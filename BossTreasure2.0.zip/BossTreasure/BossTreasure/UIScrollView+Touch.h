//
//  UIScrollView+Touch.h
//  Mall
//
//  Created by liubaojian on 15/11/13.
//  Copyright (c) 2015年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (Touch)

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;

@end
