//
//  BaseView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseView : UIView
<UITextFieldDelegate>

@end
