//
//  InterNetRequest.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/15.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^interNetSuccessBlock)(NSDictionary *dataDic);
typedef void(^interNetFailBlock)(NSError *error);

@interface InterNetRequest : NSObject

+ (instancetype)shareRequest;

- (void)toLogin :(NSString *)userName :(NSString *)md5PassWord :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
- (void)loginOut :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;


//获取订单列表
- (void)getOrderList :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//获取订单详情
- (void)getOrderDetails :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//获取订单统计
- (void)getOrderChart :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//弹框信息查询
- (void)informationSearch :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;


//采购统计
- (void)getPurchaseChart :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//获取采购订单列表
- (void)getPurchaseList :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//获取采购订单详情
- (void)getPurchaseDetails :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;


//获取入库订单列表
- (void)getStorageList :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//获取入库订单详情
- (void)getStorageDetails :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;


//获取入库订单列表
- (void)getSendGoodsList :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//获取入库订单详情
- (void)getSendGoodsDetails :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;
//发货单对比订单详情
- (void)contrastSendGoodsAndOrder :(NSDictionary *)dataDic :(interNetSuccessBlock)successBolck :(interNetFailBlock)failBlock;



@end
