 //
//  ViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/3.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()
{
    UIImageView *navBarHairlineImageView;
}
@end

@implementation BaseViewController

- (id)init{
    self = [super init];
    if (self) {
        self.enablePanGesture = YES;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
     self.automaticallyAdjustsScrollViewInsets = NO;
    self.sc=[[UIScrollView alloc]init];
    self.sc.contentSize=CGRectMake(0, 0,self.view.frame.size.width,self.view.frame.size.height+1).size;
    self.sc.showsHorizontalScrollIndicator = NO;
    self.sc.showsVerticalScrollIndicator = NO;
    self.sc.backgroundColor = RGB(247, 247, 247, 1);
    self.sc.scrollEnabled=YES;
    [self.view addSubview:self.sc];
    self.sc.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(self.view,0).rightSpaceToView(self.view,0).bottomSpaceToView(self.view,0);
    
    navBarHairlineImageView = [self findHairlineImageViewUnder:self.navigationController.navigationBar];
    navBarHairlineImageView.hidden = YES;
    
}
- (UIImageView *)findHairlineImageViewUnder:(UIView *)view {
    if ([view isKindOfClass:UIImageView.class] && view.bounds.size.height <= 1.0) {
        return (UIImageView *)view;
    }
    for (UIView *subview in view.subviews) {
        UIImageView *imageView = [self findHairlineImageViewUnder:subview];
        if (imageView) {
            return imageView;
        }
    }
    return nil;
}


/**
 *   创建导航条
 *
 *  @param text      标题
 *  @param indexPage 是否是主页
 *  @param indexPage 是否有右边的搜索
  *  @param indexPage 是否是立即去查询
 */
-(void)creatNavView :(NSString *)text :(BOOL)indexPage :(BOOL)haveRightSearch
{
    
    UILabel *navLabel = [[MethodTool shareTool] creatLabelWithAttribute:text :BIG_FONT  :2 :[UIColor whiteColor]];;
    navLabel.frame = RECT(0, 0, 100, 15, 1);
    self.navigationItem.titleView = navLabel;
    
    if (!indexPage) {
        UIButton *leftButton = [[UIButton alloc]init];
        leftButton.frame = RECT(0, 20, 45, 50,1);
        UIImageView *bgImageV = [[UIImageView alloc]init];
        bgImageV.frame = RECT(0, 15, 10, 17,1);
        bgImageV.image = [UIImage imageNamed:@"back"];
        [leftButton addSubview:bgImageV];
        leftButton.backgroundColor = [UIColor clearColor];
        [leftButton addTarget:self action:@selector(cancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
        self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftButton];
    }
    
    if (haveRightSearch) {
        UIButton *rightB = [[UIButton alloc]init];
        rightB.frame = RECT(0, 20, 45, 50,1);
        UIImageView *bgImageV = [[UIImageView alloc]init];
        bgImageV.image = [UIImage imageNamed:@"searchImage"];
        bgImageV.frame = RECT(20, 15, 24, 24,1);
        [rightB addSubview:bgImageV];
        rightB.backgroundColor = [UIColor clearColor];
        [rightB addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];
        self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];
    }
    self.view.backgroundColor = [UIColor whiteColor];
    
    
}

//为查询页面而创建
-(void)creatNavForSearchView :(NSString *)text 
{
    
    UILabel *navLabel = [[MethodTool shareTool] creatLabelWithAttribute:text :BIG_FONT  :2 :[UIColor whiteColor]];;
    navLabel.frame = RECT(0, 0, 100, 15, 1);
    self.navigationItem.titleView = navLabel;
    
    
    UIButton *leftButton = [[UIButton alloc]init];
    leftButton.frame = RECT(0, 20, 45, 50,1);
    UILabel *leftLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"取消" :MEDIUM_FONT :1 :[UIColor whiteColor]];
    leftLabel.frame = RECT(0, 18, 50, 17,1);
    [leftButton addSubview:leftLabel];
    leftButton.backgroundColor = [UIColor clearColor];
    [leftButton addTarget:self action:@selector(cancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftButton];

    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 45, 50,1);
    UIImageView *bgImageV = [[UIImageView alloc]init];
    bgImageV.image = [UIImage imageNamed:@"goto"];
    bgImageV.frame = RECT(23, 15, 20, 20,1);
    [rightB addSubview:bgImageV];
    rightB.backgroundColor = [UIColor clearColor];
    [rightB addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];
    
}
- (void)addNewRightNavItem
{
    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 45, 50,1);
    UILabel *leftLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"对比订单" :MEDIUM_FONT :2 :[UIColor whiteColor]];
    leftLabel.frame = RECT(1, 28, 80, 17,1);
    [rightB addSubview:leftLabel];
    rightB.backgroundColor = [UIColor clearColor];
    [rightB addTarget:self action:@selector(NewRightNavItemClick) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];

}
- (void)NewRightNavItemClick
{
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = NO;
    [MethodTool shareTool].viewForSVHUD = self.view;
    NSLog(@"Class :%@",NSStringFromClass(self.class));
    
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [SVProgressHUD dismiss];
}

-(void)cancelButtonEvent
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)search
{
    
}




@end
