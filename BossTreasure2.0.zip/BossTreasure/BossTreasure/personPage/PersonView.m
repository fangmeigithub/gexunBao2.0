//
//  PersonView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonView.h"
#import "PersonTableViewCell.h"

@implementation PersonView

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

- (void)initSubVWithSuperView :(UIView *)superV;
{
    cellLeftTextArray = [[NSArray alloc]initWithObjects:@"修改密码",@"关        于",@"退        出", nil];
    
    [superV addSubview:self];
    self.sd_layout.leftSpaceToView(superV,0).topSpaceToView(superV,0).rightSpaceToView(superV,0).bottomSpaceToView(superV,0);
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:Tb];
  
    Tb.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,64).rightSpaceToView(self,0).bottomSpaceToView(self,0);
    Tb.tableHeaderView = [[UIView alloc]initWithFrame:RECT(0, 0, 320, 160, 1)];
    
    //头像背景
    headHeadBgImageV = [[MethodTool shareTool] creatImageWithAttribute:@"myHeadImage2.png"];
    [Tb addSubview:headHeadBgImageV];
    headHeadBgImageV.sd_layout.leftSpaceToView(Tb,0).topSpaceToView(Tb,0).widthIs(Scale_X(320)).heightIs(Scale_Y(160));
    
    // 头像
    UIImageView *headHeadImageV = [[MethodTool shareTool] creatImageWithAttribute:@"defaultHeadImage.png"];
    [headHeadBgImageV addSubview:headHeadImageV];
    headHeadImageV.sd_layout
    .centerXEqualToView(headHeadBgImageV)
    .topSpaceToView(headHeadBgImageV,Scale_Y(20))
    .widthIs(Scale_X(80))
    .heightEqualToWidth();
    headHeadImageV.sd_cornerRadiusFromHeightRatio = @(0.5);
    
    
    
    UILabel *nameLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"姓名：张晓晓" :MEDIUM_FONT :2 :[UIColor whiteColor]];
    [headHeadBgImageV addSubview:nameLabel];
    nameLabel.sd_layout.centerXEqualToView(headHeadBgImageV).topSpaceToView(headHeadImageV,Scale_Y(7)).widthIs(Scale_X(100)).heightIs(Scale_Y(15));
    
    
    UILabel *zhanghaoLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"账号:ADADJDAJDJ00" :MEDIUM_FONT :2 :[UIColor whiteColor]];
    [headHeadBgImageV addSubview:zhanghaoLabel];
    zhanghaoLabel.sd_layout.centerXEqualToView(headHeadBgImageV).topSpaceToView(nameLabel,Scale_Y(6)).widthIs(Scale_X(140)).heightIs(Scale_Y(15));
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Scale_Y(45);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return cellLeftTextArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    PersonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[PersonTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.leftTextLabel.text =[cellLeftTextArray objectAtIndex:indexPath.row];
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    switch (indexPath.row) {
        case 0:
            self.sectionSelect(0);
            break;
        case 1:
            self.sectionSelect(1);
            break;
        case 2:
            self.sectionSelect(2);
            break;
            
        default:
            break;
    }
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat offsetY = scrollView.contentOffset.y;
    
    if (offsetY < 0) {
        headHeadBgImageV.frame = CGRectMake(offsetY/2, offsetY, WIDTH - offsetY, Scale_Y(160) - offsetY);  // 修改头部的frame值就行了
    }
}

- (void)cellClickBlock :(sectionSelectBlock )bolck;
{
    self.sectionSelect = bolck;
}

@end
