//
//  SecondViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonViewController.h"
#import "AboutViewController.h"
#import "LoginViewController.h"
#import "BaseNavigationController.h"
#import "PersonView.h"

@interface PersonViewController ()
{
    UITableView *Tb;
    
    NSArray *cellLeftTextArray;
    UIImageView *headHeadBgImageV;
}
@end

@implementation PersonViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"我的" :YES :NO];
    self.sc.scrollEnabled = NO;

    PersonView *personV = [[PersonView alloc]init];
    [personV initSubVWithSuperView:self.sc];
    [personV cellClickBlock:^(NSInteger sectionIndex) {
        
        //0 修改密码 1 关于  3 退出
        switch (sectionIndex) {
            case 0:
                
                break;
            case 1:
                [self.navigationController pushViewController:[[AboutViewController alloc]init] animated:YES];
                break;
            case 2:
               {
                   
                  UIAlertAction *suerAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                      [self initData];
                  }];
                   UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {}];
                  UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"确定要退出登录吗" preferredStyle:UIAlertControllerStyleAlert];
                   [alertVC addAction:suerAction];
                   [alertVC addAction:cancelAction];
                   [self presentViewController:alertVC animated:YES completion:nil];
                   
               }
                break;
                
            default:
                break;
        }
    }];
    
}
//放里面不会被调用
- (void)initData
{
    ShowHUD
    [[InterNetRequest shareRequest]loginOut:^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [[MethodTool shareTool] setUserDefaults:@"" :@"sysuserid"];
            BaseNavigationController *baseNav = [[BaseNavigationController alloc]initWithRootViewController:[[LoginViewController alloc]init]];
            [[MethodTool shareTool] changeWindowRootViewController:baseNav :4];
        }
        
    } :^(NSError *error) {
        DismissHUD
    }];
}


@end
