//
//  MethodTool.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FDLabelView.h"

@interface MethodTool : NSObject

@property(strong,nonatomic)UIView  *viewForSVHUD;


+ (instancetype)shareTool;

-(void)changeWindowRootViewController :(UIViewController*)vc   :(NSInteger)type;

/**
 *  初始化label
 *
 *  @param titleText           文字
 *  @param font                字号
 *  @param textAlignmentNumber 字体对齐方式
 *  @param textColor           字体颜色
 *
 *  @return label
 */
-(UILabel *)creatLabelWithAttribute :(NSString *)titleText
                                    :(NSInteger )font
                                    :(NSInteger)textAlignmentNumber
                                    :(UIColor *)textColor;




-(FDLabelView *)creatAdjustLabelWithAttribute :(NSString *)titleText
                                          :(NSInteger )font
                                          :(UIColor *)textColor;

/**
 *  初始化 UIImageView
 *
 *  @param imageName 图片名称
 *
 *  @return UIImageView
 */

-(UIImageView *)creatImageWithAttribute:(NSString *)imageName;

/**
 *  文本框
 *
 *  @param placeHolder   holder
 *
 *  @return 文本框
 */
-(UITextField *)creatTextFeild :(NSString *)placeHolder;


/**
 *  buttin
 *
 *  @param titleText 文字
 *  @param font      字体大小
 *  @param bgColor   背景颜色
 *  @param textColor 字体颜色
 *
 *  @return button
 */
-(UIButton *)creatButtonWithAttribute :(NSString *)titleText
                                      :(NSInteger )font
                                      :(UIColor *)bgColor
                                      :(UIColor *)textColor;

/**
 *  摇晃
 *
 *  @param viewToShake 试图
 */
-(void)shakeView:(UIView*)viewToShake;

/**
 *  储存
 *
 *  @param obj 值
 *  @param key 键值
 */

-(void)setUserDefaults :(id)obj :(NSString*)key;

/**
 *  取值
 *
 *  @param key 键
 *
 *  @return 值
 */
-(id)getUserDefaults :(NSString*)key;
/**
 *  数据过滤
 *
 *  @param data <#data description#>
 *
 *  @return <#return value description#>
 */
- (NSString *) cleanData:(id)data ;



//创造属性字符（截取部分颜色变化）
-(NSMutableAttributedString *)creatAttributedString :(NSString *)textTitle :(UIColor *)cutColor :(NSInteger)beginPoint :(NSInteger)length;

-(void)reflash :(UIScrollView *)scrollV;

//获取某一月的起始日期
-(NSString *)getMonthBeginAndEndWith :(NSString *)startDateStr;

//获取最近7天的日期
- (NSMutableArray *)getSevenDaysFormNow;

//获取最近7个月日期
- (NSMutableArray *)getSevenMonthFormNow;

//获得当前日期
- (NSString *)getToDayDate;



@end
