//
//  LSNavigationController.h
//  Hubanghu
//
//  Created by  striveliu on 14-11-11.
//  Copyright (c) 2014年 striveliu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseNavigationController.h"

@interface LSNavigationController : BaseNavigationController<UIGestureRecognizerDelegate,UINavigationControllerDelegate>

@end
