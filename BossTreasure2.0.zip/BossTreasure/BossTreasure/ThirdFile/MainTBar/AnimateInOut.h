//
//  AnimateInOut.h
//  Boss
//
//  Created by 孙昕 on 15/12/7.
//  Copyright © 2015年 孙昕. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimateInOut : NSObject<UIViewControllerAnimatedTransitioning>

@end
