//
//  FactoryModel.m
//  YHB_Prj
//
//  Created by  striveliu on 14/12/3.
//  Copyright (c) 2014年 striveliu. All rights reserved.
//

#import "FactoryModel.h"
#import "IndexViewController.h"
#import "PersonViewController.h"


@implementation FactoryModel
+ (FactoryModel *)shareFactoryModel
{
    static FactoryModel *factoryModel = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if(factoryModel == nil)
        {
            factoryModel = [[FactoryModel alloc] init];
        }
    });
    return factoryModel;
}

- (NSArray *)getTabbarArrys
{
    UIViewController *vc1 = [self getFirstViewController];
    UIViewController *vc2 = [self getSecondViewController];
    NSArray *arry = @[vc1,vc2];
    return arry;
}

- (UIViewController *)getFirstViewController
{
    UIViewController *firstVC = [[IndexViewController alloc] init];
    return firstVC;
}

- (UIViewController *)getSecondViewController
{
    UIViewController *secondVC = [[PersonViewController alloc] init];
    return secondVC;
}

- (UIViewController *)getloginViewController
{
    return nil;
}
@end
