

#define HEIGHT                   [UIScreen mainScreen].bounds.size.height
#define WIDTH                    [UIScreen mainScreen].bounds.size.width
#define NEWX                     [UIScreen mainScreen].bounds.size.width/320
#define NEWY                     [UIScreen mainScreen].bounds.size.height/568
#define RECT(a,b,c,d,e)           CGRectMake(a*NEWX, e==0?b:b*NEWY, c*NEWX, d*NEWY)
#define Scale_X(a)                 (a*NEWX)
#define Scale_Y(a)                 (a*NEWY)
#define NavHeight                  64



#define SYSTEMIOS7  ([[[UIDevice currentDevice]systemVersion]floatValue]>=7?YES:NO)
#define IfDebug true

//http://121.43.101.138/weixin/orderDetail.json?fid=224
//#define ServerUrl @"http://www.tgrass.com/phone/"
//#define ServerUrl @"http://wifi.tgrass.com/app/"
#define ServerUrl                @"http://www.nhfmall.com:80/app/kernel.json?data="
//#define RequestUrl               @"http://app.tuorong-china.cn:8080/gx.deplay/app/kernel.json"//后台通用请求接口
#define UPImageURL               @"http://www.nhfmall.com/gx.fm//FileUpload"//图片上传接口
#define ShowImageURL                  @"http://121.43.101.138:85/"//图片显示接口
#define ShowGoodsURL                  @"http://www.nhfmall.com/app/appMerShow.json?"//图片商品详情


// 判断硬件类型
#define iPhone4 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6Plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(414, 736), [[UIScreen mainScreen] currentMode].size) : NO)

#define SYSTEMIOS7  ([[[UIDevice currentDevice]systemVersion]floatValue]>=7?YES:NO)
#define current_SYSTEMIOS  ([[[UIDevice currentDevice]systemVersion]floatValue])
 
#define DATE_CURRENT ([NSDate date])
#define TimeOut 300



//*************************************** GEXUN ***********************************************

#define NEWSTITLECOLOR ([UIColor colorWithRed:64/255.0 green:56/255.0 blue:53/255.0 alpha:1.0f])
#define NEWSCONTEXTCOLOR ([UIColor colorWithRed:190/255.0 green:190/255.0 blue:190/255.0 alpha:1.0f])
#define blackC ([UIColor colorWithRed:50/255.0 green:50/255.0 blue:50/255.0 alpha:1.0f])
#define GrayTextColor  ([UIColor colorWithRed:120/255.0 green:120/255.0 blue:120/255.0 alpha:1.0f])
#define ViewlineColor ([UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1.0f])
#define REDCOLOR ([UIColor colorWithRed:242/255.0 green:74/255.0 blue:81/255.0 alpha:1.0f])
#define ORANGE_COLOR ([UIColor colorWithRed:250/255.0 green:80/255.0 blue:32/255.0 alpha:1.0f])
#define LikeBlackColor    RGB(40, 40, 40, 1)
/**
 *
 */
//主黄色
#define MainNavColor ([UIColor colorWithRed:248/255.0 green:150/255.0 blue:68/255.0 alpha:1.0f])
#define loginTextColor ([UIColor colorWithRed:97/255.0 green:149/255.0 blue:190/255.0 alpha:1.0f])
#define RGB(a,b,c,d)  [UIColor  colorWithRed:(a/255.0) green:(b/255.0) blue:(c/255.0) alpha:(d)]
#define theDelegate ((AppDelegate *)[[UIApplication sharedApplication] delegate])

#define showMessage(a)   [SVProgressHUD showInfoWithStatus:a maskType:SVProgressHUDMaskTypeGradient];
#define kUseScreenShotGesture 1
#define Success  [[[MethodTool shareTool] cleanData:dataDic[@"status"]]isEqualToString:@"1"]
#define ShowHUD  [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeGradient];
#define DismissHUD  [SVProgressHUD dismiss];

#define HttpHead  [NSString stringWithFormat:@"http://%@:%@",IP,Port]


//***********************************************************************************************

#define BIG_FONT    18
#define MEDIUM_FONT 15
#define SMALL_FONT  14

//***********************************************************************************************



