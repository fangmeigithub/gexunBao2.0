//
//  NSString+CodeAndClean.h
//  Mall
//
//  Created by liubaojian on 15/11/4.
//  Copyright © 2015年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CodeAndClean)

/**
 *  汉字编码
 */
-(NSString *)encodeChinese ;
/**
 *  汉字解码
 */
-(NSString *)decodeChinese;

-(NSString *)delectEmptyString ;


-(id)numberInter;
//前拼接
- (NSString *)headFormat:(NSString *)headStr;
//后拼接
- (NSString *)endFormat:(NSString *)endStr;

@end
