//
//  AppDelegate.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/3.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScreenShotView.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ScreenShotView *screenshotView;

@end

