//
//  LoginView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "LoginView.h"


extern NSString *IP;
extern NSString *Port;

@implementation LoginView


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        rememberPW = [[[MethodTool shareTool] getUserDefaults:@"rememberPW"] boolValue];
        autoLogin = [[[MethodTool shareTool] getUserDefaults:@"autoLogin"] boolValue];
        userName = [[MethodTool shareTool] getUserDefaults:@"UserName"];
        passWord = [[MethodTool shareTool] getUserDefaults:@"PassWord"];
        
        
        [self initSub];
    }
    return self;
}

- (void)initSub
{

    UIButton *rightButton = [[UIButton alloc]init];
    UIImageView *bgImageV = [[UIImageView alloc]init];
    bgImageV.frame = CGRectMake(20*NEWX, 12*NEWY, 20.5*NEWX, 20.5*NEWX);;
    bgImageV.image = [UIImage imageNamed:@"setting.png"];
    [rightButton addSubview:bgImageV];
    rightButton.backgroundColor = [UIColor clearColor];
    [rightButton addTarget:self action:@selector(setting) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:rightButton];
    rightButton.sd_layout.topSpaceToView(self,Scale_Y(20)).rightSpaceToView(self,Scale_X(5)).widthIs(Scale_X(50)).heightIs(Scale_X(50));
    
    //logo图
    UIImageView *logoImageV = [[MethodTool shareTool] creatImageWithAttribute:@"loginLogo"];
    [self addSubview:logoImageV];
    logoImageV.sd_layout.centerXEqualToView(self).topSpaceToView(self,Scale_Y(95)).widthIs(Scale_X(213)).heightIs(Scale_Y(67));
    

    
    nameBgView = [UIView new];
    nameBgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:nameBgView];
    nameBgView.sd_layout.leftSpaceToView(self,Scale_X(15)).topSpaceToView(logoImageV,Scale_Y(70)).rightSpaceToView(self,Scale_X(15)).heightIs(Scale_Y(40));
    
    
    nameTF = [[MethodTool shareTool] creatTextFeild:@"用户名"];
    [nameBgView addSubview:nameTF];
    nameTF.delegate = self;
    UIEdgeInsets sg = UIEdgeInsetsMake(10, 15, 10, 15);
    nameTF.sd_layout.spaceToSuperView(sg);
    //用户名
    if ([userName length]>0) {
        nameTF.text = userName;
    }
    
    
    passWordBgView = [UIView new];
    passWordBgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:passWordBgView];
    passWordBgView.sd_layout.leftEqualToView(nameBgView).topSpaceToView(nameBgView,Scale_Y(15)).rightEqualToView(nameBgView).heightRatioToView(nameBgView,1);
    
    passWordTF = [[MethodTool shareTool] creatTextFeild:@"密码"];
    [passWordBgView addSubview:passWordTF];
    passWordTF.secureTextEntry = YES;
    passWordTF.delegate = self;
    UIEdgeInsets sg1 = UIEdgeInsetsMake(10, 15, 10, 15);
    passWordTF.sd_layout.spaceToSuperView(sg1);
    //记住密码
    if ([passWord length]>0) {
        passWordTF.text = @"abcde";
    }
    
    //记住密码
    
    UIButton *rememberB = [UIButton new];
    [self addSubview:rememberB];
    rememberB.selected = rememberPW;
    rememberB.sd_layout.leftEqualToView(passWordBgView).topSpaceToView(passWordBgView,0).widthIs(Scale_X(50)).heightIs(Scale_Y(40));
    [rememberB addTarget:self action:@selector(rememberClick:) forControlEvents:UIControlEventTouchUpInside];
    
    rememberPassWordImageV = [[MethodTool shareTool] creatImageWithAttribute:rememberPW?@"loginSelect":@"onSelectKuang"];
    [self addSubview:rememberPassWordImageV];
    rememberPassWordImageV.sd_layout.leftSpaceToView(self,Scale_X(17)).topSpaceToView(passWordBgView,Scale_Y(10)).widthIs(Scale_X(15)).heightIs(Scale_X(15));
    
    UILabel *rememberLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"记住密码" :MEDIUM_FONT :1 :[UIColor whiteColor]];
    [self addSubview:rememberLabel];
    rememberLabel.sd_layout.leftSpaceToView(rememberPassWordImageV,Scale_X(5)).topEqualToView(rememberPassWordImageV).widthIs(Scale_X(80)).heightIs(Scale_Y(15));
    
    //自动登录
    
    UILabel *autoLoginLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"自动登录" :MEDIUM_FONT :1 :[UIColor whiteColor]];
    [self addSubview:autoLoginLabel];
    autoLoginLabel.sd_layout.rightEqualToView(passWordBgView).topEqualToView(rememberPassWordImageV).widthIs(Scale_X(60)).heightIs(Scale_Y(15));
    
    
    autoLoginImageV = [[MethodTool shareTool] creatImageWithAttribute:autoLogin?@"loginSelect":@"onSelectKuang"];
    [self addSubview:autoLoginImageV];
    autoLoginImageV.sd_layout.rightSpaceToView(autoLoginLabel,Scale_X(5)).topEqualToView(autoLoginLabel).widthIs(Scale_X(15)).heightIs(Scale_X(15));
    
    UIButton *aotuLoginB = [UIButton new];
    [self addSubview:aotuLoginB];
    aotuLoginB.selected = autoLogin;
    aotuLoginB.sd_layout.rightSpaceToView(autoLoginLabel,0).topSpaceToView(passWordBgView,0).widthIs(Scale_X(50)).heightIs(Scale_X(40));
    [aotuLoginB addTarget:self action:@selector(aotuLogin:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *loginButton = [[MethodTool shareTool] creatButtonWithAttribute:@"登录" :MEDIUM_FONT :RGB(247, 150, 68, 1) :[UIColor whiteColor]];
    [self addSubview:loginButton];
    loginButton.sd_layout.leftEqualToView(passWordBgView).topSpaceToView(passWordBgView,Scale_Y(80)).rightEqualToView(passWordBgView).heightIs(Scale_Y(40));
    loginButton.layer.cornerRadius = 3;
    [loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    
    //自动登录
    if (autoLogin&&passWord.length>0) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            NSArray *array = @[];
            if (passWord.length==32) {
                array = @[nameTF.text,passWord];
            }else{
                array = @[nameTF.text,passWordTF.text];
            }
            self.block(array);
        });
      
    }
    
    
}

#pragma mark－－－－－－－－－－－－－－－－－－－事件－－－－－－－－－－－－－－－－
//记住密码
-(void)rememberClick :(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        rememberPassWordImageV.image = [UIImage imageNamed:@"loginSelect"];\
        rememberPW = YES;
    } else {
        rememberPassWordImageV.image = [UIImage imageNamed:@"onSelectKuang"];
        rememberPW = NO;
        [[MethodTool shareTool] setUserDefaults:@"" :@"PassWord"];
    }
    [[MethodTool shareTool] setUserDefaults:[NSNumber numberWithBool:rememberPW] :@"rememberPW"];
}

//自动登录
-(void)aotuLogin :(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        autoLoginImageV.image = [UIImage imageNamed:@"loginSelect"];
        autoLogin = YES;
    } else {
        autoLoginImageV.image = [UIImage imageNamed:@"onSelectKuang"];
        autoLogin = NO;
    }
     [[MethodTool shareTool] setUserDefaults:[NSNumber numberWithBool:autoLogin] :@"autoLogin"];
}
//登录
-(void)login
{
    if ([IP length]==0) {
        showMessage(@"请先设置IP和端口号");
    }
    else if (nameTF.text.length==0) {
        showMessage(@"请输入用户名");
    }//限制输入的密码长度小于32位（md5 值）更安全，
    else if (passWordTF.text.length == 0||passWordTF.text.length >10){
        showMessage(@"密码输入有误");
    }
    else
    {
        NSArray *array = @[];
        if (passWord.length==32) {
            array = @[nameTF.text,passWord];
        }else{
            array = @[nameTF.text,passWordTF.text];
        }
        self.block(array);
    }
    
}
// 设置
-(void)setting
{
    self.settingBlock();
}

- (void)dologin :(loginBlock)block
{
    self.block = block;
}
-(void)toSettig:(toSettingBlock )block;{
    
    self.settingBlock = block;
}




@end
