//
//  LoginView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseView.h"

typedef void(^loginBlock)(NSArray *parameterArray);
typedef void(^toSettingBlock)();


@interface LoginView : BaseView
<UITextFieldDelegate>
{
    UIView *nameBgView;
    UIView *passWordBgView;
    
    UITextField *nameTF;
    UITextField *passWordTF;
    
    UIImageView *rememberPassWordImageV;
    UIImageView *autoLoginImageV;
    
    BOOL rememberPW;
    BOOL autoLogin;
    NSString *userName;
    NSString *passWord;
}
@property(nonatomic,copy) loginBlock block;
@property(nonatomic,copy) toSettingBlock settingBlock;

-(void)dologin:(loginBlock )block;
-(void)toSettig:(toSettingBlock )block;

@end
