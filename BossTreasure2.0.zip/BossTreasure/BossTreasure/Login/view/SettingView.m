//
//  SettingView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SettingView.h"


extern NSString *IP;
extern NSString *Port;
@implementation SettingView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initSubV];
    }
    return self;
}

- (void)initSubV
{
    
    iPView = [UIView new];
    iPView.backgroundColor = [UIColor whiteColor];
    [self addSubview:iPView];
    iPView.sd_layout.leftSpaceToView(self,Scale_X(15)).topSpaceToView(self,NavHeight+Scale_Y(40)).rightSpaceToView(self,Scale_X(15)).heightIs(Scale_Y(50));
    
    UILabel *ipLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"服务器IP" :MEDIUM_FONT :1 :GrayTextColor];
    [iPView addSubview:ipLabel];
    ipLabel.sd_layout.leftSpaceToView(iPView,Scale_X(10)).topSpaceToView(iPView,Scale_Y(15)).widthIs(Scale_X(60)).heightIs(Scale_Y(20));
    ipTF = [[MethodTool shareTool] creatTextFeild:@"请输入服务器IP"];
    ipTF.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    [iPView addSubview:ipTF];
    ipTF.delegate = self;
    UIEdgeInsets sg = UIEdgeInsetsMake(15, 90, 15, 15);
    ipTF.sd_layout.spaceToSuperView(sg);
    if (IP.length !=0) {
        ipTF.text = IP;
    }else{//设置一个默认的Ip服务器地址
        ipTF.text = @"121.41.87.34";
    }
    
    
    portView = [UIView new];
    portView.backgroundColor = [UIColor whiteColor];
    [self addSubview:portView];
    portView.sd_layout.leftEqualToView(iPView).topSpaceToView(iPView,10).rightEqualToView(iPView).heightRatioToView(iPView,1);
    
    UILabel *portLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"端口号" :MEDIUM_FONT :1 :GrayTextColor];
    [portView addSubview:portLabel];
    portLabel.sd_layout.leftSpaceToView(portView,Scale_X(10)).topSpaceToView(portView,Scale_Y(15)).widthIs(Scale_X(60)).heightIs(Scale_Y(20));
    
    portTF = [[MethodTool shareTool] creatTextFeild:@"请输入端口号"];
    [portView addSubview:portTF];
    portTF.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    portTF.delegate = self;
    UIEdgeInsets sg1 = UIEdgeInsetsMake(15, 90, 15, 15);
    portTF.sd_layout.spaceToSuperView(sg1);
    if (Port.length !=0) {
        portTF.text = Port;;
    }else{//设置一个默认的端口
        portTF.text = @"8083";
    }
    
    UIButton *loginButton = [[MethodTool shareTool] creatButtonWithAttribute:@"保存" :16 :RGB(247, 150, 68, 1) :[UIColor whiteColor]];
    [self addSubview:loginButton];
    loginButton.sd_layout.leftEqualToView(portView).topSpaceToView(portView,Scale_Y(40)).rightEqualToView(portView).heightIs(Scale_Y(40));
    loginButton.layer.cornerRadius = Scale_X(3);
    [loginButton addTarget:self action:@selector(save) forControlEvents:UIControlEventTouchUpInside];
}

- (void)save
{
    [[MethodTool shareTool] setUserDefaults:ipTF.text :@"IP"];
    [[MethodTool shareTool] setUserDefaults:portTF.text :@"Port"];
    IP = ipTF.text;
    Port = portTF.text;
    self.block();
}

- (void)savePort:(savePortBlock)block
{
    self.block = block;
}



@end
