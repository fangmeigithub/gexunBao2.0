//
//  SettingViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SettingViewController.h"
#import "SettingView.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"设置" :NO :NO ];
    
    SettingView *settingV = [[SettingView alloc]init];
    settingV.frame = self.view.frame;
    [self.sc addSubview:settingV];
    [settingV savePort:^{
        [self.navigationController popViewControllerAnimated:YES];
    }];
}



@end
