//
//  LoginViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginView.h"
#import "SettingViewController.h"
#import "RootTabBarController.h"
#import "MyMD5.h"


extern  NSString *UserId;
@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    //背景
    UIImageView *bgImaeV = [[MethodTool shareTool] creatImageWithAttribute:@"loginBgImage"];
    [self.view addSubview:bgImaeV];
    bgImaeV.sd_layout.leftSpaceToView(self.view,0).rightSpaceToView(self.view,0).topSpaceToView(self.view,0).bottomSpaceToView(self.view,0);
    
    self.sc.backgroundColor = [UIColor clearColor];
    LoginView *loginV = [[LoginView alloc]init];
    loginV.frame = self.view.frame;
    [self.sc addSubview:loginV];
    [self.view bringSubviewToFront:self.sc];
    
    //登录
    [loginV dologin:^(NSArray *parameterArray) {

        //传过来的数据是否是md5加密的
        NSString *md5PassWord  = @"";
        if ([parameterArray[1] length]<=20) {
            md5PassWord = [MyMD5 md5:parameterArray[1]];
        }else{
            md5PassWord = parameterArray[1];
        }
        
        ShowHUD
        [[InterNetRequest shareRequest]toLogin:parameterArray[0] :md5PassWord :^(NSDictionary *dataDic) {
            NSLog(@"kkkk:%@",dataDic);
            DismissHUD
            if (Success) {
                //记住密码
                if ([[[MethodTool shareTool] getUserDefaults:@"rememberPW"] boolValue]) {
                    [[MethodTool shareTool] setUserDefaults:parameterArray[0] :@"UserName"];
                    [[MethodTool shareTool] setUserDefaults:md5PassWord :@"PassWord"];
                }
                [[MethodTool shareTool] setUserDefaults:dataDic[@"data"][@"sysuserid"] :@"sysuserid"];
                [[MethodTool shareTool] setUserDefaults:dataDic[@"data"][@"unionNo"] :@"unionNo"];
                //全局UserId
                UserId = dataDic[@"data"][@"sysuserid"];
                RootTabBarController *rotVC = [[RootTabBarController alloc]init];
                [[MethodTool shareTool] changeWindowRootViewController:rotVC :3];
            }
        } :^(NSError *error) {
            DismissHUD
        }];
    }];
    //设置
    [loginV toSettig:^{
        [self.navigationController pushViewController:[[SettingViewController alloc]init] animated:YES];
    }];
    
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = YES;
    
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    self.navigationController.navigationBar.hidden = NO;
}


@end
