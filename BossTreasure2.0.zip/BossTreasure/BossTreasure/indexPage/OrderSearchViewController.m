//
//  OrderSearchViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderSearchViewController.h"
#import "UIScrollView+Touch.h"

@interface OrderSearchViewController ()

@end

extern NSString *UserId;
@implementation OrderSearchViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
   
    
    searchV = [[OrderSearchView alloc]init];
    searchV.frame = self.view.frame;
    [self.view addSubview:searchV];
    searchV.myDelegate = self;
    [self creatNavForSearchView:@"订单搜索"];
    
}
-(void)cancelButtonEvent
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

//提交搜索条件进行搜索
- (void)search
{
    NSDictionary *parameterDic = [searchV backInterNetParameter];
    self.beforeViewController.subDataDic = parameterDic; //预留的公共接口
    self.beforeViewController.appearLoadTb = YES;
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark－－－－－－－－－－－－－－－－－－－searchSomeParameterDelegate delegate－－－－－－－－－－－－－－－－

- (void)searchSomeParameter:(NSString *)parameterKey
{
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithCapacity:0];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:0];
    dict[@"limit"] = @"1000";
    dict[@"start"] =[NSNumber numberWithInteger:0];
    dict[@"unionNo"] = [[MethodTool shareTool] getUserDefaults:@"unionNo"];
    dict[@"queryField"] = parameterKey;
    
    ShowHUD
    [[InterNetRequest shareRequest]informationSearch:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        if (Success) {
        
            [searchV  interNetBackData:dataDic[@"data"]];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}


@end
