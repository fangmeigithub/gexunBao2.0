//
//  IndexViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/3.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "IndexViewController.h"
//**************监控相关***************
#import "Global.h"
#import "playEx.h"
#import "MonitorViewController.h"
#import "PlaceDTO.h"

void cbDisConnect(LLONG lLoginID, char *pchDVRIP, LONG nDVRPort, LDWORD dwUser)
{
    // save C-string to NSString to get the GCD capture mechanism working correctly
    NSString* ip = [[NSString alloc] initWithUTF8String:pchDVRIP];
    ALERT(_L(@"Device %@ disconnected"), ip);
}

void cbhaveReConnect(LLONG lLoginID, char *pchDVRIP, LONG nDVRPort, LDWORD dwUser)
{
    NSString* ip = [[NSString alloc] initWithUTF8String:pchDVRIP];
    ALERT(_L(@"Device %@ reconnected"), ip);
}

void cbSubDisConnect(EM_INTERFACE_TYPE emInterfaceType, BOOL bOnline, LLONG lOperateHandle, LLONG lLoginID, LDWORD dwUser)
{
#define CASE_LIST()\
X(DH_INTERFACE_REALPLAY)\
X(DH_INTERFACE_PREVIEW)\
X(DH_INTERFACE_PLAYBACK)\
X(DH_INTERFACE_DOWNLOAD)\
X(DH_INTERFACE_REALLOADPIC)
    
    switch (emInterfaceType) {
#define X(type)\
case type:\
ALERT(_L(@"Subconnection disconnected: %s"), #type);\
break;
            CASE_LIST()
#undef X
        default:
            break;
    }
}


//**************监控相关***************end

@interface IndexViewController ()

{
    UIImageView *imageV1;
    UIImageView *imageV2;
    UIImageView *imageV3;
    UIImageView *imageV4;
    UIImageView *imageV5;
    UIImageView *imageV6;
    UIImageView *imageV7;
    UIImageView *imageV8;
    
    NSString    *className;
    
    NSTimer     *slowShowImageTimer;
    float       variable;
    
}
@end

@implementation IndexViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [super creatNavView:@"首页" :YES :NO ];

    [self creatSubV];
}

-(void)creatSubV
{
    imageV1 = [[MethodTool shareTool] creatImageWithAttribute:@"index0"];
    imageV1.alpha = 0;
    imageV1.userInteractionEnabled = YES;
    [self.sc addSubview:imageV1];
    imageV2 = [[MethodTool shareTool] creatImageWithAttribute:@"index1"];
    imageV2.alpha = 0;
    imageV2.userInteractionEnabled = YES;
    [self.sc addSubview:imageV2];
    imageV3 = [[MethodTool shareTool] creatImageWithAttribute:@"index2"];
    imageV3.alpha = 0;
    imageV3.userInteractionEnabled = YES;
    [self.sc addSubview:imageV3];
    imageV4 = [[MethodTool shareTool] creatImageWithAttribute:@"index3"];
    imageV4.alpha = 0; 
    imageV4.userInteractionEnabled = YES;
    [self.sc addSubview:imageV4];
    imageV5 = [[MethodTool shareTool] creatImageWithAttribute:@"index4"];
    imageV5.alpha = 0;
    imageV5.userInteractionEnabled = YES;
    [self.sc addSubview:imageV5];
    imageV6 = [[MethodTool shareTool] creatImageWithAttribute:@"index5"];
    imageV6.alpha = 0;
    imageV6.userInteractionEnabled = YES;
    [self.sc addSubview:imageV6];
    imageV7 = [[MethodTool shareTool] creatImageWithAttribute:@"index6"];
    imageV7.alpha = 0;
    imageV7.userInteractionEnabled = YES;
    [self.sc addSubview:imageV7];
    imageV8 = [[MethodTool shareTool] creatImageWithAttribute:@"index7"];
    imageV8.alpha = 0;
    imageV8.userInteractionEnabled = YES;
    [self.sc addSubview:imageV8];
    
    self.sc.contentSize = CGSizeMake(WIDTH, Scale_Y(580));
    
    
    imageV1.sd_layout.leftSpaceToView(self.sc,Scale_X(33)).topSpaceToView(self.sc,(NavHeight+Scale_Y(15))).widthIs(Scale_X(110)).heightIs(Scale_Y(100));
    imageV2.sd_layout.topEqualToView(imageV1).rightSpaceToView(self.sc,Scale_Y(33)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,Scale_Y(10)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV4.sd_layout.topEqualToView(imageV3).rightEqualToView(imageV2).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV5.sd_layout.leftEqualToView(imageV3).topSpaceToView(imageV3,Scale_Y(10)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV6.sd_layout.topEqualToView(imageV5).rightEqualToView(imageV2).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV7.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV5,Scale_Y(10)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV8.sd_layout.topEqualToView(imageV7).rightEqualToView(imageV2).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    
    
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView1:)];
    UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView2:)];
    UITapGestureRecognizer *tapGe3 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView3:)];
    UITapGestureRecognizer *tapGe4 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView4:)];
    UITapGestureRecognizer *tapGe5 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView5:)];
    UITapGestureRecognizer *tapGe6 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView6:)];
    UITapGestureRecognizer *tapGe7 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView7:)];
    UITapGestureRecognizer *tapGe8 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView8:)];
    
    [imageV1 addGestureRecognizer:tapGe1];
    [imageV2 addGestureRecognizer:tapGe2];
    [imageV3 addGestureRecognizer:tapGe3];
    [imageV4 addGestureRecognizer:tapGe4];
    [imageV5 addGestureRecognizer:tapGe5];
    [imageV6 addGestureRecognizer:tapGe6];
    [imageV7 addGestureRecognizer:tapGe7];
    [imageV8 addGestureRecognizer:tapGe8];
    
    variable = 0.0;
    slowShowImageTimer = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(changeImageAlpha) userInfo:nil repeats:YES];
    
}


//销售
- (void)topAImageView1:(UITapGestureRecognizer *)sender
{
    className = @"OrderChartsViewController";
    [self flipView:imageV1];
    
}
//采购
- (void)topAImageView2:(UITapGestureRecognizer *)sender
{
    className = @"PurchaseCharrViewController";
    [self flipView:imageV2];
}
//入库
- (void)topAImageView3:(UITapGestureRecognizer *)sender
{
    className = @"StorageListViewController";
    [self flipView:imageV3];
    
}
//发货
- (void)topAImageView4:(UITapGestureRecognizer *)sender
{
    className = @"SendGoodsListViewController";
    [self flipView:imageV4];
    
}
//对账
- (void)topAImageView5:(UITapGestureRecognizer *)sender
{
    className = @"";
    [self flipView:imageV5];
    
}
//收款
- (void)topAImageView6:(UITapGestureRecognizer *)sender
{
    className = @"";
    [self flipView:imageV6];
    
}
//360监控
- (void)topAImageView7:(UITapGestureRecognizer *)sender
{
    className = @"360";
    [self flipView:imageV7];
    
}
//机联网
- (void)topAImageView8:(UITapGestureRecognizer *)sender
{
    className = @"MachineLinkInterNetViewController";
    [self flipView:imageV8];
    
}

-(void)flipView:(UIView *)view
{
    self.view.userInteractionEnabled = NO;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:view cache:YES];
    [UIView setAnimationDuration:0.7];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(pushNewVc)];
    [UIView commitAnimations];
    
}
-(void)pushNewVc
{
    if ([className isEqualToString:@"360"]) {
        //**************监控相关***************
        //监控相关设置
        //监控相关设置
#ifndef DEBUG
        static const std::string logPath = g_docFolder + "/log.txt";
        freopen(logPath.c_str(), "a+", stderr);
        freopen(logPath.c_str(), "a+", stdout);
#endif
        if (!CLIENT_Init(cbDisConnect, NULL)) {
            ALERT_ERROR(CLIENT_Init);
            return;
        }
        printLog("CLIENT_GetSDKVersion() = %u", CLIENT_GetSDKVersion());
        CLIENT_SetAutoReconnect(cbhaveReConnect, 0);
        NET_PARAM netParam = {8000, 3000, 3, 100};
        CLIENT_SetNetworkParam(&netParam);
        CLIENT_SetSubconnCallBack(cbSubDisConnect, NULL);
        
        PlaceDTO *place = [[PlaceDTO alloc] initWithFip:@"112.12.61.155" fserPort:@"37777" fuser:@"admin" fpwd:@"admin"];
        MonitorViewController *monitorVC = [[MonitorViewController alloc] initWithPlace:place];
        [self.navigationController pushViewController:monitorVC animated:YES];
    }
    Class cls=NSClassFromString(className);
    UIViewController  *viewController=[[[cls class] alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
    self.view.userInteractionEnabled = YES;
}
- (void)changeImageAlpha
{
    variable+= 0.05;
    imageV1.alpha = variable;
    imageV2.alpha = variable;
    imageV3.alpha = variable;
    imageV4.alpha = variable;
    imageV5.alpha = variable;
    imageV6.alpha = variable;
    imageV7.alpha = variable;
    imageV8.alpha = variable;
    
    if (variable>=1) {
        [slowShowImageTimer invalidate];
        slowShowImageTimer = nil;
    }
}


@end
