//
//  OrderListViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderListViewController.h"
#import "OrderSearchViewController.h"
#import "OrderListTableView.h"
#import "OrderDetialsViewController.h"
#import "OrderListModel.h"
#import "UIScrollView+VORefresh.h"


extern NSString *UserId;
@interface OrderListViewController ()
{
    OrderListModel *orderListM;
    NSInteger page,start,AllPage;
    NSString  *loadStyle;
    NSMutableArray *orderListArray;
    OrderListTableView *orderListTbV;
    
}
@end

@implementation OrderListViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [super creatNavView:@"销售订单列表" :NO :YES ];
    
    orderListTbV = [[OrderListTableView alloc]init];
    orderListTbV.superV  = self.view;
    [orderListTbV cellClickBlock:^(NSInteger cellIndex) {
        OrderDetialsViewController *orderDetailsVC  = [[OrderDetialsViewController alloc]init];
        orderDetailsVC.dataModel = [orderListArray objectAtIndex:cellIndex];
        [self.navigationController pushViewController:orderDetailsVC animated:YES];
    }];
    [orderListTbV addTopRefreshWithTarget:self action:@selector(headRefresh)];
    [orderListTbV addBottomRefreshWithTarget:self action:@selector(bottomRefreshing)];
    [[MethodTool shareTool] reflash:orderListTbV];
    
    orderListArray = [[NSMutableArray alloc]initWithCapacity:0];
    orderListM = [[OrderListModel alloc]init];
    page =1;
    start = 0;
    AllPage = 1;
    loadStyle = @"head";
   [self initData];
    

}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (self.appearLoadTb) {
         page = 1;
         [self initData];
    }
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewDidAppear:YES];
    self.appearLoadTb = NO;
    
}

- (void)initData
{
    start = page>1?page*10:0;
    
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:self.subDataDic];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:page];
    dict[@"limit"] = @"10";
    dict[@"start"] =[NSNumber numberWithInteger:start];
    
    ShowHUD
    [[InterNetRequest shareRequest]getOrderList:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        [orderListTbV.topRefresh  endRefreshing];
        [orderListTbV.bottomRefresh  endRefreshing];
        if (Success) {
            [orderListM initWithDic:dataDic];
            //总页数
            for (NSDictionary *dic in dataDic[@"data"]) {
                if (dic.count==1) {
                    AllPage = [dic[@"totalCount"] integerValue]/10+1;
                }
            }
            if ([loadStyle isEqualToString:@"head"] ) {
                page = 1;
                [orderListArray removeAllObjects];
            }
            
            [orderListArray addObjectsFromArray:orderListM.data];
             orderListTbV.modelArray = orderListArray;
            [orderListTbV reloadData];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

//刷新
-(void)headRefresh
{
    loadStyle = @"head";
    [self initData];
}
//尾部刷新
-(void)bottomRefreshing
{
    page ++;
    if (page<=AllPage) {
        loadStyle = @"bottom";
        [self initData];
    }else{
        [orderListTbV.bottomRefresh  endRefreshing];
    }
}

//搜索页面 
- (void)search
{
    OrderSearchViewController *orderSearchVc = [[OrderSearchViewController alloc]init];
    orderSearchVc.beforeViewController = self;
    [self.navigationController presentViewController:[[UINavigationController alloc]initWithRootViewController:orderSearchVc] animated:YES completion:nil];
}


@end
