//
//  MachineLinkInterNetViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/4.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface MachineLinkInterNetViewController : BaseViewController

@end
