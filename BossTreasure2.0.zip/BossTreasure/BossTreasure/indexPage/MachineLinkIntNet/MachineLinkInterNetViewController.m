//
//  MachineLinkInterNetViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/4.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MachineLinkInterNetViewController.h"
#import "MachineLinkInterNetDetailViewController.h"

@interface MachineLinkInterNetViewController ()
{
    UIImageView *imageV1;
    UIImageView *imageV2;
    NSString *className;
    UIView *flipView;
}
@end

@implementation MachineLinkInterNetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"机联网" :NO :NO];
    [self creatSubV];
}
- (void)creatSubV
{
    imageV1 = [[MethodTool shareTool] creatImageWithAttribute:@"home_menu1"];
    imageV1.userInteractionEnabled = YES;
    [self.sc addSubview:imageV1];
    imageV2 = [[MethodTool shareTool] creatImageWithAttribute:@"home_menu2"];
    imageV2.userInteractionEnabled = YES;
    [self.sc addSubview:imageV2];
    
    
    imageV1.sd_layout.leftSpaceToView(self.sc,Scale_X(33)).topSpaceToView(self.sc,(64+Scale_Y(80))).widthIs(Scale_X(110)).heightIs(Scale_Y(100));
    imageV2.sd_layout.topEqualToView(imageV1).rightSpaceToView(self.sc,Scale_Y(33)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    
    
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView1:)];
    UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView2:)];
    
    [imageV1 addGestureRecognizer:tapGe1];
    [imageV2 addGestureRecognizer:tapGe2];
}
//订单
- (void)topAImageView1:(UITapGestureRecognizer *)sender
{
    MachineLinkInterNetDetailViewController *machineLVC = [[MachineLinkInterNetDetailViewController alloc]init];
    machineLVC.titleStr = @"机台状态";
    [self.navigationController pushViewController:machineLVC animated:YES];
}
//订货管理
- (void)topAImageView2:(UITapGestureRecognizer *)sender
{
    MachineLinkInterNetDetailViewController *machineLVC = [[MachineLinkInterNetDetailViewController alloc]init];
    machineLVC.titleStr = @"智能分析";
    [self.navigationController pushViewController:machineLVC animated:YES];
}


@end
