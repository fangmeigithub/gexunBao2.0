//
//  MachineLinkInterNetDetailViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/4.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MachineLinkInterNetDetailViewController.h"

@interface MachineLinkInterNetDetailViewController ()
{
    UIWebView *showContentWebV;
}
@end

@implementation MachineLinkInterNetDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:self.titleStr :NO :NO];
    
    showContentWebV = [[UIWebView alloc]init];
    [self.view addSubview:showContentWebV];
    showContentWebV.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(self.view,64+Scale_Y(5)).rightSpaceToView(self.view,0).bottomSpaceToView(self.view,0);
    [self loadRequest];
}
- (void)loadRequest
{
    NSURLRequest *request = nil;
    if ([self.titleStr isEqualToString:@"机台状态"]) {
        request =[[NSURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://www.baidu.com"]];
    }else
    {
        request = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://www.baidu.com"]];
    }
    [showContentWebV loadRequest:request];
}

@end
