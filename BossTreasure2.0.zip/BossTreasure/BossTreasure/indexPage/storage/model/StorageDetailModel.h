//
//  StorageDetailModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StorageDetailModel : NSObject


@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, strong) NSArray *data;

- (void)initWithDic :(NSDictionary *)dataDic;

@end

@interface StorageDetailDataModel : NSObject

@property (nonatomic, copy) NSString *fpurNo;

@property (nonatomic, copy) NSString *style;

@property (nonatomic, copy) NSString *color;

@property (nonatomic, assign) double fprice;

@property (nonatomic, assign) double fqty;

@property (nonatomic, copy) NSString *fitemName;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, copy) NSString *fitemNo;

@property (nonatomic, assign) double famt;


- (void)initWithDataDic :(NSDictionary *)dataDic;




@end