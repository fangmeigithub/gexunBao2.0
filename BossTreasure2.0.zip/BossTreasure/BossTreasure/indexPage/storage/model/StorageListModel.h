//
//  StorageListModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StorageListModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *msg;

- (void)initWithDic :(NSDictionary *)dataDic;

@end

@interface StorageListDataModel : NSObject

@property (nonatomic, copy) NSString *fbillNo;

@property (nonatomic, copy) NSString *fsourceType;

@property (nonatomic, copy) NSString *fcustomBillNo;

@property (nonatomic, copy) NSString *finvokingNo;

@property (nonatomic, copy) NSString *fwhName;

@property (nonatomic, copy) NSString *finputAt;

@property (nonatomic, copy) NSString *fpayName;

@property (nonatomic, copy) NSString *fstatu;

@property (nonatomic, copy) NSString *fkdEmpName;

@property (nonatomic, copy) NSString *fvendorname;

@property (nonatomic, copy) NSString *fywEmpName;

@property (nonatomic, copy) NSString *fbillCreateAt;

@property (nonatomic, copy) NSString *fitemTypeName;

@property (nonatomic, copy) NSString *fdtlFamt;


- (void)initWithDataDic :(NSDictionary *)dataDic;

@end


