//
//  StorageListModel.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "StorageListModel.h"

@implementation StorageListModel


- (void)initWithDic :(NSDictionary *)dataDic;
{
    [self setValuesForKeysWithDictionary:dataDic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
- (NSArray *)data
{
    NSMutableArray *dataArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in _data) {
        if (dic.count != 1) {
            StorageListDataModel *dataModel = [[StorageListDataModel alloc]init];
            [dataModel initWithDataDic:dic];
            [dataArray addObject:dataModel];
        }
    }
    return [NSArray arrayWithArray:dataArray];
}

@end


@implementation StorageListDataModel

- (void)initWithDataDic :(NSDictionary *)dataDic;{
    
    [self setValuesForKeysWithDictionary:dataDic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end