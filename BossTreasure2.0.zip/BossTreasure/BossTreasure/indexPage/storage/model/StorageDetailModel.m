//
//  StorageDetailModel.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "StorageDetailModel.h"


@implementation StorageDetailModel

- (void)initWithDic :(NSDictionary *)dataDic;
{
    [self setValuesForKeysWithDictionary:dataDic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
- (NSArray *)data
{
    NSMutableArray *dataArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in _data) {
        if (dic.count != 1) {
            StorageDetailDataModel *dataModel = [[StorageDetailDataModel alloc]init];
            [dataModel initWithDataDic:dic];
            [dataArray addObject:dataModel];
        }
    }
    return [NSArray arrayWithArray:dataArray];
}

@end

@implementation StorageDetailDataModel

- (void)initWithDataDic :(NSDictionary *)dataDic;{
    
    [self setValuesForKeysWithDictionary:dataDic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}


@end