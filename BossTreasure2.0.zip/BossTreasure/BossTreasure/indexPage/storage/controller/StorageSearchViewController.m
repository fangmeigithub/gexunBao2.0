//
//  StorageSearchViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "StorageSearchViewController.h"
#import "StorageSearchView.h"

extern NSString *UserId;
@interface StorageSearchViewController ()
<searchSomeParameterDelegate>
{
    StorageSearchView *storageSearchV;
}
@end

@implementation StorageSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    storageSearchV = [[StorageSearchView alloc]init];
    storageSearchV.frame = self.view.frame;
    [self.view addSubview:storageSearchV];
    storageSearchV.myDelegate = self;
     [self creatNavForSearchView:@"入库单查询"];
    
}
//提交搜索条件进行搜索
- (void)search
{
    NSDictionary *parameterDic = [storageSearchV backInterNetParameter];
    self.beforeViewController.subDataDic = parameterDic; //预留的公共接口
    self.beforeViewController.appearLoadTb = YES;
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
-(void)cancelButtonEvent
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark－－－－－－－－－－－－－－－－－－－searchSomeParameterDelegate delegate－－－－－－－－－－－－－－－－

- (void)searchSomeParameter:(NSString *)parameterKey
{
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithCapacity:0];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:0];
    dict[@"limit"] = @"1000";
    dict[@"start"] =[NSNumber numberWithInteger:0];
    dict[@"unionNo"] = [[MethodTool shareTool] getUserDefaults:@"unionNo"];
    dict[@"queryField"] = parameterKey;
    
    ShowHUD
    [[InterNetRequest shareRequest]informationSearch:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        if (Success) {
            
            [storageSearchV  interNetBackData:dataDic[@"data"]];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

@end
