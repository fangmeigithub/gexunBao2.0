//
//  StorageListViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "StorageListViewController.h"
#import "StorageSearchViewController.h"
#import "StorageListTableView.h"
#import "StorageDetailViewController.h"
#import "StorageListModel.h"
#import "UIScrollView+VORefresh.h"


extern NSString *UserId;
@interface StorageListViewController ()
{
    StorageListModel *storageListM;
    NSInteger page,start,AllPage;
    NSString  *loadStyle;
    NSMutableArray *orderListArray;
    StorageListTableView *storageListTbV;
    
}
@end

@implementation StorageListViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [super creatNavView:@"入库单列表" :NO :YES ];
    
    storageListTbV = [[StorageListTableView alloc]init];
    storageListTbV.superV  = self.view;
    [storageListTbV cellClickBlock:^(NSInteger cellIndex) {
        StorageDetailViewController *purchaseDetailsVC  = [[StorageDetailViewController alloc]init];
        purchaseDetailsVC.dataModel = [orderListArray objectAtIndex:cellIndex];
        [self.navigationController pushViewController:purchaseDetailsVC animated:YES];
    }];
    [storageListTbV addTopRefreshWithTarget:self action:@selector(headRefresh)];
    [storageListTbV addBottomRefreshWithTarget:self action:@selector(bottomRefreshing)];
    [[MethodTool shareTool] reflash:storageListTbV];
    
    orderListArray = [[NSMutableArray alloc]initWithCapacity:0];
    storageListM = [[StorageListModel alloc]init];
    page =1;
    start = 0;
    AllPage = 1;
    loadStyle = @"head";
    [self initData];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (self.appearLoadTb) {
        page = 1;
        [self initData];
    }
}
-(void)viewWillDisappear:(BOOL)animated
{
    self.appearLoadTb = NO;
    [super viewDidAppear:YES];
    
}

- (void)initData
{
    start = page>1?page*10:0;
    
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:self.subDataDic];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:page];
    dict[@"limit"] = @"10";
    dict[@"start"] =[NSNumber numberWithInteger:start];
    
    ShowHUD
    [[InterNetRequest shareRequest]getStorageList:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        [storageListTbV.topRefresh  endRefreshing];
        [storageListTbV.bottomRefresh  endRefreshing];
        if (Success) {
            [storageListM initWithDic:dataDic];
            //总页数
            for (NSDictionary *dic in dataDic[@"data"]) {
                if (dic.count==1) {
                    AllPage = [dic[@"totalCount"] integerValue]/10+1;
                }
            }
            if ([loadStyle isEqualToString:@"head"] ) {
                page = 1;
                [orderListArray removeAllObjects];
            }
            
            [orderListArray addObjectsFromArray:storageListM.data];
            storageListTbV.modelArray = orderListArray;
            [storageListTbV reloadData];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

//刷新
-(void)headRefresh
{
    loadStyle = @"head";
    [self initData];
}
//尾部刷新
-(void)bottomRefreshing
{
    page ++;
    if (page<=AllPage) {
        loadStyle = @"bottom";
        [self initData];
    }else{
        [storageListTbV.bottomRefresh  endRefreshing];
    }
}

//搜索页面
- (void)search
{
    StorageSearchViewController *StorageSearchVc = [[StorageSearchViewController alloc]init];
    StorageSearchVc.beforeViewController = self;
    [self.navigationController presentViewController:[[UINavigationController alloc]initWithRootViewController:StorageSearchVc] animated:YES completion:nil];
}

@end
