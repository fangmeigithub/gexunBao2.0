//
//  StorageSearchViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "StorageListViewController.h"

@interface StorageSearchViewController : BaseViewController
@property(strong,nonatomic)StorageListViewController *beforeViewController;

@end
