//
//  StorageDetailViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "StorageDetailModel.h"
#import "StorageListModel.h"

@interface StorageDetailViewController : BaseViewController

@property(strong,nonatomic)NSString *type;
@property(strong,nonatomic)StorageListDataModel *dataModel;
@end
