//
//  StorageDetailViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "StorageDetailViewController.h"
#import "StorageDetailTableView.h"

extern NSString *UserId;
@interface StorageDetailViewController ()
{
    StorageDetailModel *storageDeM;
    StorageDetailTableView *storageDetailTb;
}
@end

@implementation StorageDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"入库单详情" :NO :NO];
    
    self.sc.sd_layout
    .leftSpaceToView(self.view,Scale_X(8))
    .topSpaceToView(self.view,(64+Scale_Y(8)))
    .rightSpaceToView(self.view,Scale_X(8))
    .bottomSpaceToView(self.view,Scale_Y(8));
    
    self.sc.backgroundColor = RGB(236, 236, 236, 1);
    
    storageDetailTb = [[StorageDetailTableView alloc]init];
    storageDetailTb.superV  = self.view;
    [self initData];
}

- (void)initData
{
    
    storageDeM = [[StorageDetailModel alloc]init];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] = UserId;
    dict[@"fbillNo"] = self.dataModel.fbillNo;
    ShowHUD
    [[InterNetRequest shareRequest]getStorageDetails:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [storageDeM initWithDic:dataDic];
            storageDetailTb.dataModel = self.dataModel;
            storageDetailTb.modelArray = storageDeM.data;
            [storageDetailTb reloadData];
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

@end
