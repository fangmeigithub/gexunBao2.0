//
//  StorageDetailTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StorageDetailModel.h"

@interface StorageDetailTableViewCell : UITableViewCell
{
    UILabel  *allAcount;
    UILabel  *number;
    UILabel  *color;
    UILabel  *goodsCode;
    UILabel  *caidouCode;
    UILabel  *goodName;
    UILabel  *price;
    UILabel  *typeL;//花型
    UILabel  *sizeL;//尺码
}

@property(strong,nonatomic)StorageDetailDataModel *dataModel;

@end

