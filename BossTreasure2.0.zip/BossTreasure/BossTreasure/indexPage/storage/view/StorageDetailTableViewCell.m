//
//  StorageDetailTableViewCell.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "StorageDetailTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation StorageDetailTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView  *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(248, 248, 248, 1);
        [self.contentView addSubview:bgView];
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(2))
        .topSpaceToView(self.contentView,Scale_X(0))
        .rightSpaceToView(self.contentView,Scale_X(2))
        .bottomSpaceToView(self.contentView,Scale_Y(6));
        
        NSArray *titleArray = @[@"金额",@"数量",@"单价",@"颜色",@"货品编号",@"入库单号",@"货品名称",@"花型",@"尺码"];
        
        for (int i = 0; i<titleArray.count; i++) {
            
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :MEDIUM_FONT :blackC];
            [bgView addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(bgView,Scale_X(15))
            .topSpaceToView(bgView,Scale_Y(6+20*i))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
            [bgView addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(2))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(200))
            .heightIs(15);
            
            if (i==0) {
                allAcount = rightLabel;
            }else if (i==1){
                number = rightLabel;
            }else if (i==2){
                price = rightLabel;
            }
            else if (i==3){
                color = rightLabel;
            }else if (i==4){
                goodsCode = rightLabel;
            }else if (i==5){
                caidouCode = rightLabel;
            }else if (i==6){
                goodName = rightLabel;
            }else if (i==7){
                typeL = rightLabel;
            }else if (i==8){
                sizeL = rightLabel;
            }
        }
    }
    return self;
}

- (void)setDataModel:(StorageDetailDataModel *)dataModel
{
    allAcount.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.famt]] headFormat:@"："];
    number.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.fqty]] headFormat:@"："];
    color.text = [[[MethodTool shareTool] cleanData:dataModel.color] headFormat:@"："];
    goodsCode.text = [[[MethodTool shareTool] cleanData:dataModel.fitemNo] headFormat:@"："];
    caidouCode.text = [[[MethodTool shareTool] cleanData:dataModel.fpurNo] headFormat:@"："];
    goodName.text = [[[MethodTool shareTool] cleanData:dataModel.fitemName] headFormat:@"："];
    price.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.fprice]] headFormat:@"："];
    typeL.text = [[[MethodTool shareTool] cleanData:dataModel.style] headFormat:@"："];
    sizeL.text = [[[MethodTool shareTool] cleanData:dataModel.size] headFormat:@"："];
    
}
@end
