//
//  StorageDetailTableView.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StorageListModel.h"

@interface StorageDetailTableView : UITableView
<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *statusArray;
    NSArray *sendArray;
    UIView  *bgView;
}
@property(strong,nonatomic)NSArray *modelArray;
@property(strong,nonatomic)UIView *superV;
@property(strong,nonatomic)StorageListDataModel *dataModel;

@end