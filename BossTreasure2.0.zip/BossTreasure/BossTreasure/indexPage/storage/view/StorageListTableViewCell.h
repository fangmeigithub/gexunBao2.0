//
//  StorageListTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDLabelView.h"
#import "StorageListModel.h"
#import "NSString+CodeAndClean.h"

@interface StorageListTableViewCell : UITableViewCell
{
    UILabel  *fbillNoL;
    UILabel  *fsaleNoL;
    UILabel  *fywEmpNameL;
    
    UILabel  *statusLabel;
    UILabel  *finputAtL;
    UILabel  *fbillCreateAtL;
    
    NSArray *statusArray;
    NSArray *sendArray;
}

@property(strong,nonatomic)UIView *bgView;
@property(strong,nonatomic)StorageListDataModel *dataModel;
@end
