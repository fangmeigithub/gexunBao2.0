//
//  PurchaseDetailViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "PurchaseDetailModel.h"
#import "PurchaseListModel.h"

@interface PurchaseDetailViewController : BaseViewController

@property(strong,nonatomic)NSString *type;
@property(strong,nonatomic)PurchaseListDataModel *dataModel;
@end
