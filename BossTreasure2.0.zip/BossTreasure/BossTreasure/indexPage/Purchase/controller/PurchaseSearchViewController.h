//
//  PurchaseSearchViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "PurchaseListViewController.h"

@interface PurchaseSearchViewController : BaseViewController

@property(strong,nonatomic)PurchaseListViewController *beforeViewController;
@end
