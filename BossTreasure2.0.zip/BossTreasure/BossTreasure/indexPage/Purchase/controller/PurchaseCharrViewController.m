//
//  PurchaseCharrViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseCharrViewController.h"
#import "HYSegmentedControl.h"
#import "PurchaseChartView.h"
#import "PurchaseListViewController.h"

typedef enum {
    SegmenteLeft = 0,
    SegmenteRight = 1,
} Segmentetype;

extern NSString *UserId;
@interface PurchaseCharrViewController ()
<HYSegmentedControlDelegate>
{
    HYSegmentedControl *SegmentedControl;
    NSInteger Segmentedtype;
    PurchaseChartView *purchaseChartV ;
}
@end

@implementation PurchaseCharrViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"采购数据统计" :NO :NO];
    self.enablePanGesture = NO;
    
    //默认选中第一个 ，这个参数的设定为了省去多余的操作
    Segmentedtype = SegmenteLeft;
    
    //表试图
    purchaseChartV= [[PurchaseChartView alloc]init];
    purchaseChartV.superV = self.sc;
    [purchaseChartV clickType:^(NSString * formatStr) {
        
        PurchaseListViewController *purchaseListVC = [[PurchaseListViewController alloc]init];
        purchaseListVC.subDataDic = [self creatRequestDic:formatStr];//列表请求页
        [self.navigationController pushViewController:purchaseListVC animated:YES];
    }];
    
    [purchaseChartV swipe:^(NSInteger type) {
        
        if (Segmentedtype == type) {
            return;
        }
        Segmentedtype = type;
        if (type == SegmenteLeft) {//统计图将要往左滑动
            [SegmentedControl changeSegmentedControlWithIndex:SegmenteLeft];
        }
        else{
            [SegmentedControl changeSegmentedControlWithIndex:SegmenteRight];
        }
        [self initData];
    }];
    
    
    //切换试图
    SegmentedControl = [[HYSegmentedControl alloc]initWithOriginY:CGRectMake(0, 64, WIDTH, Scale_Y(40))
                                                           Titles:@[@"当天", @"当月"]
                                                                 :blackC
                                                                 :MainNavColor
                                                                 :[UIColor whiteColor]
                                                         delegate:self] ;
    
    [self.view addSubview:SegmentedControl];
    [self initData];
    
}

#pragma mark－－－－－－－－－－－－－－－－－－－hySegmentedControl delegate－－－－－－－－－－－－－－－－
- (void)hySegmentedControlSelectAtIndex:(NSInteger)index
{
    if (Segmentedtype == index) {
        return;
    }
    Segmentedtype = index;
    [self initData];
    
}
//网络请求
- (void)initData
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] =UserId;
    dict[@"queryFlag"] = Segmentedtype==SegmenteLeft?@"byDay":@"byMonth";
    
    ShowHUD
    [[InterNetRequest shareRequest]getPurchaseChart:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if(Success)
        {
            DMLog(@"odataDic:%@",dataDic);
            NSString *keyStr = Segmentedtype==SegmenteLeft?@"byDay":@"byMonth";
            purchaseChartV.dataDic = dataDic[keyStr];
            purchaseChartV.dayType = Segmentedtype==0?YES:NO;
            DMLog(@"orderV.dataDic:%@",purchaseChartV.dataDic);
        }
    } :^(NSError *error) {
        DismissHUD
        purchaseChartV.dayType = Segmentedtype==0?YES:NO;
    }];
}
//拼接列表页的部分请求参数
- (NSDictionary *)creatRequestDic :(NSString *)requestStr
{
    NSMutableDictionary *addDataDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    NSArray *messageArray = [requestStr componentsSeparatedByString:@":"];
    
    //不填fstatu 为全部的订单
    if ([messageArray[0] length]!=0) {
        addDataDic[@"fstatu"]= messageArray[0];
    }
    if ([ messageArray[1] isEqualToString:@"Day"]) {//按天查询
        
        addDataDic[@"fbillCreateAt_start"]= messageArray[2];
        addDataDic[@"fbillCreateAt_end"]= messageArray[2];
    }else{
        NSString *dateStr = [[MethodTool shareTool] getMonthBeginAndEndWith:messageArray[2]];
        NSArray *dateA = [dateStr componentsSeparatedByString:@":"];
        
        addDataDic[@"fbillCreateAt_start"]= dateA[0];//月的第一天
        addDataDic[@"fbillCreateAt_end"]= dateA[1];//月的最后一天
    }
    return [[NSDictionary alloc ]initWithDictionary:addDataDic];
}


@end
