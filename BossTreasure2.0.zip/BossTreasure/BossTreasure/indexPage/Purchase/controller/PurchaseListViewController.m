//
//  PurchaseListViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseListViewController.h"
#import "PurchaseSearchViewController.h"
#import "PurchaseListTableView.h"
#import "PurchaseDetailViewController.h"
#import "PurchaseListModel.h"
#import "UIScrollView+VORefresh.h"


extern NSString *UserId;
@interface PurchaseListViewController ()
{
    PurchaseListModel *purchaseListM;
    NSInteger page,start,AllPage;
    NSString  *loadStyle;
    NSMutableArray *orderListArray;
    PurchaseListTableView *purchaseListTbV;
    
}
@end

@implementation PurchaseListViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [super creatNavView:@"采购订单列表" :NO :YES ];
    
    purchaseListTbV = [[PurchaseListTableView alloc]init];
    purchaseListTbV.superV  = self.view;
    [purchaseListTbV cellClickBlock:^(NSInteger cellIndex) {
        PurchaseDetailViewController *purchaseDetailsVC  = [[PurchaseDetailViewController alloc]init];
        purchaseDetailsVC.dataModel = [orderListArray objectAtIndex:cellIndex];
        [self.navigationController pushViewController:purchaseDetailsVC animated:YES];
    }];
    [purchaseListTbV addTopRefreshWithTarget:self action:@selector(headRefresh)];
    [purchaseListTbV addBottomRefreshWithTarget:self action:@selector(bottomRefreshing)];
    [[MethodTool shareTool] reflash:purchaseListTbV];
    
    orderListArray = [[NSMutableArray alloc]initWithCapacity:0];
    purchaseListM = [[PurchaseListModel alloc]init];
    page =1;
    start = 0;
    AllPage = 1;
    loadStyle = @"head";
    [self initData];
    
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (self.appearLoadTb) {
        page = 1;
        [self initData];
    }
}
-(void)viewWillDisappear:(BOOL)animated
{
    self.appearLoadTb = NO;
    [super viewDidAppear:YES];
    
}

- (void)initData
{
    start = page>1?page*10:0;
    
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:self.subDataDic];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:page];
    dict[@"limit"] = @"10";
    dict[@"start"] =[NSNumber numberWithInteger:start];
    
    ShowHUD
    [[InterNetRequest shareRequest]getPurchaseList:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        [purchaseListTbV.topRefresh  endRefreshing];
        [purchaseListTbV.bottomRefresh  endRefreshing];
        if (Success) {
            [purchaseListM initWithDic:dataDic];
            //总页数
            for (NSDictionary *dic in dataDic[@"data"]) {
                if (dic.count==1) {
                    AllPage = [dic[@"totalCount"] integerValue]/10+1;
                }
            }
            if ([loadStyle isEqualToString:@"head"] ) {
                page = 1;
                [orderListArray removeAllObjects];
            }
            
            [orderListArray addObjectsFromArray:purchaseListM.data];
            purchaseListTbV.modelArray = orderListArray;
            [purchaseListTbV reloadData];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

//刷新
-(void)headRefresh
{
    loadStyle = @"head";
    [self initData];
}
//尾部刷新
-(void)bottomRefreshing
{
    page ++;
    if (page<=AllPage) {
        loadStyle = @"bottom";
        [self initData];
    }else{
        [purchaseListTbV.bottomRefresh  endRefreshing];
    }
}

//搜索页面
- (void)search
{
    PurchaseSearchViewController *orderSearchVc = [[PurchaseSearchViewController alloc]init];
    orderSearchVc.beforeViewController = self;
    [self.navigationController presentViewController:[[UINavigationController alloc]initWithRootViewController:orderSearchVc] animated:YES completion:nil];
}

@end
