//
//  PurchaseDetailViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseDetailViewController.h"
#import "PurchaseDetailTableView.h"

extern NSString *UserId;
@interface PurchaseDetailViewController ()
{
    PurchaseDetailModel *PurchaseDeM;
    PurchaseDetailTableView *PurchaseDetailTb;
}
@end

@implementation PurchaseDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"采购订单详情" :NO :NO];
    
    self.sc.sd_layout
    .leftSpaceToView(self.view,Scale_X(8))
    .topSpaceToView(self.view,(64+Scale_Y(8)))
    .rightSpaceToView(self.view,Scale_X(8))
    .bottomSpaceToView(self.view,Scale_Y(8));
    
    self.sc.backgroundColor = RGB(236, 236, 236, 1);
    
    PurchaseDetailTb = [[PurchaseDetailTableView alloc]init];
    PurchaseDetailTb.superV  = self.view;
    [self initData];
}

- (void)initData
{
    
    PurchaseDeM = [[PurchaseDetailModel alloc]init];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] = UserId;
    dict[@"fbillNo"] = self.dataModel.fbillNo;
    ShowHUD
    [[InterNetRequest shareRequest]getPurchaseDetails:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [PurchaseDeM initWithDic:dataDic];
            PurchaseDetailTb.dataModel = self.dataModel;
            PurchaseDetailTb.modelArray = PurchaseDeM.data;
            [PurchaseDetailTb reloadData];
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}
@end


