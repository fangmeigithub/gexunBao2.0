//
//  PurchaseSearchViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseSearchViewController.h"
#import "PurchaseSearchView.h"

extern NSString *UserId;
@interface PurchaseSearchViewController ()
<searchSomeParameterDelegate>
{
    PurchaseSearchView *purchaseSearchV;
}
@end

@implementation PurchaseSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    purchaseSearchV = [[PurchaseSearchView alloc]init];
    purchaseSearchV.frame = self.view.frame;
    [self.view addSubview:purchaseSearchV];
    purchaseSearchV.myDelegate = self;
   
    [self creatNavForSearchView:@"采购单查询"];
    
}
//提交搜索条件进行搜索
- (void)search
{
    NSDictionary *parameterDic = [purchaseSearchV backInterNetParameter];
    self.beforeViewController.subDataDic = parameterDic; //预留的公共接口
    self.beforeViewController.appearLoadTb = YES;
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
-(void)cancelButtonEvent
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark－－－－－－－－－－－－－－－－－－－searchSomeParameterDelegate delegate－－－－－－－－－－－－－－－－

- (void)searchSomeParameter:(NSString *)parameterKey
{
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithCapacity:0];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:0];
    dict[@"limit"] = @"1000";
    dict[@"start"] =[NSNumber numberWithInteger:0];
    dict[@"unionNo"] = [[MethodTool shareTool] getUserDefaults:@"unionNo"];
    dict[@"queryField"] = parameterKey;
    
    ShowHUD
    [[InterNetRequest shareRequest]informationSearch:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        if (Success) {
            
            [purchaseSearchV  interNetBackData:dataDic[@"data"]];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}


@end
