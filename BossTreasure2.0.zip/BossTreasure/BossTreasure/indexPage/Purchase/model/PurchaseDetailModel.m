//
//  PurchaseDetailModel.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseDetailModel.h"

@implementation PurchaseDetailModel

- (void)initWithDic :(NSDictionary *)dataDic;
{
    [self setValuesForKeysWithDictionary:dataDic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
- (NSArray *)data
{
    NSMutableArray *dataArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in _data) {
        if (dic.count != 1) {
            PurchaseDetailDataModel *dataModel = [[PurchaseDetailDataModel alloc]init];
            [dataModel initWithDataDic:dic];
            [dataArray addObject:dataModel];
        }
    }
    return [NSArray arrayWithArray:dataArray];
}

@end

@implementation PurchaseDetailDataModel

- (void)initWithDataDic :(NSDictionary *)dataDic;{
    
    [self setValuesForKeysWithDictionary:dataDic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}


@end