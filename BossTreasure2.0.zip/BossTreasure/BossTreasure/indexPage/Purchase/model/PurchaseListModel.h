//
//  PurchaseListModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PurchaseListModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *msg;

- (void)initWithDic :(NSDictionary *)dataDic;

@end


@interface PurchaseListDataModel : NSObject

@property (nonatomic, copy) NSString *fsaleNo;

@property (nonatomic, copy) NSString *fstatu;

@property (nonatomic, copy) NSString *fpurJhDate;

@property (nonatomic, copy) NSString *finStatu;

@property (nonatomic, copy) NSString *fywEmpName;

@property (nonatomic, copy) NSString *fkdEmpName;

@property (nonatomic, copy) NSString *fbillNo;

@property (nonatomic, copy) NSString *fbillCreateAt;

@property (nonatomic, copy) NSString *fvendorname;


- (void)initWithDataDic :(NSDictionary *)dataDic;



@end
