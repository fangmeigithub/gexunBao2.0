//
//  PurchaseDetailModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@class DataModel;
@interface PurchaseDetailModel : NSObject


@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, strong) NSArray *data;

- (void)initWithDic :(NSDictionary *)dataDic;

@end

@interface PurchaseDetailDataModel : NSObject

@property (nonatomic, assign) double fprice;

@property (nonatomic, copy) NSString *color;

@property (nonatomic, assign) double fqty;

@property (nonatomic, copy) NSString *fitemName;

@property (nonatomic, copy) NSString *fipOrdNo;

@property (nonatomic, copy) NSString *fitemNo;

@property (nonatomic, assign) double famt;


- (void)initWithDataDic :(NSDictionary *)dataDic;




@end