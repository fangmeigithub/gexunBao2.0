//
//  PurchaseSearchView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseView.h"
#import "FDAlertView.h"
#import "SearchBaseView.h"
#import "CustomAlertView.h"

@protocol searchSomeParameterDelegate <NSObject>

- (void)searchSomeParameter :(NSString *)parameterKey;

@end
@interface PurchaseSearchView : BaseView
<selfTappedDelegate,clickDelegate>
{
    FDAlertView *alert;
    CustomAlertView *contentView;
    UIScrollView  *sc;
    NSInteger  viewTag;
    NSArray *interNetBackDataAr;
    NSMutableArray *backParameterArray;
}
@property(assign,nonatomic)id<searchSomeParameterDelegate> myDelegate;
//返回查询参数
- (NSDictionary *)backInterNetParameter;
- (void)interNetBackData :(NSArray *)interNetBackDataArrray;
@end
