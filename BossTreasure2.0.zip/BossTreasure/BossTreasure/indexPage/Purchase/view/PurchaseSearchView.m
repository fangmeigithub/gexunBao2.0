//
//  PurchaseSearchView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseSearchView.h"

@implementation PurchaseSearchView

- (instancetype)init
{
    self = [super init];
    if (self) {
        //浅灰色背景
        self.backgroundColor = RGB(247, 248, 249, 1);
        
        NSArray *textArray = @[@"开始日期",@"结束日期",@"交货开始日期",@"交货结束日期",@"单据号",@"开单人",@"采购类型",@"入库状态",
                               @"货品类型",@"货品名称",@"采购员",@"供应商",@"组织机构",@"部门名称",@"物料清单",@"速查码",@"状态"];
        
        //是否有交互性
        NSArray *enableArray = @[@"NO",@"NO",@"NO",@"NO",@"YES",@"YES",@"NO",@"NO",
                                 @"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"YES",@"YES",@"NO",];
        //是否右侧有图片
        NSArray *haveRightImageArray = @[@"YES",@"YES",@"YES",@"YES",@"NO",@"NO",@"YES",@"YES",
                                         @"YES",@"YES",@"YES",@"YES",@"YES",@"YES",@"NO",@"NO",@"YES"];
        //是否是时间选择的图片
        NSArray *forTimeArray = @[@"YES",@"YES",@"YES",@"YES",@"NO",@"NO",@"NO",@"NO",
                                  @"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO"];
        
        sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, Scale_Y(6), WIDTH,Scale_Y(480))];
        sc.contentSize=CGRectMake(0, 0,WIDTH,Scale_Y(481)).size;
        sc.showsHorizontalScrollIndicator = NO;
        sc.showsVerticalScrollIndicator = NO;
        sc.backgroundColor = [UIColor clearColor];
        sc.scrollEnabled=YES;
        [self addSubview:sc];
        
        for (int i = 0; i<textArray.count; i++) {
            
            NSInteger x_For = i%2;
            NSInteger y_for = i/2;
            
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[textArray objectAtIndex:i] :14 :LikeBlackColor];
            [sc addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(sc,Scale_X(8+153*x_For))
            .topSpaceToView(sc,Scale_Y(80+30*y_for))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@":" :MEDIUM_FONT :1 :LikeBlackColor];
            [sc addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(0))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(4))
            .heightIs(15);
            
            SearchBaseView * searchBaseV = [[SearchBaseView alloc]initWithSetting:[[enableArray objectAtIndex:i] boolValue]
                                                                   haveRightImage:[[haveRightImageArray objectAtIndex:i] boolValue]
                                                                          forTime:[[forTimeArray objectAtIndex:i] boolValue]
                                                                                 :RECT(75+153*x_For, 77+30*y_for, 83, 20, 1)];
            [sc addSubview:searchBaseV];
            searchBaseV.tag = 5000+i;
            searchBaseV.myDelegate = self;
            
        }
        
        alert = [[FDAlertView alloc] init];
        contentView = [[CustomAlertView alloc]initWithFrame:RECT(100, 100, 220, 300, 1)];
        contentView.layer.cornerRadius = 5;
        contentView.mydelegate = self;
        alert.contentView = contentView;
        
        //收藏最终的请求参数
        backParameterArray = [[NSMutableArray alloc]initWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",@""
                              @"",@"",@"",@"",@"",@"",@"",@"",@"", nil];
        
    }
    return self;
}

#pragma mark－－－－－－－－－－－－－－－－－－－SearchBaseView delegate－－－－－－－－－－－－－－－－
//点击选择了某项查询按钮，或进行网络请求
- (void)selfTappedBack:(NSInteger)selfTag
{
    viewTag = selfTag-5000; //全局指向
    if (selfTag>=5000&&selfTag<5004) {
        [contentView showWithType:YES];
        [alert show];
    }
    else if (selfTag == 5006){//采购类型
        [contentView showWithType:NO];
        contentView.dataArray = @[@"正常采购",@"采购补数"];
        [alert show];
    }
    else if (selfTag == 5007){//入库状态
        
        [contentView showWithType:NO];
        contentView.dataArray = @[@"未入库",@"部分入库",@"入库完成"];
        [alert show];
    }
    else if (selfTag == 5016){//采购单状态
        [contentView showWithType:NO];
        contentView.dataArray = @[@"未审核",@"审核中",@"已审核",@"已作废"];
        [alert show];
    }
    else{
        NSArray *ParameterArray = @[@"",@"",@"",@"",@"",@"",@"",@"",
                                    @"byItemType",@"byItem",@"byBusiPerson",@"byVendor",@"byUnion",@"byDept",@"",@"",@""];
        [self.myDelegate searchSomeParameter:ParameterArray[viewTag]];
    }
}


//请求回来的数据
- (void)interNetBackData :(NSArray *)interNetBackDataArrray;
{
    interNetBackDataAr = interNetBackDataArrray;
    NSArray *ParameterDicNameKeyArray = @[@"",@"",@"",@"",@"",@"",@"",@"",
                                           @"fitemTypeName",@"fitemName",@"fempName",@"fvendorName",@"funionName",@"fdeptName",@"",@"",@""];
    
    NSMutableArray *contentViewDataArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in interNetBackDataAr) {
        //为保证安全，防止内部不是字典
        if (![dic isKindOfClass:[NSDictionary class]]) {
            return;
        }
        if (dic[ParameterDicNameKeyArray[viewTag]]) {
            [contentViewDataArray addObject:dic[ParameterDicNameKeyArray[viewTag]]];
        }
    }
    [contentView showWithType:NO];
    contentView.dataArray = [NSArray arrayWithArray:contentViewDataArray];
    [alert show];
    
}


#pragma mark－－－－－－－－－－－－－－－－－－－CustomAlertView delegate－－－－－－－－－－－－－－－－
//选定了弹框中的某一项
- (void)backSelectContext:(NSString *)backStr
{
    if (viewTag<4) {
        [backParameterArray replaceObjectAtIndex:viewTag withObject:backStr];
        
    }else if ((viewTag>=4)&&(viewTag!=6)&&(viewTag!=7)&&(viewTag!=16)) {
        NSArray *ParameterDicNameKeyArray = @[@"",@"",@"",@"",@"",@"",@"",@"",
                                              @"fitemTypeName",@"fitemName",@"fempName",@"fvendorName",@"funionName",@"fdeptName",@"",@"",@""];
        NSArray *ParameterDicIdKeyArray = @[@"",@"",@"",@"",@"",@"",@"",@"",
                                            @"fitemTypeNo",@"fitemNo",@"fempId",@"fvendorNo",@"funionId",@"fdeptNo",@"",@"",@""];

        for (NSDictionary *dic in interNetBackDataAr) {
            //为保证安全，防止内部不是字典
            if (![dic isKindOfClass:[NSDictionary class]]) {
                return;
            }
            if ([dic[ParameterDicNameKeyArray[viewTag]] isEqualToString:backStr]) {
                [backParameterArray replaceObjectAtIndex:viewTag withObject:dic[ParameterDicIdKeyArray[viewTag]]];
            }
            
        }
    }else{
        [backParameterArray replaceObjectAtIndex:viewTag withObject:[self getStatusForRequestValue:backStr]];
    }
    
    SearchBaseView *searchV = [sc viewWithTag:viewTag+5000];
    searchV.tFText = backStr;
    [alert hide];
    
}
- (void)backSelectContextCancel
{
    //弹框消失
    [alert hide];
}


//返回查询参数给列表页
- (NSDictionary *)backInterNetParameter;
{
    
    NSArray *parameterKeyArray = @[@"fbillCreateAt_start",@"fbillCreateAt_end",
                                   @"fpurJhDate_start",@"fpurJhDate_end",
                                   @"fbillNo",@"fkdEmpName",
                                   @"fpurType",@"finStatu",
                                   @"fitemTypeNo",@"fitemNo",
                                   @"fywEmpNo",@"fvendorno",
                                   @"funionId",@"fdeptNo",
                                   @"",@"ffindcode",
                                   @"fstatu"];//单据调用预留接口
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithCapacity:0];
    for (SearchBaseView *subV in sc.subviews) {
        if ([subV isKindOfClass:NSClassFromString(@"SearchBaseView")]) {
            if (subV.tFText.length !=0) {//有数值的查询条件
                dict[parameterKeyArray[subV.tag-5000]] = backParameterArray[subV.tag-5000];
            }
        }
        
    }
    return dict;
}

- (NSString *)getStatusForRequestValue :(NSString *)valueKey
{
    NSDictionary *dic = [[NSDictionary alloc]initWithObjects:@[@"0",@"1",@"2",@"3",@"0",@"1",@"2",@"0",@"1"] forKeys:@[@"未审核",@"审核中",@"已审核",@"已作废",@"未入库",@"部分入库",@"入库完成",@"正常采购",@"采购补数"]];
    
    //   NSLog(@"%@",[dic objectForKey:@"未审核"]) ;
    return dic[valueKey];
}


#pragma mark－－－－－－－－－－－－－－－－－－－UITextField delegate－－－－－－－－－－－－－－－－

- (void)UITextFieldBiganEdit:(UITextField *)tF
{
    UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
    CGRect frame=[tF convertRect: tF.bounds toView:window];
    
    /*
     *  frame.origin.y;  获取的是父视图的相对坐标  需要获取在屏幕上的位置
     */
    int offset = frame.origin.y  - (self.frame.size.height - 216)+60;
    
    [UIView animateWithDuration:0.2 animations:^{
        float width = self.frame.size.width;
        float height = self.frame.size.height;
        if(offset > 0)
        {
            CGRect rect = CGRectMake(0.0f, -offset,width,height);
            self.frame = rect;
        }
    }];
}
- (void)UITextFieldReturnEdit:(UITextField *)tF
{
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = CGRectMake(0.0f, 0.0f, self.frame.size.width, self.frame.size.height);
        self.frame = rect;
    }];
    [tF resignFirstResponder];
}


@end
