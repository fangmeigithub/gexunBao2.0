//
//  PurchaseChartView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseChartView.h"


@implementation PurchaseChartView


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        //初始化  Day/Month
        dayDateStr = [[MethodTool shareTool] getToDayDate];
        monthDateStr = [self subTimeStr:dayDateStr];
        //默认按天
        _dayType = YES;
        [self initSubV];
        
    }
    return self;
    
}
- (void)initSubV
{
    
    
    timeLabel = [[MethodTool shareTool] creatLabelWithAttribute:dayDateStr :BIG_FONT :1 :ORANGE_COLOR];
    [self addSubview:timeLabel];
    timeLabel.sd_layout.leftSpaceToView(self,15).topSpaceToView(self,(64+Scale_Y(60))).widthIs(Scale_X(120)).heightIs(Scale_X(15));
    
    
    
    colorArray = @[RGB(27, 173, 222, 1),
                            RGB(165, 205, 70, 1),
                            RGB(252, 194, 50, 1)];
    
    NSArray *items = @[[PNPieChartDataItem dataItemWithValue:20 color:colorArray[0] description:@"已入库"],
                       [PNPieChartDataItem dataItemWithValue:20 color:colorArray[1]  description:@"部分入库"],
                       [PNPieChartDataItem dataItemWithValue:40 color:colorArray[2]  description:@"未入库"],
                       ];
    
    pieChart = [[PNPieChart alloc] initWithFrame:CGRectMake(WIDTH/2-Scale_Y(90), 64+Scale_Y(70), Scale_Y(180), Scale_Y(180)) items:nil];
    pieChart.items = items;
    pieChart.descriptionTextColor = [UIColor whiteColor];
    pieChart.descriptionTextFont  = [UIFont fontWithName:@"Avenir-Medium" size:14.0];
    pieChart.descriptionTextShadowColor = [UIColor clearColor];
    pieChart.showAbsoluteValues = NO;
    pieChart.showOnlyValues = NO;
    //[pieChart strokeChart];
    pieChart.legendStyle = PNLegendItemStyleStacked;
    pieChart.legendFont = [UIFont boldSystemFontOfSize:12.0f];
    
    //下面的配图说明
    UIView *legend = [pieChart getLegendWithMaxWidth:200];
    [legend setFrame:CGRectMake(Scale_X(236), Scale_Y(290), legend.frame.size.width, legend.frame.size.height)];
    [self addSubview:legend];
    
    [self addSubview:pieChart];

    
    
    NSArray *titleArray = @[@"已接收的订单",@"已审核的订单",@"已发货的订单"];
    for (int i = 0; i<3; i++) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [colorArray objectAtIndex:i];
        bgView.layer.cornerRadius = 5;
        [self addSubview:bgView];
        bgView.sd_layout.leftSpaceToView(self,Scale_X(15)).topSpaceToView(pieChart,Scale_Y(40+55*i)).rightSpaceToView(self,Scale_X(15)).heightIs(Scale_Y(45));
        
        UIButton *actionB = [[MethodTool shareTool] creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
        [actionB addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        actionB.tag = 200+i;
        [bgView addSubview:actionB];
        actionB.sd_layout.leftSpaceToView(bgView,Scale_X(0)).topSpaceToView(bgView,Scale_Y(0)).rightSpaceToView(bgView,Scale_X(0)).bottomSpaceToView(bgView,0);
        
        UILabel *titleLabel = [[MethodTool shareTool] creatLabelWithAttribute:[titleArray objectAtIndex:i] :MEDIUM_FONT :1 :[UIColor whiteColor]];
        [bgView addSubview:titleLabel];
        titleLabel.sd_layout.leftSpaceToView(bgView,Scale_X(10)).topSpaceToView(bgView,Scale_Y(5)).widthIs(Scale_X(120)).heightIs(15);
        
        UILabel *numberLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"0" :BIG_FONT :1 :[UIColor whiteColor]];
        [bgView addSubview:numberLabel];
        numberLabel.sd_layout.leftSpaceToView(bgView,Scale_X(10)).bottomSpaceToView(bgView,Scale_Y(5)).widthIs(Scale_X(120)).heightIs(15);
        
        UIImageView *arrowV = [[MethodTool shareTool] creatImageWithAttribute:@"goto"];
        [bgView addSubview:arrowV];
        arrowV.sd_layout.centerYEqualToView(bgView).rightSpaceToView(bgView,Scale_Y(10)).widthIs(Scale_X(20)).heightIs(Scale_X(20));
        
        
        if (i == 0) {
            completeLbel = numberLabel;
        }
        else if (i == 1){
            inStoreCountL = numberLabel;
        }
        else{
            notInCountL = numberLabel;
        }
    }
    
    
    // 加上左右滑动的手势
    UISwipeGestureRecognizer *swiepLeftGeture = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRecpgnizer:)];
    [swiepLeftGeture setDirection: UISwipeGestureRecognizerDirectionLeft];
    [self addGestureRecognizer:swiepLeftGeture];
    
    UISwipeGestureRecognizer *swiepRightGeture = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRecpgnizer:)];
    [swiepRightGeture setDirection: UISwipeGestureRecognizerDirectionRight];
    [self addGestureRecognizer:swiepRightGeture];
    
}

- (void)clickType :(chartBlock )block;
{
    self.myBlock = block;
}
- (void)swipe :(swipeBlock )block;
{
    self.mySwipeBlock = block;
}

- (void)buttonClick :(UIButton *)sende
{
    NSString *buttonTag = @"";
    if (sende.tag==200) {
        buttonTag = @"";
    }else if (sende.tag==201){
        buttonTag = @"2";
    }else{
        //buttonTag = @"3";//已发货的状态还没加上
    }
    self.myBlock([NSString stringWithFormat:@"%@:%@:%@",buttonTag,_dayType?@"Day":@"Month",timeLabel.text]);
}

//滑动请求 当天和当月  本处的滑动跟新通过VC的请求后得到刷新
- (void)swipeRecpgnizer :(UISwipeGestureRecognizer *)sender
{
    if (sender.direction == UISwipeGestureRecognizerDirectionLeft) {
        self.mySwipeBlock(1);
    }
    else{
        self.mySwipeBlock(0);
    }
}

- (void)setSuperV:(UIView *)superV
{
    [superV addSubview:self];
    self.sd_layout
    .leftSpaceToView(superV,0)
    .topSpaceToView(superV,0)
    .rightSpaceToView(superV,0)
    .bottomSpaceToView(superV,0);
    
}
//为了布局页面
- (void)setDayType:(BOOL )dayType
{
    _dayType = dayType;
    [self selectData];
}


#pragma mark－－－－－－－－－－－－－－－－－－－tool method－－－－－－－－－－－－－－－－
//得到年－月
- (NSString *)subTimeStr:(NSString *)orginTimeStr
{
    NSArray *strArray =[orginTimeStr componentsSeparatedByString:@"-"];
    return [NSString stringWithFormat:@"%@-%@",strArray[0],strArray[1]];
}
//根据竖线的位置来筛选数据
- (void)selectData
{
    timeLabel.text = _dayType?dayDateStr:monthDateStr;
    
     NSString *completeLT = [[MethodTool shareTool] cleanData:self.dataDic[@"completeCount"]];
     NSString *inStoreCountLT = [[MethodTool shareTool] cleanData:self.dataDic[@"inStoreCount"]];
     NSString *notInCountLT = [[MethodTool shareTool] cleanData:self.dataDic[@"notInCount"]];
    
    completeLbel.text = [completeLT isEqualToString:@""]?@"0":completeLT;
    inStoreCountL.text = [inStoreCountLT isEqualToString:@""]?@"0":inStoreCountLT;
    notInCountL.text = [notInCountLT isEqualToString:@""]?@"0":notInCountLT;
    
    NSArray *itemsA = @[[PNPieChartDataItem dataItemWithValue:[completeLbel.text floatValue] color:colorArray[0] description:@"已入库"],
                       [PNPieChartDataItem dataItemWithValue:[inStoreCountL.text floatValue] color:colorArray[1]  description:@"部分入库"],
                       [PNPieChartDataItem dataItemWithValue:[notInCountL.text floatValue] color:colorArray[2]  description:@"未入库"],
                       ];
    pieChart.items = itemsA;
    [pieChart strokeChart];
    
    
}




@end
