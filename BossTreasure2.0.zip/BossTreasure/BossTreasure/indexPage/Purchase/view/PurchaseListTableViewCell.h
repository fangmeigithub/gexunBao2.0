//
//  PurchaseListTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDLabelView.h"
#import "PurchaseListModel.h"
#import "NSString+CodeAndClean.h"

@interface PurchaseListTableViewCell : UITableViewCell
{
    UILabel  *fbillNoL;
    UILabel  *fsaleNoL;
    UILabel  *fywEmpNameL;
    
    UILabel  *statusLabel;
    UILabel  *fvendornameL;
    UILabel  *fbillCreateAtL;
    
    NSArray *statusArray;
    NSArray *sendArray;
}

@property(strong,nonatomic)UIView *bgView;
@property(strong,nonatomic)PurchaseListDataModel *dataModel;
@end
