//
//  PurchaseChartView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/30.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseView.h"
#import "MoveViewInChartView.h"
#import "PNPieChartDataItem.h"
#import "PNPieChart.h"

typedef void(^chartBlock )(NSString * formatStr);
typedef void(^swipeBlock )(NSInteger type);

@interface PurchaseChartView : BaseView
{
    
    UILabel  *completeLbel;
    UILabel  *inStoreCountL;
    UILabel  *notInCountL;
    UILabel *timeLabel;
    NSString *dayDateStr,*monthDateStr;

    BOOL _dayType;
    NSInteger  lineViewIndex;
    
    PNPieChart *pieChart;
    NSArray *colorArray;
}
@property(copy,nonatomic)chartBlock myBlock;
@property(copy,nonatomic)swipeBlock mySwipeBlock;
@property(strong,nonatomic)UIView *superV;

@property(assign,nonatomic) BOOL dayType;
@property(strong,nonatomic)NSDictionary *dataDic;//数据值

- (void)clickType :(chartBlock )block;
- (void)swipe :(swipeBlock )block;

@end
