//
//  PurchaseDetailTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PurchaseDetailModel.h"

@interface PurchaseDetailTableViewCell : UITableViewCell
{
    UILabel  *allAcount;
    UILabel  *number;
    UILabel  *color;
    UILabel  *goodsCode;
    UILabel  *caidouCode;
    UILabel  *goodName;
    UILabel  *price;
}

@property(strong,nonatomic)PurchaseDetailDataModel *dataModel;

@end

