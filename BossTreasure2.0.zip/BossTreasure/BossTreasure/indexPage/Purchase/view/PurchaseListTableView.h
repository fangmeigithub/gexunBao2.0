//
//  PurchaseListTableView.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^cellClickBlock)(NSInteger cellIndex);
@interface PurchaseListTableView : UITableView
<UITableViewDelegate,UITableViewDataSource>

@property(copy,nonatomic)cellClickBlock cellClick;
@property(strong,nonatomic)UIView *superV;
@property(strong,nonatomic)NSArray *modelArray;


- (void)cellClickBlock :(cellClickBlock )bolck;


@end
