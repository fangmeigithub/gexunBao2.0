//
//  PurchaseListTableViewCell.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseListTableViewCell.h"

@implementation PurchaseListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.bgView = [UIView new];
        self.bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(248, 248, 248, 1);
        [self.contentView addSubview:self.bgView];
        
        self.bgView.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(2))
        .topSpaceToView(self.contentView,Scale_X(0))
        .rightSpaceToView(self.contentView,Scale_X(2))
        .bottomSpaceToView(self.contentView,Scale_Y(6));
        
        NSArray *titleArray = @[@"采购订单编号",@"销售订单编号"];
        statusArray = @[@"未审核",@"审核中",@"已审核",@"已作废"];
        sendArray = @[@"未入库",@"部分入库",@"入库完成"];
        
        for (int i = 0; i<2; i++) {
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :14 :blackC];
            [self.bgView addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(self.bgView,Scale_X(10))
            .topSpaceToView(self.bgView,Scale_Y(6+20*i))
            .widthIs(Scale_X(80))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
            [self.bgView addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(2))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(200))
            .heightIs(15);
            
            if (i==0) {
                fbillNoL = rightLabel;
            }
            else if (i == 1){
                fsaleNoL = rightLabel;
            }
            else if (i == 2){
                fywEmpNameL = rightLabel;
            }
        }
        
        statusLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :3 :ORANGE_COLOR];
        [self.bgView addSubview:statusLabel];
        statusLabel.sd_layout
        .rightSpaceToView(self.bgView,Scale_X(15))
        .topSpaceToView(self.bgView,Scale_Y(6))
        .widthIs(Scale_X(60))
        .heightIs(15);
        
        //下单日期
        UILabel *fywEmpNameLL = [[MethodTool shareTool] creatLabelWithAttribute:@"采购员" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:fywEmpNameLL];
        fywEmpNameLL.sd_layout
        .leftSpaceToView(self.bgView,Scale_X(10))
        .topSpaceToView(self.bgView,Scale_Y(8+20*2))
        .widthIs(Scale_X(40))
        .heightIs(15);
        
        
        fywEmpNameL = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:fywEmpNameL];
        fywEmpNameL.sd_layout
        .leftSpaceToView(fywEmpNameLL,Scale_X(0))
        .topEqualToView(fywEmpNameLL)
        .widthIs(Scale_X(100))
        .heightIs(15);
        
        
        //下单日期
        UILabel *fvendornameLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"供应商" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:fvendornameLabel];
        fvendornameLabel.sd_layout
        .leftSpaceToView(self.bgView,Scale_X(10))
        .topSpaceToView(self.bgView,Scale_Y(8+20*3))
        .widthIs(Scale_X(40))
        .heightIs(15);
        
        
        fvendornameL = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:fvendornameL];
        fvendornameL.sd_layout
        .leftSpaceToView(fvendornameLabel,Scale_X(0))
        .topEqualToView(fvendornameLabel)
        .widthIs(Scale_X(80))
        .heightIs(15);
        
        
        
        //交期
        UILabel *endTimeLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"下单日期" :MEDIUM_FONT :3 :blackC];
        [self.bgView addSubview:endTimeLabel];
        endTimeLabel.sd_layout
        .rightSpaceToView(self.bgView,Scale_X(80))
        .topEqualToView(fvendornameL)
        .widthIs(Scale_X(80))
        .heightIs(15);
        
        
        fbillCreateAtL = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:fbillCreateAtL];
        fbillCreateAtL.sd_layout
        .leftSpaceToView(endTimeLabel,Scale_X(0))
        .topEqualToView(endTimeLabel)
        .widthIs(Scale_X(80))
        .heightIs(15);
        
    }
    return self;
}

- (void)setDataModel:(PurchaseListDataModel *)dataModel
{
    fbillNoL.text = [[[MethodTool shareTool] cleanData:dataModel.fbillNo] headFormat:@"："];
    fsaleNoL.text = [[[MethodTool shareTool] cleanData:dataModel.fsaleNo] headFormat:@"："];
    fywEmpNameL.text = [[[MethodTool shareTool] cleanData:dataModel.fywEmpName] headFormat:@"："];
    if ([dataModel.fstatu intValue]==2) {
        statusLabel.text = [sendArray objectAtIndex:[dataModel.finStatu intValue]];
    }else
    {
        statusLabel.text = [statusArray objectAtIndex:[dataModel.fstatu intValue]];
    }
    fvendornameL.text = [[[MethodTool shareTool] cleanData:dataModel.fvendorname] headFormat:@"："];
    fbillCreateAtL.text = [[[MethodTool shareTool] cleanData:dataModel.fbillCreateAt] headFormat:@"："];
    if ((![fbillCreateAtL.text isEqualToString:@"：暂无数据"])&&([fbillCreateAtL.text length] !=0)) {
        fbillCreateAtL.textColor = REDCOLOR;
        fbillCreateAtL.attributedText = [[MethodTool shareTool] creatAttributedString:fbillCreateAtL.text :blackC :0 :1];
    }
    else{
        fbillCreateAtL.textColor = blackC;
    }
    
}


@end
