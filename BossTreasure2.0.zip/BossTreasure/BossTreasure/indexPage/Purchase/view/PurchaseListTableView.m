//
//  PurchaseListTableView.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PurchaseListTableView.h"
#import "PurchaseListTableViewCell.h"

@implementation PurchaseListTableView

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dataSource = self;
        self.delegate = self;
        self.backgroundColor = RGB(248, 248, 248, 1);
    }
    return self;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 94*NEWY;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return Scale_Y(25);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return self.modelArray.count;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(236, 236, 236, 1);
    view1.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).heightIs(Scale_Y(25));
    
    UILabel *allGoodsNumberLabel = [[MethodTool shareTool] creatLabelWithAttribute: [NSString stringWithFormat:@"当前订单数：%lu",(unsigned long)self.modelArray.count]  :MEDIUM_FONT :1 :ORANGE_COLOR];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.attributedText = [[MethodTool shareTool] creatAttributedString:[allGoodsNumberLabel text] :blackC :0 :6];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(10)).centerYEqualToView(view1).rightSpaceToView(view1,Scale_X(100)).heightIs(Scale_Y(20));
    return view1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    PurchaseListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[PurchaseListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    cell.dataModel = [self.modelArray objectAtIndex:indexPath.row];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    PurchaseListTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.bgView.backgroundColor = RGB(255, 246, 238, 1);
    self.cellClick(indexPath.row);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        cell.bgView.backgroundColor = [UIColor whiteColor];
    });
}

- (void)cellClickBlock :(cellClickBlock )bolck;
{
    self.cellClick = bolck;
}
- (void)setSuperV:(UIView *)superV
{
    [superV addSubview:self];
    self.sd_layout
    .leftSpaceToView(superV,0)
    .topSpaceToView(superV,64)
    .rightSpaceToView(superV,0)
    .heightIs(HEIGHT-64);
}

@end
