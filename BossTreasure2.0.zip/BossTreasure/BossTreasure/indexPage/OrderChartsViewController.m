//
//  OrderChartsViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderChartsViewController.h"
#import "HYSegmentedControl.h"
#import "OrderChartView.h"
#import "OrderListViewController.h"
#import "OrderChartModel.h"

typedef enum {
    SegmenteLeft = 0,
    SegmenteRight = 1,
} Segmentetype;


extern NSString *UserId;
@interface OrderChartsViewController ()
<HYSegmentedControlDelegate>
{
    HYSegmentedControl *SegmentedControl;
    NSInteger Segmentedtype;
    OrderChartView *orderV ;
}
@end

@implementation OrderChartsViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.enablePanGesture = NO;
    
    //默认选中第一个 ，这个参数的设定为了省去多余的操作
    Segmentedtype = SegmenteLeft;
   
    //表试图
    orderV= [[OrderChartView alloc]init];
    orderV.superV = self.sc;
    [orderV clickType:^(NSString * formatStr) {
        
        OrderListViewController *orderListVC = [[OrderListViewController alloc]init];
        orderListVC.subDataDic = [self creatRequestDic:formatStr];
        [self.navigationController pushViewController:orderListVC animated:YES];
    }];
    
    [orderV swipe:^(NSInteger type) {
        
        if (Segmentedtype == type) {
            return;
        }
        Segmentedtype = type;
        if (type == SegmenteLeft) {//统计图将要往左滑动
            [SegmentedControl changeSegmentedControlWithIndex:SegmenteLeft];
        }
        else{
            [SegmentedControl changeSegmentedControlWithIndex:SegmenteRight];
        }
        [self initData];
    }];
    
    
    //切换试图
    SegmentedControl = [[HYSegmentedControl alloc]initWithOriginY:CGRectMake(0, NavHeight, WIDTH, Scale_Y(40))
                                                           Titles:@[@"当天", @"当月"]
                                                                 :blackC
                                                                 :MainNavColor
                                                                 :[UIColor whiteColor]
                                                         delegate:self] ;
    
    [self.view addSubview:SegmentedControl];
     [super creatNavView:@"订单统计图" :NO:NO ];
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self initData];
}

#pragma mark－－－－－－－－－－－－－－－－－－－hySegmentedControl delegate－－－－－－－－－－－－－－－－
- (void)hySegmentedControlSelectAtIndex:(NSInteger)index
{
    if (Segmentedtype == index) {
        return;
    }
    Segmentedtype = index;
    [self initData];
  
}
//网络请求
- (void)initData
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] =UserId;
    dict[@"queryFlag"] = Segmentedtype==SegmenteLeft?@"byDay":@"byMonth";
    
    ShowHUD
    [[InterNetRequest shareRequest]getOrderChart:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if(Success)
        {
            DMLog(@"odataDic:%@",dataDic);
            OrderChartModel *orderChartmM = [[OrderChartModel alloc]init];
            orderV.dataDic = [orderChartmM selectDataWithDataDic:dataDic :Segmentedtype==0?YES:NO];
            orderV.dayType = Segmentedtype==0?YES:NO;
            DMLog(@"orderV.dataDic:%@",orderV.dataDic);
            [orderV layoutSubV];
        }
    } :^(NSError *error) {
        DismissHUD
        orderV.dayType = Segmentedtype==0?YES:NO;
    }];
}
 //拼接列表页的部分请求参数
- (NSDictionary *)creatRequestDic :(NSString *)requestStr
{
    NSMutableDictionary *addDataDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    NSArray *messageArray = [requestStr componentsSeparatedByString:@":"];
    
    //不填fstatu 为全部的订单
    if ([messageArray[0] length]!=0) {
        addDataDic[@"fstatu"]= messageArray[0];
    }
    if ([ messageArray[1] isEqualToString:@"Day"]) {//按天查询
        
         addDataDic[@"fbillCreateAt_start"]= messageArray[2];
         addDataDic[@"fbillCreateAt_end"]= messageArray[2];
    }else{
        NSString *dateStr = [[MethodTool shareTool] getMonthBeginAndEndWith:messageArray[2]];
        NSArray *dateA = [dateStr componentsSeparatedByString:@":"];

         addDataDic[@"fbillCreateAt_start"]= dateA[0];//月的第一天
         addDataDic[@"fbillCreateAt_end"]= dateA[1];//月的最后一天
    }
    return [[NSDictionary alloc ]initWithDictionary:addDataDic];
}



@end
