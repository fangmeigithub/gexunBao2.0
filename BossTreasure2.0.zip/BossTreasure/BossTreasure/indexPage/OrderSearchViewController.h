//
//  OrderSearchViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "OrderSearchView.h"
#import "OrderListViewController.h"

@interface OrderSearchViewController : BaseViewController
<UITextFieldDelegate,searchSomeParameterDelegate>
{
    OrderSearchView *searchV;
}

@property(strong,nonatomic)OrderListViewController *beforeViewController;

@end
