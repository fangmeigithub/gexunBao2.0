//
//  ContrastSOModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContrastSOModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *msg;

- (void)initWithDic :(NSDictionary *)dataDic;

@end

@interface ContrastSOModeltDataModel : NSObject


@property (nonatomic, copy) NSString *itemNo;

@property (nonatomic, copy) NSString *color;

@property (nonatomic, assign) double orderQty;

@property (nonatomic, copy) NSString *itemName;

@property (nonatomic, copy) NSString *orderNo;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, assign) double sendQty;

@property (nonatomic, assign) double unSendQty;




- (void)initWithDataDic :(NSDictionary *)dataDic;



@end