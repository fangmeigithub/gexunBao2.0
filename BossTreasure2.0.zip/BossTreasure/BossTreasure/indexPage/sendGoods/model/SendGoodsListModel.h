//
//  SendGoodsModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/6.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SendGoodsListModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *msg;

- (void)initWithDic :(NSDictionary *)dataDic;

@end

@interface SendGoodsListDataModel : NSObject


@property (nonatomic, copy) NSString *finvoiceTypeName;

@property (nonatomic, copy) NSString *ftel;

@property (nonatomic, copy) NSString *fwhName;

@property (nonatomic, copy) NSString *farinvStatu;

@property (nonatomic, copy) NSString *fstatu;

@property (nonatomic, copy) NSString *fywEmpName;

@property (nonatomic, copy) NSString *fbillNo;

@property (nonatomic, copy) NSString *ftpCode;

@property (nonatomic, copy) NSString *finvoiceReq;

@property (nonatomic, copy) NSString *fphEmpName;

@property (nonatomic, copy) NSString *fkdEmpName;

@property (nonatomic, copy) NSString *fcustname;

@property (nonatomic, copy) NSString *freceiver;

@property (nonatomic, copy) NSString *freceiverPhone;

@property (nonatomic, copy) NSString *fcustomBillNo;

@property (nonatomic, copy) NSString *fitemTypeName;

@property (nonatomic, copy) NSString *finvokingNo;

@property (nonatomic, copy) NSString *fbillCreateAt;

@property (nonatomic, copy) NSString *fdeptName;

@property (nonatomic, copy) NSString *freceiverAddress;


- (void)initWithDataDic :(NSDictionary *)dataDic;



@end