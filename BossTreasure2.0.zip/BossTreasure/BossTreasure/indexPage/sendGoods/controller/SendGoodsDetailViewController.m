//
//  SendGoodsDetailViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SendGoodsDetailViewController.h"
#import "SendGoodsDetailTableView.h"
#import "ContrastSendGoodsAndOrderViewController.h"

extern NSString *UserId;
@interface SendGoodsDetailViewController ()
{
    SendGoodsDetailModel *SendGoodsDeM;
    SendGoodsDetailTableView *SendGoodsDetailTb;
}
@end

@implementation SendGoodsDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"发货单详情" :NO :NO];
    [super addNewRightNavItem];
    
    self.sc.sd_layout
    .leftSpaceToView(self.view,Scale_X(8))
    .topSpaceToView(self.view,(64+Scale_Y(8)))
    .rightSpaceToView(self.view,Scale_X(8))
    .bottomSpaceToView(self.view,Scale_Y(8));
    
    self.sc.backgroundColor = RGB(236, 236, 236, 1);
    
    SendGoodsDetailTb = [[SendGoodsDetailTableView alloc]init];
    SendGoodsDetailTb.superV  = self.view;
    [self initData];
}
- (void)NewRightNavItemClick
{
    ContrastSendGoodsAndOrderViewController *contrastVC = [[ContrastSendGoodsAndOrderViewController alloc]init];
    contrastVC.fbillNo = self.dataModel.fbillNo;;
    [self.navigationController pushViewController:contrastVC animated:YES];
}
- (void)initData
{
    
    SendGoodsDeM = [[SendGoodsDetailModel alloc]init];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] = UserId;
    dict[@"fbillNo"] = self.dataModel.fbillNo;
    ShowHUD
    [[InterNetRequest shareRequest]getSendGoodsDetails:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [SendGoodsDeM initWithDic:dataDic];
            SendGoodsDetailTb.dataModel = self.dataModel;
            SendGoodsDetailTb.modelArray = SendGoodsDeM.data;
            [SendGoodsDetailTb reloadData];
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

@end
