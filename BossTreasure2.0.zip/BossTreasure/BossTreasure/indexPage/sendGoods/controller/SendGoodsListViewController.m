//
//  SendGoodsListViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SendGoodsListViewController.h"
#import "SendGoodsSearchViewController.h"
#import "SendGoodsListTableView.h"
#import "SendGoodsDetailViewController.h"
#import "SendGoodsListModel.h"
#import "UIScrollView+VORefresh.h"


extern NSString *UserId;
@interface SendGoodsListViewController ()
{
    SendGoodsListModel *sendGoodsListM;
    NSInteger page,start,AllPage;
    NSString  *loadStyle;
    NSMutableArray *orderListArray;
    SendGoodsListTableView *sendGoodsListTbV;
    
}
@end

@implementation SendGoodsListViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [super creatNavView:@"发货单列表" :NO :YES ];
    
    sendGoodsListTbV = [[SendGoodsListTableView alloc]init];
    sendGoodsListTbV.superV  = self.view;
    [sendGoodsListTbV cellClickBlock:^(NSInteger cellIndex) {
        SendGoodsDetailViewController *sendGoodsDetailsVC  = [[SendGoodsDetailViewController alloc]init];
        sendGoodsDetailsVC.dataModel = [orderListArray objectAtIndex:cellIndex];
        [self.navigationController pushViewController:sendGoodsDetailsVC animated:YES];
    }];
    [sendGoodsListTbV addTopRefreshWithTarget:self action:@selector(headRefresh)];
    [sendGoodsListTbV addBottomRefreshWithTarget:self action:@selector(bottomRefreshing)];
    [[MethodTool shareTool] reflash:sendGoodsListTbV];
    
    orderListArray = [[NSMutableArray alloc]initWithCapacity:0];
    sendGoodsListM = [[SendGoodsListModel alloc]init];
    page =1;
    start = 0;
    AllPage = 1;
    loadStyle = @"head";
    [self initData];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (self.appearLoadTb) {
        page = 1;
        [self initData];
    }
}
-(void)viewWillDisappear:(BOOL)animated
{
    self.appearLoadTb = NO;
    [super viewDidAppear:YES];
    
}

- (void)initData
{
    start = page>1?page*10:0;
    
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:self.subDataDic];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:page];
    dict[@"limit"] = @"10";
    dict[@"start"] =[NSNumber numberWithInteger:start];
    
    ShowHUD
    [[InterNetRequest shareRequest]getSendGoodsList:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        [sendGoodsListTbV.topRefresh  endRefreshing];
        [sendGoodsListTbV.bottomRefresh  endRefreshing];
        if (Success) {
            [sendGoodsListM initWithDic:dataDic];
            //总页数
            for (NSDictionary *dic in dataDic[@"data"]) {
                if (dic.count==1) {
                    AllPage = [dic[@"totalCount"] integerValue]/10+1;
                }
            }
            if ([loadStyle isEqualToString:@"head"] ) {
                page = 1;
                [orderListArray removeAllObjects];
            }
            
            [orderListArray addObjectsFromArray:sendGoodsListM.data];
            sendGoodsListTbV.modelArray = orderListArray;
            [sendGoodsListTbV reloadData];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

//刷新
-(void)headRefresh
{
    loadStyle = @"head";
    [self initData];
}
//尾部刷新
-(void)bottomRefreshing
{
    page ++;
    if (page<=AllPage) {
        loadStyle = @"bottom";
        [self initData];
    }else{
        [sendGoodsListTbV.bottomRefresh  endRefreshing];
    }
}

//搜索页面
- (void)search
{
    SendGoodsSearchViewController *SendGoodsSearchVc = [[SendGoodsSearchViewController alloc]init];
    SendGoodsSearchVc.beforeViewController = self;
    [self.navigationController presentViewController:[[UINavigationController alloc]initWithRootViewController:SendGoodsSearchVc] animated:YES completion:nil];
}

@end
