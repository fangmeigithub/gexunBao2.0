//
//  ContrastSendGoodsAndOrderViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "ContrastSendGoodsAndOrderViewController.h"
#import "ContrastSendGoodsAndOrderTableView.h"
#import "ContrastSOModel.h"

extern NSString *UserId;
@interface ContrastSendGoodsAndOrderViewController ()
{
    ContrastSOModel *ContrastSOM;
    ContrastSendGoodsAndOrderTableView *ContrastSendGoodsAndOrderTb;
}
@end

@implementation ContrastSendGoodsAndOrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"发货单与对应订单对比" :NO :NO];
    self.sc.sd_layout
    .leftSpaceToView(self.view,Scale_X(8))
    .topSpaceToView(self.view,(64+Scale_Y(8)))
    .rightSpaceToView(self.view,Scale_X(8))
    .bottomSpaceToView(self.view,Scale_Y(8));
    
    self.sc.backgroundColor = RGB(236, 236, 236, 1);
    
    ContrastSendGoodsAndOrderTb = [[ContrastSendGoodsAndOrderTableView alloc]init];
    ContrastSendGoodsAndOrderTb.superV  = self.view;
    [self initData];
    
}
- (void)initData
{
    
    ContrastSOM = [[ContrastSOModel alloc]init];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] = UserId;
    dict[@"fbillNo"] = self.fbillNo;
    ShowHUD
    [[InterNetRequest shareRequest]contrastSendGoodsAndOrder:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [ContrastSOM initWithDic:dataDic];
            ContrastSendGoodsAndOrderTb.modelArray = ContrastSOM.data;
            [ContrastSendGoodsAndOrderTb reloadData];
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}

@end
