//
//  SendGoodsSearchViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "SendGoodsListViewController.h"

@interface SendGoodsSearchViewController : BaseViewController
@property(strong,nonatomic)SendGoodsListViewController *beforeViewController;
@end
