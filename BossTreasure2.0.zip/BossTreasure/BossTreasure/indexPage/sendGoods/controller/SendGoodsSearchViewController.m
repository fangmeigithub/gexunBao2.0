//
//  SendGoodsSearchViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SendGoodsSearchViewController.h"
#import "SendGoodsSearchView.h"

extern NSString *UserId;
@interface SendGoodsSearchViewController ()
<searchSomeParameterDelegate>
{
    SendGoodsSearchView * sendGoodsSearchV;
}
@end

@implementation SendGoodsSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    sendGoodsSearchV = [[SendGoodsSearchView alloc]init];
    sendGoodsSearchV.frame = self.view.frame;
    [self.view addSubview:sendGoodsSearchV];
    sendGoodsSearchV.myDelegate = self;
    [super creatNavForSearchView:@"发货单查询"];
    
}
//提交搜索条件进行搜索
- (void)search
{
    NSDictionary *parameterDic = [sendGoodsSearchV backInterNetParameter];
    self.beforeViewController.subDataDic = parameterDic; //预留的公共接口
    self.beforeViewController.appearLoadTb = YES;
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
-(void)cancelButtonEvent
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark－－－－－－－－－－－－－－－－－－－searchSomeParameterDelegate delegate－－－－－－－－－－－－－－－－

- (void)searchSomeParameter:(NSString *)parameterKey
{
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithCapacity:0];
    dict[@"sysuserid"] = UserId;
    dict[@"page"] = [NSNumber numberWithInteger:0];
    dict[@"limit"] = @"1000";
    dict[@"start"] =[NSNumber numberWithInteger:0];
    dict[@"unionNo"] = [[MethodTool shareTool] getUserDefaults:@"unionNo"];
    dict[@"queryField"] = parameterKey;
    
    ShowHUD
    [[InterNetRequest shareRequest]informationSearch:dict :^(NSDictionary *dataDic) {
        DismissHUD
        DMLog(@"dataDic %@",dataDic);
        if (Success) {
            
            [sendGoodsSearchV  interNetBackData:dataDic[@"data"]];
            
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}
@end
