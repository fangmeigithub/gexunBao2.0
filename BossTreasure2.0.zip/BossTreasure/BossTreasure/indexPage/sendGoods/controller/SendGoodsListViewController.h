//
//  SendGoodsListViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface SendGoodsListViewController : BaseViewController

@property(retain,nonatomic)NSDictionary  *subDataDic;//一部分的请求参数
@property(assign,nonatomic)BOOL  appearLoadTb;//出现时重新加载表

@end
