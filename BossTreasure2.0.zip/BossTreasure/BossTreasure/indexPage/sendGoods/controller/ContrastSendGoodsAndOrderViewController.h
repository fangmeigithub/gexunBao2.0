//
//  ContrastSendGoodsAndOrderViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface ContrastSendGoodsAndOrderViewController : BaseViewController
@property(strong,nonatomic)NSString *fbillNo;
@end
