//
//  ContrastSendGoodsAndOrderTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContrastSOModel.h"

@interface ContrastSendGoodsAndOrderTableViewCell : UITableViewCell
{
    UILabel  *goodNameL;
    UILabel  *goodBillL;
    UILabel  *ordercodeL;
    UILabel  *colorL;
    UILabel  *allNumberL;
    UILabel  *sendedNumberL;
    UILabel  *anSenNumberL;
    UILabel  *sizeL;//尺码
}

@property(strong,nonatomic)ContrastSOModeltDataModel *dataModel;

@end
