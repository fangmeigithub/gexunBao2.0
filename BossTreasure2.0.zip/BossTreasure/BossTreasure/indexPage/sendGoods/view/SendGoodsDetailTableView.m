//
//  SendGoodsDetailTableView.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SendGoodsDetailTableView.h"
#import "SendGoodsDetailTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation SendGoodsDetailTableView

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dataSource = self;
        self.delegate = self;
        self.backgroundColor = RGB(248, 248, 248, 1);
    }
    return self;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.modelArray.count+1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section ==0 ) {
        return 415*NEWY;
    }
    else{
        return 200*NEWY;
    }
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section<=1) {
        return Scale_Y(25);
    }
    return 0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 1;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(236, 236, 236, 1);
    view1.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).heightIs(Scale_Y(25));
    
    UILabel *allGoodsNumberLabel = [[MethodTool shareTool] creatLabelWithAttribute:section==0?@"单据信息":@"商品信息"  :MEDIUM_FONT :1 :blackC];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(10)).centerYEqualToView(view1).rightSpaceToView(view1,Scale_X(100)).heightIs(Scale_Y(20));
    return view1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        UITableViewCell *cell = [[UITableViewCell alloc]init];
        [cell.contentView addSubview:bgView];
        return cell;
    }else{
        static NSString *cellIdentifier = @"firstCell";
        SendGoodsDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (!cell) {
            cell = [[SendGoodsDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        cell.tag = indexPath.row;
        cell.dataModel = [self.modelArray objectAtIndex:(indexPath.section-1)];
        return cell;
    }
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

- (void)setSuperV:(UIView *)superV
{
    [superV addSubview:self];
    self.sd_layout
    .leftSpaceToView(superV,0)
    .topSpaceToView(superV,64)
    .rightSpaceToView(superV,0)
    .heightIs(HEIGHT-64);
}

- (void)setDataModel:(SendGoodsListDataModel *)dataModel
{
    UITableViewCell *cell = [self cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    bgView = [UIView new];
    bgView.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:bgView];
    
    bgView.sd_layout
    .leftSpaceToView(cell.contentView,Scale_X(2))
    .topSpaceToView(cell.contentView,Scale_X(0))
    .rightSpaceToView(cell.contentView,Scale_X(2))
    .bottomSpaceToView(cell.contentView,Scale_Y(6));
    
    statusArray = @[@"：未审核",@"：审核中",@"：已审核",@"：已作废"];
    NSArray *finvoiceReqArray = @[@"否",@"是"];
    NSArray *titleArray = @[@"收货人地址",@"联系电话",@"配货员名称",@"收货人",@"业务员",@"开单人",@"自定义单据号",@"下单日期",@"托运号",
                            @"货品类型名称",@"销售发票生成",@"部门",@"发票类型名称",@"发货单号",@"发票要求",@"审核状态",@"客户名称",@"销售订单号",@"收货人电话",@"仓库",];
    
    NSArray *textArray = @[dataModel.freceiverAddress,
                           dataModel.ftel,
                           dataModel.fphEmpName,
                           dataModel.freceiver,
                           dataModel.fywEmpName,
                           dataModel.fkdEmpName,
                           dataModel.fcustomBillNo,
                           dataModel.fbillCreateAt,
                           dataModel.ftpCode,
                           dataModel.fitemTypeName,
                           dataModel.farinvStatu,
                           dataModel.fdeptName,
                           dataModel.finvoiceTypeName,
                           dataModel.fbillNo,
                           @"",
                           @"",
                           dataModel.fcustname,
                           dataModel.finvokingNo,
                           dataModel.freceiverPhone,
                           dataModel.fwhName];
    
    UILabel *status ;
    UILabel *fsourceTypeL;
    for (int i = 0; i<titleArray.count; i++) {
        
        FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :14 :blackC];
        [bgView addSubview:titlelabel];
        titlelabel.sd_layout
        .leftSpaceToView(bgView,Scale_X(15))
        .topSpaceToView(bgView,Scale_Y(6+20*i))
        .widthIs(Scale_X(75))
        .heightIs(15);
        
        UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:[[textArray objectAtIndex:i] headFormat:@"：" ] :MEDIUM_FONT :1 :i==15?ORANGE_COLOR:blackC];
        [bgView addSubview:rightLabel];
        rightLabel.sd_layout
        .leftSpaceToView(titlelabel,Scale_X(2))
        .topEqualToView(titlelabel)
        .widthIs(Scale_X(240))
        .heightIs(15);
        
        if (i==15) {
            status = rightLabel;
        }else if (i == 14){
            fsourceTypeL = rightLabel;
        }
    }
    status.text = [statusArray objectAtIndex:[dataModel.fstatu intValue]];
    status.attributedText = [[MethodTool shareTool] creatAttributedString:status.text :blackC :0 :1];
    fsourceTypeL.text = [[finvoiceReqArray objectAtIndex:[dataModel.finvoiceReq intValue]] headFormat:@"："];
}


@end