//
//  SendGoodsSearchView.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/1.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SendGoodsSearchView.h"

@implementation SendGoodsSearchView

- (instancetype)init
{
    self = [super init];
    if (self) {
        //浅灰色背景
        self.backgroundColor = RGB(247, 248, 249, 1);
        
        NSArray *textArray = @[@"开始日期",@"结束日期",@"发货单号",@"客户",@"收款方式",@"销售订单",
                               @"部门名称",@"业务员",@"配货员",@"仓库",@"状态",@"销售发票",@"组织机构",@"送货单号",
                               @"货品类型",@"货品名称",@"速查码"];
        
        //是否有交互性
        NSArray *enableArray = @[@"NO",@"NO",@"YES",@"NO",@"NO",@"YES",
                                 @"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"YES",@"NO",@"NO",@"YES"];
        //是否右侧有图片
        NSArray *haveRightImageArray = @[@"YES",@"YES",@"NO",@"YES",@"YES",@"NO",
                                         @"YES",@"YES",@"YES",@"YES",@"YES",@"YES",@"YES",@"NO",@"YES",@"YES",@"NO"];
        //是否是时间选择的图片
        NSArray *forTimeArray = @[@"YES",@"YES",@"NO",@"NO",@"NO",@"NO",
                                  @"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO"];
        
        sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, Scale_Y(6), WIDTH,Scale_Y(480))];
        sc.contentSize=CGRectMake(0, 0,WIDTH,Scale_Y(481)).size;
        sc.showsHorizontalScrollIndicator = NO;
        sc.showsVerticalScrollIndicator = NO;
        sc.backgroundColor = [UIColor clearColor];
        sc.scrollEnabled=YES;
        [self addSubview:sc];
        
        for (int i = 0; i<textArray.count; i++) {
            
            NSInteger x_For = i%2;
            NSInteger y_for = i/2;
            
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[textArray objectAtIndex:i] :14 :LikeBlackColor];
            [sc addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(sc,Scale_X(8+153*x_For))
            .topSpaceToView(sc,Scale_Y(80+30*y_for))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@":" :MEDIUM_FONT :1 :LikeBlackColor];
            [sc addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(0))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(4))
            .heightIs(15);
            
            SearchBaseView * searchBaseV = [[SearchBaseView alloc]initWithSetting:[[enableArray objectAtIndex:i] boolValue]
                                                                   haveRightImage:[[haveRightImageArray objectAtIndex:i] boolValue]
                                                                          forTime:[[forTimeArray objectAtIndex:i] boolValue]
                                                                                 :RECT(75+153*x_For, 77+30*y_for, 83, 20, 1)];
            [sc addSubview:searchBaseV];
            searchBaseV.tag = 5000+i;
            searchBaseV.myDelegate = self;
            
        }
        
        alert = [[FDAlertView alloc] init];
        contentView = [[CustomAlertView alloc]initWithFrame:RECT(100, 100, 220, 300, 1)];
        contentView.layer.cornerRadius = 5;
        contentView.mydelegate = self;
        alert.contentView = contentView;
        
        //收藏最终的请求参数
        backParameterArray = [[NSMutableArray alloc]initWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"", nil];
        
    }
    return self;
}

#pragma mark－－－－－－－－－－－－－－－－－－－SearchBaseView delegate－－－－－－－－－－－－－－－－
//点击选择了某项查询按钮，或进行网络请求
- (void)selfTappedBack:(NSInteger)selfTag
{
    viewTag = selfTag-5000; //全局指向
    if (selfTag>=5000&&selfTag<5002) {
        [contentView showWithType:YES];
        [alert show];
    }
    else if (selfTag == 5010){//状态
        [contentView showWithType:NO];
        contentView.dataArray = @[@"未审核",@"审核中",@"已审核",@"已作废"];
        [alert show];
    }
    else if (selfTag == 5011){//状态
        [contentView showWithType:NO];
        contentView.dataArray = @[@"未生成",@"已生成",@"已作废"];
        [alert show];
    }
    else{
        NSArray *ParameterArray = @[@"",@"",@"",@"byCust",@"byPayment",@"",@"byDept",@"byBusiPerson",@"byBusiPerson",
                                    @"byStorage",@"",@"",@"byUnion",@"",@"byItemType",@"byItem",@""];
        [self.myDelegate searchSomeParameter:ParameterArray[viewTag]];
    }
}


//请求回来的数据
- (void)interNetBackData :(NSArray *)interNetBackDataArrray;
{
    interNetBackDataAr = interNetBackDataArrray;
    NSArray *ParameterDicNameKeyArray = @[@"",@"",@"",@"fcustname",@"fpayName",@"",@"fdeptName",@"fempName",@"fempName",
                                          @"fwhname",@"",@"",@"funionName",@"",@"fitemTypeName",@"fitemName",@""];
    
    NSMutableArray *contentViewDataArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in interNetBackDataAr) {
        //为保证安全，防止内部不是字典
        if (![dic isKindOfClass:[NSDictionary class]]) {
            return;
        }
        if (dic[ParameterDicNameKeyArray[viewTag]]) {
            [contentViewDataArray addObject:dic[ParameterDicNameKeyArray[viewTag]]];
        }
    }
    [contentView showWithType:NO];
    contentView.dataArray = [NSArray arrayWithArray:contentViewDataArray];
    [alert show];
    
}


#pragma mark－－－－－－－－－－－－－－－－－－－CustomAlertView delegate－－－－－－－－－－－－－－－－
//选定了弹框中的某一项
- (void)backSelectContext:(NSString *)backStr
{
    if (viewTag<2) {
        [backParameterArray replaceObjectAtIndex:viewTag withObject:backStr];
        
    }
    else if ((viewTag!=10)&&(viewTag!=11)) {
        NSArray *ParameterDicNameKeyArray =  @[@"",@"",@"",@"fcustname",@"fpayName",@"",@"fdeptName",@"fempName",@"fempName",
                                               @"fwhname",@"",@"",@"funionName",@"",@"fitemTypeName",@"fitemName",@""];
        NSArray *ParameterDicIdKeyArray =  @[@"",@"",@"",@"fcustno",@"fpayNo",@"",@"fdeptNo",@"fempId",@"fempId",
                                             @"fwhno",@"",@"",@"funionId",@"",@"fitemTypeNo",@"fitemNo",@""];
        
        for (NSDictionary *dic in interNetBackDataAr) {
            //为保证安全，防止内部不是字典
            if (![dic isKindOfClass:[NSDictionary class]]) {
                return;
            }
            if ([dic[ParameterDicNameKeyArray[viewTag]] isEqualToString:backStr]) {
                [backParameterArray replaceObjectAtIndex:viewTag withObject:dic[ParameterDicIdKeyArray[viewTag]]];
            }
            
        }
    }else{
        [backParameterArray replaceObjectAtIndex:viewTag withObject:[self getStatusForRequestValue:backStr]];
    }
    
    SearchBaseView *searchV = [sc viewWithTag:viewTag+5000];
    searchV.tFText = backStr;
    [alert hide];
    
}
- (void)backSelectContextCancel
{
    //弹框消失
    [alert hide];
}


//返回查询参数给列表页
- (NSDictionary *)backInterNetParameter;
{
    
    NSArray *parameterKeyArray = @[@"fbillCreateAt_start",@"fbillCreateAt_end",
                                   @"fbillNo",@"fcustno",
                                   @"fpayNo",@"finvokingNo",
                                   @"fdeptNo",@"fywEmpNo",
                                   @"",@"fwhno",
                                   @"fstatu",@"farinvStatu",
                                   @"funionId",@"fdeliverNo",
                                   @"fitemTypeNo",@"fitemNo",
                                   @"ffindcode"];//单据调用预留接口
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithCapacity:0];
    for (SearchBaseView *subV in sc.subviews) {
        if ([subV isKindOfClass:NSClassFromString(@"SearchBaseView")]) {
            if (subV.tFText.length !=0) {//有数值的查询条件
                dict[parameterKeyArray[subV.tag-5000]] = backParameterArray[subV.tag-5000];
            }
        }
        
    }
    return dict;
}

- (NSString *)getStatusForRequestValue :(NSString *)valueKey
{
    NSDictionary *dic = [[NSDictionary alloc]initWithObjects:@[@"0",@"1",@"2",@"3",@"0",@"1",@"2"  ] forKeys:@[@"未审核",@"审核中",@"已审核",@"已作废",@"未生成",@"已生成",@"已作废"]];
    
    //   NSLog(@"%@",[dic objectForKey:@"未审核"]) ;
    return dic[valueKey];
}


#pragma mark－－－－－－－－－－－－－－－－－－－UITextField delegate－－－－－－－－－－－－－－－－

- (void)UITextFieldBiganEdit:(UITextField *)tF
{
    UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
    CGRect frame=[tF convertRect: tF.bounds toView:window];
    
    /*
     *  frame.origin.y;  获取的是父视图的相对坐标  需要获取在屏幕上的位置
     */
    int offset = frame.origin.y  - (self.frame.size.height - 216)+60;
    
    [UIView animateWithDuration:0.2 animations:^{
        float width = self.frame.size.width;
        float height = self.frame.size.height;
        if(offset > 0)
        {
            CGRect rect = CGRectMake(0.0f, -offset,width,height);
            self.frame = rect;
        }
    }];
}
- (void)UITextFieldReturnEdit:(UITextField *)tF
{
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = CGRectMake(0.0f, 0.0f, self.frame.size.width, self.frame.size.height);
        self.frame = rect;
    }];
    [tF resignFirstResponder];
}

@end
