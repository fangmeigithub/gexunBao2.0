//
//  ContrastSendGoodsAndOrderTableView.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "ContrastSendGoodsAndOrderTableView.h"
#import "ContrastSendGoodsAndOrderTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation ContrastSendGoodsAndOrderTableView

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dataSource = self;
        self.delegate = self;
        self.backgroundColor = RGB(248, 248, 248, 1);
    }
    return self;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 180*NEWY;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section<=1) {
        return Scale_Y(25);
    }
    return 0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 1;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(236, 236, 236, 1);
    view1.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).heightIs(Scale_Y(25));
    
    UILabel *allGoodsNumberLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"对比信息"  :MEDIUM_FONT :1 :blackC];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(10)).centerYEqualToView(view1).rightSpaceToView(view1,Scale_X(100)).heightIs(Scale_Y(20));
    return view1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    static NSString *cellIdentifier = @"firstCell";
    ContrastSendGoodsAndOrderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[ContrastSendGoodsAndOrderTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    cell.dataModel = [self.modelArray objectAtIndex:indexPath.row];
    return cell;

}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

- (void)setSuperV:(UIView *)superV
{
    [superV addSubview:self];
    self.sd_layout
    .leftSpaceToView(superV,0)
    .topSpaceToView(superV,64)
    .rightSpaceToView(superV,0)
    .heightIs(HEIGHT-64);
}


@end