//
//  SendGoodsListTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDLabelView.h"
#import "SendGoodsListModel.h"
#import "NSString+CodeAndClean.h"

@interface SendGoodsListTableViewCell : UITableViewCell
{
    UILabel  *fsendGoodsBillL;
    UILabel  *fcustonBill;
    UILabel  *fcustomsterL;
    
    UILabel  *statusLabel;
    UILabel  *fywL;
    UILabel  *fbillCreateAtL;
    
    NSArray *statusArray;
    NSArray *sendArray;
}

@property(strong,nonatomic)UIView *bgView;
@property(strong,nonatomic)SendGoodsListDataModel *dataModel;
@end
