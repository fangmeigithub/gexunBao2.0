//
//  ContrastSendGoodsAndOrderTableViewCell.m
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "ContrastSendGoodsAndOrderTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation ContrastSendGoodsAndOrderTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView  *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(248, 248, 248, 1);
        [self.contentView addSubview:bgView];
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(2))
        .topSpaceToView(self.contentView,Scale_X(0))
        .rightSpaceToView(self.contentView,Scale_X(2))
        .bottomSpaceToView(self.contentView,Scale_Y(6));
        
        NSArray *titleArray = @[@"货品名称",@"货品编号",@"订单号",@"颜色",@"订单总数",@"已发货数",@"未发货数",@"尺码"];
        
        for (int i = 0; i<titleArray.count; i++) {
            
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :14 :blackC];
            [bgView addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(bgView,Scale_X(15))
            .topSpaceToView(bgView,Scale_Y(6+20*i))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :i==6?ORANGE_COLOR:blackC];
            [bgView addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(2))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(200))
            .heightIs(15);
            
            if (i==0) {
                goodNameL = rightLabel;
            }else if (i==1){
                goodBillL = rightLabel;
            }else if (i==2){
                ordercodeL = rightLabel;
            }else if (i==3){
                colorL = rightLabel;
            }else if (i==4){
                allNumberL = rightLabel;
            }else if (i==5){
                sendedNumberL = rightLabel;
            }else if (i==6){
                anSenNumberL = rightLabel;
                
            }else if (i==7){
                sizeL = rightLabel;
            }
        }
    }
    return self;
}

- (void)setDataModel:(ContrastSOModeltDataModel *)dataModel
{
    goodNameL.text = [[[MethodTool shareTool] cleanData:dataModel.itemName] headFormat:@"："];
    goodBillL.text = [[[MethodTool shareTool] cleanData:dataModel.itemNo] headFormat:@"："];
    ordercodeL.text = [[[MethodTool shareTool] cleanData:dataModel.orderNo] headFormat:@"："];
    colorL.text = [[[MethodTool shareTool] cleanData:dataModel.color] headFormat:@"："];
    allNumberL.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.orderQty]] headFormat:@"："];
    sendedNumberL.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.sendQty]] headFormat:@"："];
    anSenNumberL.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.unSendQty]] headFormat:@"："];
    sizeL.text = [[[MethodTool shareTool] cleanData:dataModel.size] headFormat:@"："];
    
    anSenNumberL.attributedText = [[MethodTool shareTool] creatAttributedString:anSenNumberL.text :blackC :0 :1];
    
}
@end
