//
//  ContrastSendGoodsAndOrderTableView.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContrastSOModel.h"

@interface ContrastSendGoodsAndOrderTableView : UITableView
<UITableViewDelegate,UITableViewDataSource>

@property(strong,nonatomic)NSArray *modelArray;
@property(strong,nonatomic)UIView *superV;


@end