//
//  SendGoodsDetailTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/7/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SendGoodsDetailModel.h"

@interface SendGoodsDetailTableViewCell : UITableViewCell
{
    UILabel  *allAcount;
    UILabel  *number;
    UILabel  *color;
    UILabel  *goodsCode;
    UILabel  *sendGoodsCode;
    UILabel  *goodName;
    UILabel  *price;
    UILabel  *typeL;//花型
    UILabel  *sizeL;//尺码
}

@property(strong,nonatomic)SendGoodsDetailDataModel *dataModel;

@end
