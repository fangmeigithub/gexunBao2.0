//
//  MonitorViewController.h
//  sunCanteen
//
//  Created by Jonren on 15/4/16.
//  Copyright (c) 2015年 Jonren. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "PlaceDTO.h"
#import "Global.h"

static NSInteger const PAGECOUNT = 8;//页数
static NSInteger const PAGEVIEWCOUNT = 2;//每一页视频数量(暂时数量固定，未做修改方法，请勿修改)


@class VideoWnd;

@interface MonitorViewController : BaseViewController
<UIScrollViewDelegate>
{
    UIScrollView *myScrollView; // 水平ScrollView
    CGFloat originY;
    CGFloat viewWidth;
    CGFloat viewHeight;
    int lastPage;
    int currentPage;
    UIView *scrollCurrentView[PAGECOUNT];
    VideoWnd *viewPlay[PAGECOUNT * PAGEVIEWCOUNT];
    
    CGRect origanRect;
    UIView *origanSuperV;
    UILabel *rightNavLabel;
}

@property (nonatomic) LLONG lPlayHandle0;
@property (nonatomic) LLONG lPlayHandle1;
@property (nonatomic) LLONG lPlayHandle2;
@property (nonatomic) LLONG lPlayHandle3;
@property (nonatomic) LLONG lPlayHandle4;
@property (nonatomic) LLONG lPlayHandle5;
@property (nonatomic) LLONG lPlayHandle6;
@property (nonatomic) LLONG lPlayHandle7;
@property (nonatomic) LLONG lPlayHandle8;
@property (nonatomic) LLONG lPlayHandle9;
@property (nonatomic) LLONG lPlayHandle10;
@property (nonatomic) LLONG lPlayHandle11;
@property (nonatomic) LLONG lPlayHandle12;
@property (nonatomic) LLONG lPlayHandle13;
@property (nonatomic) LLONG lPlayHandle14;
@property (nonatomic) LLONG lPlayHandle15;

@property (nonatomic) LONG playPort0;
@property (nonatomic) LONG playPort1;
@property (nonatomic) LONG playPort2;
@property (nonatomic) LONG playPort3;
@property (nonatomic) LONG playPort4;
@property (nonatomic) LONG playPort5;
@property (nonatomic) LONG playPort6;
@property (nonatomic) LONG playPort7;
@property (nonatomic) LONG playPort8;
@property (nonatomic) LONG playPort9;
@property (nonatomic) LONG playPort10;
@property (nonatomic) LONG playPort11;
@property (nonatomic) LONG playPort12;
@property (nonatomic) LONG playPort13;
@property (nonatomic) LONG playPort14;
@property (nonatomic) LONG playPort15;

@property (strong, nonatomic) PlaceDTO *place; // 传递过来的数据（包含IP、端口、用户名和密码）

- (id)initWithPlace:(PlaceDTO *)place;


@end
