//
//  PlaceDTO.h
//  sunCanteen
//
//  Created by Jonren on 15/6/2.
//  nonatomicright (c) 2015年 Jonren. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlaceDTO : NSObject

@property (nonatomic, copy) NSString *faddr;
@property (nonatomic, copy) NSString *fdeptName;
@property (nonatomic, copy) NSString *fdeptNo;
@property (nonatomic, assign) int fenabled;
@property (nonatomic, copy) NSString *ffindCode;
@property (nonatomic, copy) NSString *fprincipal1;
@property (nonatomic, copy) NSString *fprincipal1Phone;
@property (nonatomic, copy) NSString *fprincipal2 ;
@property (nonatomic, copy) NSString *fprincipal2Phone;
@property (nonatomic, copy) NSString *fprincipal3;
@property (nonatomic, copy) NSString *fprincipal3Phone;
@property (nonatomic, copy) NSString *fprincipal4;
@property (nonatomic, copy) NSString *fprincipal4Phone;
@property (nonatomic, copy) NSString *fprincipal5;
@property (nonatomic, copy) NSString *fprincipal5Phone;
@property (nonatomic, copy) NSString *fprincipalPicPath1;
@property (nonatomic, copy) NSString *fprincipalPicPath2;
@property (nonatomic, copy) NSString *fprincipalPicPath3;
@property (nonatomic, copy) NSString *fprincipalPicPath4;
@property (nonatomic, copy) NSString *fprincipalPicPath5;
@property (nonatomic, copy) NSString *fprincipalPost1;
@property (nonatomic, copy) NSString *fprincipalPost2;
@property (nonatomic, copy) NSString *fprincipalPost3;
@property (nonatomic, copy) NSString *fprincipalPost4;
@property (nonatomic, copy) NSString *fprincipalPost5;
@property (nonatomic, copy) NSString *frefectoryId;
@property (nonatomic, copy) NSString *frefectoryName;
@property (nonatomic, assign) int frefectoryType;
@property (nonatomic, copy) NSString *fremark;
@property (nonatomic, copy) NSString *fschoolId;
@property (nonatomic, copy) NSString *fschoolName;
@property (nonatomic, copy) NSString *rpdept;
@property (nonatomic, copy) NSString *school;

@property (nonatomic, copy) NSString *fip;
@property (nonatomic, copy) NSString *fserPort;
@property (nonatomic, copy) NSString *fuser;
@property (nonatomic, copy) NSString *fpwd;

- (id)initWithFip:(NSString *)fip fserPort:(NSString *)fserPort fuser:(NSString *)fuser fpwd:(NSString *)fpwd;


@end
