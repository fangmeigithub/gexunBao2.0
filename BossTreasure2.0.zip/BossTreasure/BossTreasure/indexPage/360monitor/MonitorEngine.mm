//
//  MonitorEngine.m
//  sunCanteen
//
//  Created by Jonren on 16/4/26.
//  Copyright © 2016年 Jonren. All rights reserved.
//

#import "MonitorEngine.h"
#import "PlaceDTO.h"

@implementation MonitorEngine

+ (bool)isValidIP:(NSString *)ipStr {
    const char* ip = [ipStr cStringUsingEncoding:NSUTF8StringEncoding];
    // check invalid char
    int temp = 0;
    for (int i = 0; i < strlen(ip); i++) {
        // <1 or > 9,invalid char
        temp = (int)ip[i];
        if ((temp >= 48 && temp <= 57) || temp == 46) {
            continue;
        }else {
            return false;
        }
    }
    
    int n;
    unsigned int a, b, c, d;
    if(strlen(ip) <= 15 &&
       sscanf(ip, "%3u.%3u.%3u.%3u%n", &a, &b, &c, &d, &n) >= 4
       && n == static_cast<int>(strlen(ip))) {
        return (a > 0 && a <= 255 && b <= 255 && c <= 255 && d <= 255 && d > 0) || (a == 0 && b== 0 && c == 0 && d == 0);
    }
    return false;
}


+ (void)saveLoginInfoWith:(PlaceDTO *)place {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSArray *array = [NSArray arrayWithObjects:place.fip, place.fuser,
                      place.fpwd, place.fserPort, nil];
    NSLog(@"Save login info:%@, %@, %@, %@", array[0], array[1],
             array[2], array[3]);
    [userDefaults setObject:array forKey:@"userInfo"];
    [userDefaults synchronize];
}


@end
