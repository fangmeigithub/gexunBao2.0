//
//  MonitorViewController.m
//  sunCanteen
//
//  Created by Jonren on 15/4/16.
//  Copyright (c) 2015年 Jonren. All rights reserved.
//

#import "MonitorViewController.h"

#import "IPParser.h"
#import "playEx.h"
#import "fstream"
#import "string"
#import "VideoWnd.h"
#import "scopeguard.h"
#import "MonitorEngine.h"

#define ScreenWidth  [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define NavBarHeight 64.0f
#define TabBarHeight 49.0f


/**
 *  real play data callback
 */
static std::ofstream s_ofile;

void CALLBACK realDataCallback0(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort0, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback1(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort1, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback2(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort2, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback3(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort3, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback4(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort4, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback5(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort5, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback6(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort6, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback7(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort7, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback8(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort8, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback9(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort9, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback10(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort10, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback11(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort11, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback12(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort12, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback13(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort13, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback14(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort14, pBuffer, dwBufSize);
}
void CALLBACK realDataCallback15(LLONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, LDWORD dwUser)
{
    static MonitorViewController* pSelf = (__bridge MonitorViewController*)(void*)dwUser;
    PLAY_InputData(pSelf.playPort15, pBuffer, dwBufSize);
}


void CALLBACK cbDemuxDecCBFun(LONG nPort,char * pBuf, LONG nSize,void * pParam,void* pReserved, void* pUserData)
{
    DemuInfoEx* pframeInfo = (DemuInfoEx*)pReserved;
    if (*(BOOL*)pUserData) {
        s_ofile.write(pframeInfo->pBody, pframeInfo->nBodyLen);
    }
}
/************************************************************/


@interface MonitorViewController ()

@end

@implementation MonitorViewController {
    DH_RealPlayType _rType;
}

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _rType = DH_RType_Realplay_1;//枚举类型
        
        _playPort0 = 101;
        _playPort1 = 102;
        _playPort2 = 103;
        _playPort3 = 104;
        _playPort4 = 105;
        _playPort5 = 106;
        _playPort6 = 107;
        _playPort7 = 108;
        _playPort8 = 109;
        _playPort9 = 110;
        _playPort10 = 111;
        _playPort11 = 112;
        _playPort12 = 113;
        _playPort13 = 114;
        _playPort14 = 115;
        _playPort15 = 116;
        NSLog(@"_playPort: %d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d", _playPort0, _playPort1, _playPort2, _playPort3, _playPort4, _playPort5, _playPort6, _playPort7, _playPort8, _playPort9, _playPort10, _playPort11, _playPort12, _playPort13, _playPort14, _playPort15);
    }
    return self;
}

- (id)initWithPlace:(PlaceDTO *)place {
    self = [super init];
    if (self) {
        self.place = place;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor blackColor];
    
    currentPage = 1;
    [super creatNavView:@"食堂监控" :NO :NO];
    rightNavLabel = [[MethodTool shareTool] creatLabelWithAttribute:[NSString stringWithFormat:@"%d/8",currentPage] :BIG_FONT :3 :[UIColor whiteColor]];
    rightNavLabel.frame = RECT(1, 28, 80, 17,1);
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightNavLabel];
    
    [self initData];
    [self initSubviews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    ShowHUD;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loginExAt];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    //停止当前正在播放的监控
    [self stopViewOnPage:currentPage];
    [self.navigationController popViewControllerAnimated:NO];
}


#pragma mark - init

- (void)initSubviews {
    
    myScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 66, ScreenWidth, viewHeight*2+10)];
    myScrollView.pagingEnabled = YES;
    myScrollView.delegate = self;
    [myScrollView setContentSize:CGSizeMake(ScreenWidth * PAGECOUNT, 0)];
    [self.view addSubview:myScrollView];
    //UIWindow
    for (int i = 0; i < PAGECOUNT; i ++) {
        scrollCurrentView[i] = [[UIView alloc] init];
        scrollCurrentView[i].backgroundColor = [UIColor clearColor];
        scrollCurrentView[i].frame = CGRectMake(ScreenWidth * i, originY, ScreenWidth, viewHeight*2+10);
        [myScrollView addSubview:scrollCurrentView[i]];
        
        for (int j = PAGEVIEWCOUNT * i; j < PAGEVIEWCOUNT * (i + 1); j ++) {
            
            viewPlay[j] = [[VideoWnd alloc] init];
            viewPlay[j].backgroundColor = [UIColor clearColor];
            [scrollCurrentView[i] addSubview:viewPlay[j]];
            int m = j % PAGEVIEWCOUNT;
            viewPlay[j].frame = CGRectMake((m / 2) * viewWidth+2.5, (m % 2) * (viewHeight+5), viewWidth, viewHeight);
            
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.tag = j;
            button.selected = NO;
            button.frame = CGRectMake(0, 0, viewWidth, viewHeight);
            [button setBackgroundColor:[UIColor clearColor]];
            [button addTarget:self action:@selector(frameChange:) forControlEvents:UIControlEventTouchUpInside];
            [viewPlay[j] addSubview:button];
        }
    }
}

- (void)initData {
    NSLog(@"ip:%@\nport:%@\nuser:%@\npwd:%@", _place.fip, _place.fserPort, _place.fuser, _place.fpwd);
    viewWidth = ScreenWidth-5 ;
    originY = 10;
    CGFloat MplayViewHeight = ScreenHeight - NavBarHeight - TabBarHeight - originY * 2;
    viewHeight = MplayViewHeight / 2+20;
}


#pragma mark - login
- (void)loginExAt {
    char* loginIP;
    WORD loginPort;
    int nSpecCap = 0;

    loginIP = (char*)[_place.fip UTF8String];
    loginPort = [_place.fserPort intValue];
    int nError = 0;
    NET_DEVICEINFO devInfo = {};
    LLONG lLoginID = CLIENT_LoginEx(loginIP, loginPort, (char*)[_place.fuser UTF8String], (char*)[_place.fpwd UTF8String], nSpecCap, NULL, &devInfo, &nError);
    memset(&g_sysAttr, 0, sizeof(g_sysAttr));
    //memset(&g_devEnableInfo, 0, sizeof(g_devEnableInfo));
    
    g_loginID = lLoginID;
    NSLog(@"g_loginID: %ld", g_loginID);
    dispatch_async(dispatch_get_main_queue(), ^{
        [MonitorEngine saveLoginInfoWith:_place];
        g_nChannel = 0;
        [self onPlayWithPort:_playPort0 onView:viewPlay[0]];
        g_nChannel = 1;
        [self onPlayWithPort:_playPort1 onView:viewPlay[1]];
//        [MBProgressHUD hideHUDForView:scrollCurrentView[0]];
    });
    int retLen = 0;
    DWORD dwRetLen = 0;
    __NET_RUN(ALERT(_L(@"fail to retieve critical info, please re-login")); return, CLIENT_GetDevConfig, g_loginID, DH_DEV_DEVICECFG, 0, &g_sysAttr, sizeof(g_sysAttr), &dwRetLen, g_nWaitTime);
    NET_DEV_CHN_COUNT_INFO chnCount = {sizeof(chnCount), {sizeof(chnCount.stuVideoIn)}, {sizeof(chnCount.stuVideoOut)}};
    __NET_RUN(ALERT(_L(@"fail to retieve critical info, please re-login")); return, CLIENT_QueryDevState, g_loginID, DH_DEVSTATE_DEV_CHN_COUNT, (char*)&chnCount, sizeof(chnCount), &retLen, g_nWaitTime);
    g_ChannelCount = chnCount.stuVideoIn.nMaxTotal;
    NSLog(@"所有通道数：%d", g_ChannelCount);
}


#pragma mark - play
- (void)onPlayWithPort:(LONG)playPort onView:(VideoWnd *)view {
    NSLog(@"g_nChannel: %zd, playPort: %zd", g_nChannel, playPort);
    PLAY_RUN(PLAY_OpenStream, playPort, nil, 0, 300*1024);
    ScopeGuard sgCloseStream = MakeGuard(PLAY_CloseStream, playPort);
    PLAY_RUN(PLAY_Play, playPort, (__bridge void*)view);
    ScopeGuard sgStopPlay = MakeGuard(PLAY_Stop, playPort);
//    PLAY_RUN(PLAY_PlaySoundShare, playPort);
//    ScopeGuard sgStopSound = MakeGuard(PLAY_StopSoundShare, playPort);
    
    LLONG playHandle = CLIENT_RealPlayEx(g_loginID, g_nChannel, NULL, _rType);
    if (!playHandle) {
        ALERT_ERROR(CLIENT_RealPlay);
        NETSDK_ERROR(CLIENT_RealPlay);
         DismissHUD
        return;
    }
    ScopeGuard sgStopRealPlay = MakeGuard(CLIENT_StopRealPlay, playHandle);
    switch (g_nChannel) {
        case 0: {
            self.lPlayHandle0 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback0, (LDWORD)self);
              DismissHUD
        }break;
        case 1: {
            self.lPlayHandle1 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback1, (LDWORD)self);
              DismissHUD
        }break;
        case 2: {
            self.lPlayHandle2 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback2, (LDWORD)self);
              DismissHUD
        }break;
        case 3: {
            self.lPlayHandle3 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback3, (LDWORD)self);
              DismissHUD
        }break;
        case 4: {
            self.lPlayHandle4 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback4, (LDWORD)self);
              DismissHUD
        }break;
        case 5: {
            self.lPlayHandle5 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback5, (LDWORD)self);
              DismissHUD
        }break;
        case 6: {
            self.lPlayHandle6 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback6, (LDWORD)self);
              DismissHUD
        }break;
        case 7: {
            self.lPlayHandle7 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback7, (LDWORD)self);
              DismissHUD
        }break;
        case 8: {
            self.lPlayHandle8 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback8, (LDWORD)self);
              DismissHUD
        }break;
        case 9: {
            self.lPlayHandle9 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback9, (LDWORD)self);
              DismissHUD
        }break;
        case 10: {
            self.lPlayHandle10 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback10, (LDWORD)self);
              DismissHUD
        }break;
        case 11: {
            self.lPlayHandle11 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback11, (LDWORD)self);
              DismissHUD
        }break;
        case 12: {
            self.lPlayHandle12 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback12, (LDWORD)self);
              DismissHUD
        }break;
        case 13: {
            self.lPlayHandle13 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback13, (LDWORD)self);
              DismissHUD
        }break;
        case 14: {
            self.lPlayHandle14 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback14, (LDWORD)self);
              DismissHUD
        }break;
        case 15: {
            self.lPlayHandle15 = playHandle;
            NET_RUN(CLIENT_SetRealDataCallBack, playHandle, realDataCallback15, (LDWORD)self);
              DismissHUD
        }break;
        default:
            break;
    }
    sgCloseStream.Dismiss();
    sgStopPlay.Dismiss();
    sgStopRealPlay.Dismiss();
//    sgStopSound.Dismiss();
}

- (void)stopPlayWithPort:(LONG)playPort lPlayHandle:(LLONG)playHandle {
    CLIENT_StopRealPlay(playHandle);
//    PLAY_StopSound();
    PLAY_Stop(playPort);
    PLAY_CloseStream(playPort);
    s_ofile.close();
}


#pragma mark - private methods

- (void)frameChange:(UIButton *)sender {
    NSInteger i = sender.tag;

    if (!sender.selected) {
        sender.selected = YES;
         origanRect = viewPlay[i].frame;
         origanSuperV = viewPlay[i].superview;

        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        viewPlay[i].transform = CGAffineTransformMakeRotation(M_PI*(90)/180.0);
        viewPlay[i].bounds = CGRectMake(0, 0, HEIGHT, WIDTH);
        viewPlay[i].center = CGPointMake(WIDTH/2, HEIGHT/2);
        [[UIApplication sharedApplication].keyWindow addSubview:viewPlay[i]];
        [UIView commitAnimations];
         sender.frame = CGRectMake(0, 0, CGRectGetHeight(viewPlay[i].frame), CGRectGetWidth(viewPlay[i].frame));
        
    }else {
        sender.selected = NO;
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        viewPlay[i].transform = CGAffineTransformMakeRotation(0);
        viewPlay[i].frame = origanRect;
        [origanSuperV addSubview:viewPlay[i]];
        [UIView commitAnimations];
        sender.frame = CGRectMake(0, 0, CGRectGetWidth(viewPlay[i].frame), CGRectGetHeight(viewPlay[i].frame));
 
    }
   
}

- (void)startViewOnPage:(int)page {
    switch (page) {
        case 0: {
            g_nChannel = 0;
            [self onPlayWithPort:_playPort0 onView:viewPlay[0]];
            g_nChannel = 1;
            [self onPlayWithPort:_playPort1 onView:viewPlay[1]];
        }
            break;
        case 1: {
            g_nChannel = 2;
            [self onPlayWithPort:_playPort2 onView:viewPlay[2]];
            g_nChannel = 3;
        }
            break;
        case 2: {
            g_nChannel = 4;
            [self onPlayWithPort:_playPort4 onView:viewPlay[4]];
            g_nChannel = 5;
            [self onPlayWithPort:_playPort5 onView:viewPlay[5]];
            
        }
            break;
        case 3: {
            g_nChannel = 6;
            [self onPlayWithPort:_playPort6 onView:viewPlay[6]];
            g_nChannel = 7;
            [self onPlayWithPort:_playPort7 onView:viewPlay[7]];
        
        }
        case 4: {
            g_nChannel = 8;
            [self onPlayWithPort:_playPort8 onView:viewPlay[8]];
            g_nChannel = 9;
            [self onPlayWithPort:_playPort9 onView:viewPlay[9]];
           
            
        }
        case 5: {
            g_nChannel = 10;
            [self onPlayWithPort:_playPort10 onView:viewPlay[10]];
            g_nChannel = 11;
            [self onPlayWithPort:_playPort11 onView:viewPlay[11]];
            
        }
        case 6: {
            g_nChannel = 12;
            [self onPlayWithPort:_playPort12 onView:viewPlay[12]];
            g_nChannel = 13;
            [self onPlayWithPort:_playPort13 onView:viewPlay[13]];
        
        }
        case 7: {
            g_nChannel = 14;
            [self onPlayWithPort:_playPort14 onView:viewPlay[14]];
            g_nChannel = 15;
            [self onPlayWithPort:_playPort15  onView:viewPlay[15]];
            
        }
            break;
        default:
            break;
    }
  
    
}

- (void)stopViewOnPage:(int)page {
    switch (page) {
        case 0: {
            [self stopPlayWithPort:_playPort0 lPlayHandle:self.lPlayHandle0];
            self.lPlayHandle0 = 0;
            [self stopPlayWithPort:_playPort1 lPlayHandle:self.lPlayHandle1];
            self.lPlayHandle1 = 0;
            
        }
            break;
        case 1: {
            [self stopPlayWithPort:_playPort2 lPlayHandle:self.lPlayHandle2];
            self.lPlayHandle2 = 0;
            [self stopPlayWithPort:_playPort3 lPlayHandle:self.lPlayHandle3];
            self.lPlayHandle3 = 0;
                    }
            break;
        case 2: {
            [self stopPlayWithPort:_playPort4 lPlayHandle:self.lPlayHandle4];
            self.lPlayHandle4 = 0;
            [self stopPlayWithPort:_playPort5 lPlayHandle:self.lPlayHandle5];
            self.lPlayHandle5 = 0;
            
        }
            break;
        case 3: {
            [self stopPlayWithPort:_playPort6 lPlayHandle:self.lPlayHandle6];
            self.lPlayHandle6 = 0;
            [self stopPlayWithPort:_playPort7 lPlayHandle:self.lPlayHandle7];
            self.lPlayHandle7 = 0;
            
            
        }
            break;
        case 4: {
            [self stopPlayWithPort:_playPort8 lPlayHandle:self.lPlayHandle8];
            self.lPlayHandle8 = 0;
            [self stopPlayWithPort:_playPort9 lPlayHandle:self.lPlayHandle9];
            self.lPlayHandle9 = 0;
                    }
            break;
        case 5: {
            [self stopPlayWithPort:_playPort10 lPlayHandle:self.lPlayHandle10];
            self.lPlayHandle10 = 0;
            [self stopPlayWithPort:_playPort11 lPlayHandle:self.lPlayHandle11];
            self.lPlayHandle11 = 0;
            

        }
            break;
        case 6: {
            [self stopPlayWithPort:_playPort12 lPlayHandle:self.lPlayHandle12];
            self.lPlayHandle12 = 0;
            [self stopPlayWithPort:_playPort13 lPlayHandle:self.lPlayHandle13];
            self.lPlayHandle13 = 0;
            
        }
            break;
        case 7: {
            [self stopPlayWithPort:_playPort14 lPlayHandle:self.lPlayHandle14];
            self.lPlayHandle14 = 0;
            [self stopPlayWithPort:_playPort15 lPlayHandle:self.lPlayHandle15];
            self.lPlayHandle15 = 0;
        }
            break;
            
        default:
            break;
    }
}


#pragma mark - Delegates
#pragma mark -UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    currentPage = scrollView.contentOffset.x / ScreenWidth;
    rightNavLabel.text = [NSString stringWithFormat:@"%d/8",currentPage+1];
    DMLog(@"当前页：%d", currentPage);
    if (lastPage != currentPage) {
        NSLog(@"销毁上一页，播放当前页");
        [self stopViewOnPage:lastPage];
        [self startViewOnPage:currentPage];
        lastPage = currentPage;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    myScrollView = nil;
    for (int i = 0; i < PAGECOUNT; i ++) {
        scrollCurrentView[i] = nil;
    }
    for (int i = 0; i < PAGECOUNT * PAGEVIEWCOUNT; i ++) {
        viewPlay[i] = nil;
    }
    self.place = nil;
}

@end
