//
//  MonitorEngine.h
//  sunCanteen
//
//  Created by Jonren on 16/4/26.
//  Copyright © 2016年 Jonren. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PlaceDTO;
@interface MonitorEngine : NSObject

/*******************************************************************************
 Function:			isValidIP
 Description:		check ip
 Input:				ipStr － IP address
 Output:
 Return:			true-valid,false-invalid
 *******************************************************************************/
+ (bool)isValidIP:(NSString *)ipStr;


/**
 * 保存登录信息到UserDefault中
 */
+ (void)saveLoginInfoWith:(PlaceDTO *)place;

@end
