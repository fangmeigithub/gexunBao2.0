//
//  PlaceDTO.m
//  sunCanteen
//
//  Created by Jonren on 15/6/2.
//  Copyright (c) 2015年 Jonren. All rights reserved.
//

#import "PlaceDTO.h"

@implementation PlaceDTO

- (id)initWithFip:(NSString *)fip fserPort:(NSString *)fserPort fuser:(NSString *)fuser fpwd:(NSString *)fpwd {
    self = [super init];
    if (self) {
        self.fip = fip;
        self.fserPort = fserPort;
        self.fuser = fuser;
        self.fpwd = fpwd;
    }
    return self;
}

@end
