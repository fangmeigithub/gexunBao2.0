//
//  VideoWnd.h
//  netsdk_demo
//
//  Created by wu_pengzhou on 14-4-2.
//  Copyright (c) 2014年 wu_pengzhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoWnd : UIView

@end
