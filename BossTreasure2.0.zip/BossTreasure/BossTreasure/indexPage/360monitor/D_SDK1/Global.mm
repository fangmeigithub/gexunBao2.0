//
//  Global.m
//  SingleView
//
//  Created by  on 14-1-18.
//  Copyright (c) 2014年 dh. All rights reserved.
//

#import "Global.h"
#import <objc/runtime.h>
#import <UIKit/UIKit.h>

const float iOSVer = [[[UIDevice currentDevice] systemVersion] floatValue];

LLONG g_loginID = 0;
int g_ChannelCount = 0;
DHDEV_SYSTEM_ATTR_CFG g_sysAttr;
const std::string g_docFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] UTF8String];
int g_nChannel = 0;
unsigned g_nWaitTime = 3000;
unsigned g_nP2pRetry = 15;

typedef id (*IMP_objectAtIndex)(id, SEL, NSUInteger);

static id imp_objectAtIndex(id self, SEL _cmd, NSUInteger index);

static IMP_objectAtIndex oldImpOfNSArrayObjectAtIndex = (IMP_objectAtIndex)class_replaceMethod([[NSArray new] class], @selector(objectAtIndex:), (IMP)imp_objectAtIndex, @encode(IMP_objectAtIndex));

static id imp_objectAtIndex(id self, SEL _cmd, NSUInteger index)
{
    @try {
        return oldImpOfNSArrayObjectAtIndex(self, _cmd, index);
    }
    @catch (NSException *exception) {
        @throw [NSException exceptionWithName:exception.name reason:exception.reason userInfo:@{@"NSArray": self}];
    }
}
