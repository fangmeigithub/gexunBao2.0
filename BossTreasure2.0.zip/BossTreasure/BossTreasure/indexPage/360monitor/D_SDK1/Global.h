
#import <Foundation/Foundation.h>
#import <assert.h>
#import <string>
#import "global_macro_define.h"
#import "globle_functions.h"
#import "netsdk.h"
#import "play.h"

extern const float iOSVer;
extern LLONG g_loginID;
extern int g_ChannelCount;
extern DHDEV_SYSTEM_ATTR_CFG g_sysAttr;
extern const std::string g_docFolder;
extern int g_nChannel;
extern unsigned g_nWaitTime;
extern unsigned g_nP2pRetry;
