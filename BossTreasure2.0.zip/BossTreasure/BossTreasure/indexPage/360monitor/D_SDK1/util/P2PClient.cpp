// P2PClientTest.cpp : �������̨Ӧ�ó������ڵ㡣

#include "ProxyClientCWrap.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
using namespace std;
#ifdef WIN32
#include <windows.h>
#define sleep(s) Sleep(s * 1000) 
#else
#include <unistd.h>
#endif

static ProxyClientHandler client;

/***************************************************
NAME:          checkClientOnline
FUNCTION:      check the status of proxy client until status is DHProxyStateOnline
PARAMETER:
               handler[IN]:  the handle of proxy client
RETURN VALUE:  NA
****************************************************/
bool checkClientOnline(ProxyClientHandler handler, size_t tryCount)
{
    int state = 0;
    bool isOnline = false;
    while (tryCount--)
    {
        ///<get the status of proxy client
        if (DHProxyClientState(handler, &state) < 0)
        {
            printf("[Demo] proxy client check state failed!\n");
        }

        if (state == DHProxyStateOnline)
        {
            printf("[Demo] proxy client check state:On line!\n");
            isOnline = true;
            break;
        }

        sleep(1);
    }
    return isOnline;
}


/***************************************************
NAME:          checkDeviceOnline
FUNCTION:      check the status of device until status is DHProxyStateOnline
PARAMETER:
               handler[IN]:  the handle of proxy client
               uuid   [IN]:  the ID of device, in general is sequence number of device.
RETURN VALUE:  NA
****************************************************/
bool checkDeviceOnline(ProxyClientHandler handler, const char *uuid, size_t tryCount)
{
    int state = 0;
    bool isOnline = false;
    while (tryCount--)
    {
        if (DHProxyClientServerState(handler, uuid, &state) < 0)
        {
            printf("[Demo] proxy client check server state failed!\n");
        }

        if (state == DHProxyStateOnline)
        {
            printf("[Demo] proxy client check state: OnLine!\n");
            isOnline = true;
            break;
        }
        sleep(1);
    }
    return isOnline;
}


/***************************************************
NAME:         checkPortState
FUNCTION:     check the channel status of proxy client
PARAMETER:
              handler[IN]:  the handle of proxy client
              port   [IN]:  the local port of mapping remote device.
RETURN VALUE:
              >= 0 : success, and need to wait continue
              -1: failed, and need to connect again

****************************************************/
int checkPortState(ProxyClientHandler handler, int port)
{
    int state = 0;
//    DHProxyClientMapPortRate rate;

    if (DHProxyClientChannelstate(handler, port, &state) < 0)
    {
        printf("[Demo] proxy client get state failed!\n");
        return -1;
    }

    if (state == DHP2PChannelStateNonExist)
    {
        printf("[Demo] proxy client state: NonExist!\n");
        return -1;
    }

    if (state == DHP2PChannelStateInit)
    {
        printf("[Demo] proxy client state: Initing!\n");
        return 0;
    }

    printf("[Demo] proxy client create channel ok!\n");

//    if (DHProxyClientQueryRate(handler, port, &rate) < 0)
//    {
//        printf("[Demo] proxy client query rate failed!\n");
//        return -1;
//    }


    ///>Next is the proccessing logic of application layer. At this time, the local port is listening, and you just need to connect (127.0.0.1, port) and establish a TCP connection,
    ///>then, you can access the remote device.
    ///>If the application want to quit, just set the value of variable is_need_stop to 1.

    ///> TO DO


//    printf("[Demo] current recv rate:%.3f\n", rate.curRecvRate);
    return state;
}

/***************************************************
NAME:         checkRemoteInfo
FUNCTION:     check the Remote Device NAT Address
PARAMETER:
              handler[IN]:  the handle of proxy client
              port   [IN]:  the local port of mapping remote device.
RETURN VALUE:
              0 : success, and need to wait continue
              -1: failed, and need to connect again

****************************************************/
int checkRemoteNATInfo(ProxyClientHandler handler, int port)
{
   DHProxyClientRemotePortInfo info;
   if(DHProxyClientQueryRemoetInfo(handler, port, &info) < 0)
   {
       printf("[Demo] proxy client query stat info failed!\n");
       return -1;
   }

   printf("[Demo] localPort:%d, remoteID: %s, remoteAddress:%s:%d\n",
           port, info.remoteId, info.remoteIp, info.remotePort);

   return 0;
}

/************************************************************************/
/*create a connecting channel and process                               */
/************************************************************************/
bool addClientPort(ProxyClientHandler client, const char* deviceId, int devicePort, int* local_port, int tryCount)
{
    bool bGetLocalPort = false;	// get Localport succeed flag
    while(!bGetLocalPort && tryCount-- > 0)	// if failed,try again
    {
        ///>create P2P connecting channel
        DHProxyClientAddPort(client, deviceId, devicePort, local_port);
        while (tryCount-- > 0)
        {
            ///>check the status of P2P channel
            int ret = checkPortState(client, *local_port);
            if (ret < 0)
            {
                break;
            }
            else if(ret == DHP2PChannelStateActive)
            {
                bGetLocalPort = true;
                break;
            }
            sleep(5);
        }
        
        sleep(1);
    }
    return bGetLocalPort;
}
bool p2p_disconnect(int local_port)
{
    /************************************************************************/
	/*delete the P2P channel and local port,release resource before exit P2P*/
	/************************************************************************/
    if (DHProxyClientDelPort(client, local_port))
    {
        return false;
    }
    
    DHProxyClientRelease(client);
    return true;
}

int p2p_connect(const char* serverIp, int serverPort, const char* serverSecret, const char* deviceId, int devicePort, int tryCount = 15)
{
	/************************************************************************/
	/*Init P2P Client By P2P serverIP, Port and secret                       */
	/************************************************************************/
	
	int local_port = 0; ///>the mapping port of remote device.
    int serverChkCnt = tryCount*0.3, deviceChkCnt = serverChkCnt, portChkCnt = tryCount - serverChkCnt - deviceChkCnt;
    ///>DHProxyClientInit(P2P server ip, P2P server port, P2P server authentication secret)
    client = DHProxyClientInit(serverIp, serverPort, serverSecret);

	/************************************************************************/
	/*Check the status of proxy client until status is DHProxyStateOnline*/
	/************************************************************************/
    if (!checkClientOnline(client, serverChkCnt))
    {
        return -1;
    }

	/************************************************************************/
	/*check the status of device until status is DHProxyStateOnline         */
	/************************************************************************/

    ///>Then check the status of remote device
    if (!checkDeviceOnline(client, deviceId, deviceChkCnt))
    {
        return -1;
    }

	if (!addClientPort(client, deviceId, devicePort, &local_port, portChkCnt))
    {
        return -1;
    }

	
    return local_port;
}


