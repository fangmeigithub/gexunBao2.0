//
//  OrderDetialsViewController.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderDetialsViewController.h"
#import "OrderDetailTableView.h"


extern NSString *UserId;
@interface OrderDetialsViewController ()
{
    OrderDetailModel *orderDeM;
    OrderDetailTableView *orderDetailTb;
}
@end

@implementation OrderDetialsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"销售订单详情" :NO :NO];
    
    self.sc.sd_layout
    .leftSpaceToView(self.view,Scale_X(8))
    .topSpaceToView(self.view,(Scale_Y(8)))
    .rightSpaceToView(self.view,Scale_X(8))
    .bottomSpaceToView(self.view,Scale_Y(8));
    
    self.sc.backgroundColor = RGB(236, 236, 236, 1);
    
    orderDetailTb = [[OrderDetailTableView alloc]init];
    orderDetailTb.superV  = self.view;
    [self initData];
}

- (void)initData
{
    
    orderDeM = [[OrderDetailModel alloc]init];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"sysuserid"] = UserId;
    dict[@"fbillNo"] = self.dataModel.fbillNo;
    ShowHUD
    [[InterNetRequest shareRequest]getOrderDetails:dict :^(NSDictionary *dataDic) {
        DismissHUD
        if (Success) {
            [orderDeM initWithDic:dataDic];
             orderDetailTb.dataModel = self.dataModel;
             orderDetailTb.modelArray = orderDeM.data;
            [orderDetailTb reloadData];
        }
    } :^(NSError *error) {
        DismissHUD
    }];
}


@end
