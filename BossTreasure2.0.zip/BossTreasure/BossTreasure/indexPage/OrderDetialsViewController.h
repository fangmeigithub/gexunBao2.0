//
//  OrderDetialsViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "OrderDetailModel.h"
#import "OrderListModel.h"

@interface OrderDetialsViewController : BaseViewController

@property(strong,nonatomic)NSString *type;
@property(strong,nonatomic)OrderListDataModel *dataModel;

@end
