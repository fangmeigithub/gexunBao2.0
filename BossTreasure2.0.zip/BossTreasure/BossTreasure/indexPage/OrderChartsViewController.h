//
//  OrderChartsViewController.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/7.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface OrderChartsViewController : BaseViewController

@property(strong,nonatomic)NSString *type;
@end
