//
//  OrderChartView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UUChart.h"
#import "MoveViewInChartView.h"

typedef void(^chartBlock )(NSString * formatStr);
typedef void(^swipeBlock )(NSInteger type);

@interface OrderChartView : UIView
<UUChartDataSource>
{
    UUChart  *chartView;
    
    UILabel  *allLabel;
    UILabel  *checkLabel;
    UILabel  *sendGoodLabel;
    UILabel *timeLabel;
    NSArray *dayDateArray,*monthDateArray;
    
    BOOL _dayType;
    NSInteger  lineViewIndex;
}
@property(copy,nonatomic)chartBlock myBlock;
@property(copy,nonatomic)swipeBlock mySwipeBlock;
@property(strong,nonatomic)UIView *superV;

@property(assign,nonatomic) BOOL dayType;
@property(strong,nonatomic)NSDictionary *dataDic;//数据值

- (void)clickType :(chartBlock )block;
- (void)swipe :(swipeBlock )block;
- (void)layoutSubV; //刷新页面

@end
