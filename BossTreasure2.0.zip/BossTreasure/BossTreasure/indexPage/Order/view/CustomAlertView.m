//
//  CustomAlertView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CustomAlertView.h"

@implementation CustomAlertView


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        _dataArray = [[NSArray alloc]init];
        
        //选择时间
        
        dateView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        dateView.backgroundColor = [UIColor clearColor];
        
        datePicker = [[UIDatePicker alloc] initWithFrame:CGRectZero];
        datePicker.backgroundColor =RGB(230, 230, 230, 1);
        datePicker.layer.cornerRadius = 4;
        datePicker.datePickerMode = UIDatePickerModeDate;
        datePicker.transform = CGAffineTransformMakeScale(0.8,0.8);
        [dateView addSubview:datePicker];
        datePicker.sd_layout.leftSpaceToView(dateView,Scale_X(10)).rightSpaceToView(dateView,Scale_Y(10)).topSpaceToView(dateView,Scale_Y(55)).heightIs(Scale_Y(120));
        
        UIButton *cancelButton = [[MethodTool shareTool] creatButtonWithAttribute:@"取消" :11 :[UIColor whiteColor] :LikeBlackColor];
        [dateView addSubview:cancelButton];
         cancelButton.sd_layout.leftSpaceToView(dateView,Scale_X(20)).topSpaceToView(dateView,Scale_Y(240)).widthIs(Scale_X(60)).heightIs(Scale_Y(20));
        [cancelButton addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
        [cancelButton.layer setBorderWidth:1];
        [cancelButton.layer setBorderColor:blackC.CGColor];
        
        UIButton *sureButton = [[MethodTool shareTool] creatButtonWithAttribute:@"确定" :11 :[UIColor whiteColor] :ORANGE_COLOR];
        [dateView addSubview:sureButton];
        [sureButton addTarget:self action:@selector(sureClick) forControlEvents:UIControlEventTouchUpInside];
        sureButton.sd_layout.rightSpaceToView(dateView,Scale_X(20)).topSpaceToView(dateView,Scale_Y(240)).widthIs(Scale_X(60)).heightIs(Scale_Y(20));
        [sureButton.layer setBorderWidth:1];
        [sureButton.layer setBorderColor:ORANGE_COLOR.CGColor];
        
        
        resultView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        
        Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        Tb.backgroundColor=[UIColor whiteColor];
        Tb.delegate=self;
        Tb.dataSource=self;
        Tb.scrollEnabled=YES;
        Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
        [resultView addSubview:Tb];
        Tb.sd_layout.leftSpaceToView(resultView,Scale_X(5)).rightSpaceToView(resultView,Scale_Y(20)).topSpaceToView(resultView,Scale_Y(15)).bottomSpaceToView(resultView,Scale_Y(10));

       
    }
    return self;
}
- (void)showWithType :(BOOL)forTime;
{
    if (forTime) {
        [resultView removeFromSuperview];
        [self addSubview:dateView];
    }
    else{
        [dateView removeFromSuperview];
        [self addSubview:resultView];
    }
}

- (void)setDataArray:(NSArray *)dataArray
{
    _dataArray = dataArray;
    [Tb reloadData];
}

- (void)cancel
{
    [self.mydelegate backSelectContextCancel];
}
- (void)sureClick
{
    NSDateFormatter *formatter =[[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *timestamp = [formatter stringFromDate:datePicker.date];
    [self.mydelegate backSelectContext:timestamp];
}


#pragma mark－－－－－－－－－－－－－－－－－－－TableView delegate－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30*NEWY;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return _dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"firstCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.textLabel.text = _dataArray[indexPath.row];
    [cell.textLabel setFont:[UIFont systemFontOfSize:13]];
    cell.textLabel.textColor = LikeBlackColor;
   
    
    UIView *headBgView = [[UIView alloc]initWithFrame:CGRectZero];
    headBgView.backgroundColor = ViewlineColor;
    [cell addSubview:headBgView];
    headBgView.sd_layout.leftSpaceToView(cell,Scale_X(10)).topSpaceToView(cell,Scale_Y(29)).rightSpaceToView(cell,0).heightIs(Scale_Y(0.8));
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self.mydelegate backSelectContext:_dataArray[indexPath.row]];
}




@end
