
//
//  MoveViewInChartView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/24.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MoveViewInChartView.h"

#define buttonWidth   33.85

@implementation MoveViewInChartView

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        for (int i = 0; i<7; i++) {
            
            UIButton *bu = [[MethodTool shareTool] creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
            [self addSubview: bu];
            bu.tag = 1000+i;
            [bu addTarget:self action:@selector(buttonC:) forControlEvents:UIControlEventTouchUpInside];
            bu.sd_layout.leftSpaceToView(self,Scale_X((buttonWidth)*i)).topSpaceToView(self,0).widthIs(Scale_X(buttonWidth)).bottomSpaceToView(self,0);
            
        }
        
        lineView = [UIView new];
        [self addSubview:lineView];
        lineView.backgroundColor = ORANGE_COLOR;
        [self.layer addSublayer:lineView.layer];
        lineView.sd_layout.leftSpaceToView(self,Scale_X(16+buttonWidth*6)).topSpaceToView(self,0).widthIs(Scale_X(2)).bottomSpaceToView(self,Scale_Y(30));
        
    }
    return self;
}
- (void)buttonC :(UIButton *)sender
{
   
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        lineView.frame = RECT((16+buttonWidth*(sender.tag-1000)), 0, 2, self.frame.size.height-30 ,1);
        
    } completion:^(BOOL finished) {}];
    
    self.buttonClick(sender.tag-1000);
}
- (void)buttonClickBlock :(buttonClickBlock )buttonClick
{
    self.buttonClick = buttonClick;
}


@end
