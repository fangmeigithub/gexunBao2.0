//
//  searchBaseView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SearchBaseView.h"

@implementation SearchBaseView

- (instancetype)initWithSetting  :(BOOL)enable haveRightImage:(BOOL)haveImage forTime:(BOOL)forTime :(CGRect )rect;
{
    self = [super init];
    if (self) {
        self.frame = rect;
        self.backgroundColor = [UIColor clearColor];
        self.layer.borderWidth = 1;
        self.layer.borderColor = ViewlineColor.CGColor;
        
        isForTime = forTime;
        isHaveRightImage = haveImage;
        self.userInteractionEnabled = YES;
        if (haveImage) {
            rightImageView = [[MethodTool shareTool] creatImageWithAttribute:forTime?@"fortime0":@"search0"];
            [self addSubview:rightImageView];
            rightImageView.sd_layout.topSpaceToView(self,0).rightSpaceToView(self,0).bottomSpaceToView(self,0).widthIs(self.frame.size.height);
        }
        
        textF = [[MethodTool shareTool] creatTextFeild:@""];
        [textF setFont:[UIFont systemFontOfSize:10]];
        textF.delegate =self;
        textF.userInteractionEnabled = enable;
        [self addSubview:textF];
        textF.sd_layout.leftSpaceToView(self,Scale_X(1)).topSpaceToView(self,Scale_Y(1)).rightSpaceToView(haveImage?rightImageView:self,Scale_X(1)).bottomSpaceToView(self,Scale_Y(1));
      
        UITapGestureRecognizer *gestR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        [self addGestureRecognizer:gestR];
        
       
    }
    return self;
}
- (void)setTFText:(NSString *)UITextFText
{
    textF.text = UITextFText;
    
    if (!isHaveRightImage) {
        return;
    }
    if (textF.text.length != 0) {
        rightImageView.image = [UIImage imageNamed:isForTime?@"fortime1":@"search1"];
    }else{
        rightImageView.image = [UIImage imageNamed:isForTime?@"fortime0":@"fortime0"];
    }
}
- (NSString *)tFText
{
    return textF.text;
}
- (void)tap:(UITapGestureRecognizer *)sender
{
    [self.myDelegate selfTappedBack:self.tag];
}

//此页面的整体高度很小，已经无法共用 BaseView那里的代理方法了
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.myDelegate UITextFieldReturnEdit:textField];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
     [self.myDelegate UITextFieldBiganEdit:textField];
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
}


@end
