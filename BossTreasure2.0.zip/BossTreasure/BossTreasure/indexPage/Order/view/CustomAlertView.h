//
//  CustomAlertView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol clickDelegate <NSObject>

- (void)backSelectContext :(NSString *)backStr;
- (void)backSelectContextCancel;


@end
@interface CustomAlertView : UIView
<UITableViewDelegate,UITableViewDataSource>
{
    UIDatePicker *datePicker;
    UITableView  *Tb;
    UIView *dateView;
    UIView *resultView;
    NSArray *_dataArray;
}

@property(strong,nonatomic)NSArray *dataArray;
@property(assign,nonatomic)id <clickDelegate>mydelegate;

- (instancetype)initWithFrame:(CGRect)frame ;
- (void)showWithType :(BOOL)forTime;

@end
