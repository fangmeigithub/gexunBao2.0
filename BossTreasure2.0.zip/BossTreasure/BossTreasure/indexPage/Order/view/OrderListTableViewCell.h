//
//  OrderListTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/15.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDLabelView.h"
#import "OrderListModel.h"
#import "NSString+CodeAndClean.h"

@interface OrderListTableViewCell : UITableViewCell
{
     UILabel  *orderCode;
     UILabel  *oderByPerson;
     UILabel  *customer;
     UILabel  *statusLabel;
     UILabel  *startDate;
     UILabel  *endDate;
    
     NSArray *statusArray;
     NSArray *sendArray;
}

@property(strong,nonatomic)UIView *bgView;
@property(strong,nonatomic)OrderListDataModel *dataModel;

@end
