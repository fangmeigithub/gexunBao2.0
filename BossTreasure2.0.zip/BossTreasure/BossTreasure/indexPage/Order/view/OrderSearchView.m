//
//  OrderSearchView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderSearchView.h"

@implementation OrderSearchView

- (instancetype)init
{
    self = [super init];
    if (self) {
        //浅灰色背景
        self.backgroundColor = RGB(247, 248, 249, 1);
        
        NSArray *textArray = @[@"下单开始",@"下单结束",@"交货开始",@"交货结束",@"订单号",@"单据调用",@"订单状态",
                               @"发货状态",@"开单人",@"客户",@"部门",@"业务员",@"组织机构",@"货品名称",@"手机",@"客户速查码"];
        
        //是否有交互性
        NSArray *enableArray = @[@"NO",@"NO",@"NO",@"NO",@"YES",@"YES",@"NO",
                                 @"NO",@"YES",@"NO",@"NO",@"NO",@"NO",@"NO",@"YES",@"YES"];
        //是否右侧有图片
        NSArray *haveRightImageArray = @[@"YES",@"YES",@"YES",@"YES",@"NO",@"NO",@"YES",
                                         @"YES",@"NO",@"YES",@"YES",@"YES",@"YES",@"YES",@"NO",@"NO"];
        //是否是时间选择的图片
        NSArray *forTimeArray = @[@"YES",@"YES",@"YES",@"YES",@"NO",@"NO",@"NO",
                                  @"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO",@"NO"];
        
        sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, Scale_Y(6), WIDTH,Scale_Y(480))];
        sc.contentSize=CGRectMake(0, 0,WIDTH,Scale_Y(481)).size;
        sc.showsHorizontalScrollIndicator = NO;
        sc.showsVerticalScrollIndicator = NO;
        sc.backgroundColor = [UIColor clearColor];
        sc.scrollEnabled=YES;
        [self addSubview:sc];
        
        for (int i = 0; i<textArray.count; i++) {
            
            NSInteger x_For = i%2;
            NSInteger y_for = i/2;
            
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[textArray objectAtIndex:i] :14 :LikeBlackColor];
            [sc addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(sc,Scale_X(8+153*x_For))
            .topSpaceToView(sc,NavHeight+Scale_Y(18+30*y_for))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@":" :MEDIUM_FONT :1 :LikeBlackColor];
            [sc addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(0))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(4))
            .heightIs(15);
            
            SearchBaseView * searchBaseV = [[SearchBaseView alloc]initWithSetting:[[enableArray objectAtIndex:i] boolValue]
                                                                   haveRightImage:[[haveRightImageArray objectAtIndex:i] boolValue]
                                                                          forTime:[[forTimeArray objectAtIndex:i] boolValue]
                                                                                 :RECT((75+153*x_For), NavHeight+16+(30*y_for)*NEWY, 83, 20, 0)];
            [sc addSubview:searchBaseV];
            searchBaseV.tag = 5000+i;
            searchBaseV.myDelegate = self;
            
        }
        
        alert = [[FDAlertView alloc] init];
        contentView = [[CustomAlertView alloc]initWithFrame:RECT(100, 100, 220, 300, 1)];
        contentView.layer.cornerRadius = 5;
        contentView.mydelegate = self;
        alert.contentView = contentView;
        
        //收藏最终的请求参数
        backParameterArray = [[NSMutableArray alloc]initWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",
                                                                     @"",@"",@"",@"",@"",@"",@"",@"", nil];
        
    }
    return self;
}

#pragma mark－－－－－－－－－－－－－－－－－－－SearchBaseView delegate－－－－－－－－－－－－－－－－
//点击选择了某项查询按钮，或进行网络请求
- (void)selfTappedBack:(NSInteger)selfTag
{
    viewTag = selfTag-5000; //全局指向
    if (selfTag>=5000&&selfTag<5004) {
        [contentView showWithType:YES];
        [alert show];
    }
    else if (selfTag == 5006){//订单状态
        [contentView showWithType:NO];
         contentView.dataArray = @[@"未审核",@"审核中",@"已审核",@"已作废"];
         [alert show];
    }
    else if (selfTag == 5007){//发货状态

        [contentView showWithType:NO];
         contentView.dataArray = @[@"未发货",@"部分发货",@"已发货",@"准备发货"];
         [alert show];
    }
    else{
        NSArray *ParameterArray = @[@"",@"",@"",@"",@"",@"",@"",@"",@"",
                                    @"byCust",@"byDept",@"byBusiPerson",@"byUnion",@"byItem"];
        [self.myDelegate searchSomeParameter:ParameterArray[viewTag]];
    }
}


//请求回来的数据
- (void)interNetBackData :(NSArray *)interNetBackDataArrray;
{
    interNetBackDataAr = interNetBackDataArrray;
    NSArray *ParameterDicNameKeyArray = @[@"",@"",@"",@"",@"",@"",@"",@"",@"",
                                          @"fcustname",@"fdeptName",@"fempName",@"funionName",@"fitemName"];
    
    NSMutableArray *contentViewDataArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in interNetBackDataAr) {
        //为保证安全，防止内部不是字典
        if (![dic isKindOfClass:[NSDictionary class]]) {
            return;
        }
        if (dic[ParameterDicNameKeyArray[viewTag]]) {
            [contentViewDataArray addObject:dic[ParameterDicNameKeyArray[viewTag]]];
        }
    
    }
    [contentView showWithType:NO];
    contentView.dataArray = [NSArray arrayWithArray:contentViewDataArray];
    [alert show];
  
}


#pragma mark－－－－－－－－－－－－－－－－－－－CustomAlertView delegate－－－－－－－－－－－－－－－－
//选定了弹框中的某一项
- (void)backSelectContext:(NSString *)backStr
{
    if (viewTag<4) {
        [backParameterArray replaceObjectAtIndex:viewTag withObject:backStr];

    }else if ((viewTag>=4)&&(viewTag!=6)&&(viewTag!=7)) {
        NSArray *ParameterDicNameKeyArray = @[@"",@"",@"",@"",@"",@"",@"",@"",@"",
                                              @"fcustname",@"fdeptName",@"fempName",@"funionName",@"fitemName"];
        NSArray *ParameterDicIdKeyArray = @[@"",@"",@"",@"",@"",@"",@"",@"",@"",
                                            @"fcustno",@"fdeptNo",@"fempId",@"funionId",@"fitemNo"];
        for (NSDictionary *dic in interNetBackDataAr) {
            //为保证安全，防止内部不是字典
            if (![dic isKindOfClass:[NSDictionary class]]) {
                return;
            }
            if ([dic[ParameterDicNameKeyArray[viewTag]] isEqualToString:backStr]) {
               [backParameterArray replaceObjectAtIndex:viewTag withObject:dic[ParameterDicIdKeyArray[viewTag]]];
            }
            
        }
    }else{
        [backParameterArray replaceObjectAtIndex:viewTag withObject:[self getStatusForRequestValue:backStr]];
    }
   
    SearchBaseView *searchV = [sc viewWithTag:viewTag+5000];
    searchV.tFText = backStr;
    [alert hide];
    
}
- (void)backSelectContextCancel
{
    //弹框消失
    [alert hide];
}


//返回查询参数给列表页
- (NSDictionary *)backInterNetParameter;
{
    
    /**
     *  没有把控各查询条件之间的并列和包含关系，只是简单的组合在一起，组合错误的条件集合就没有数据返回
     */
    
    NSArray *parameterKeyArray = @[@"fbillCreateAt_start",@"fbillCreateAt_end",
                                   @"freqJhDate_start",@"freqJhDate_end",
                                   @"fbillNo",@"",
                                   @"fstatu",@"fsendStatu",
                                   @"fkdEmpName",@"fcustno",
                                   @"fdeptNo",@"fywEmpNo",
                                   @"funionId",@"fitemNo",
                                   @"",@"ffindcode"];//单据调用预留接口
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithCapacity:0];
    for (SearchBaseView *subV in sc.subviews) {
        if ([subV isKindOfClass:NSClassFromString(@"SearchBaseView")]) {
            if (subV.tFText.length !=0) {//有数值的查询条件
                dict[parameterKeyArray[subV.tag-5000]] = backParameterArray[subV.tag-5000];
            }
        }
       
    }
    return dict;
}

- (NSString *)getStatusForRequestValue :(NSString *)valueKey
{
    NSDictionary *dic = [[NSDictionary alloc]initWithObjects:@[@"0",@"1",@"2",@"3",@"0",@"1",@"2",@"3"] forKeys:@[@"未审核",@"审核中",@"已审核",@"已作废",@"未发货",@"部分发货",@"已发货",@"准备发货"]];
    return dic[valueKey];
}



#pragma mark－－－－－－－－－－－－－－－－－－－UITextField delegate－－－－－－－－－－－－－－－－

- (void)UITextFieldBiganEdit:(UITextField *)tF
{
    UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
    CGRect frame=[tF convertRect: tF.bounds toView:window];
    
    /*
     *  frame.origin.y;  获取的是父视图的相对坐标  需要获取在屏幕上的位置
     */
    int offset = frame.origin.y  - (self.frame.size.height - 216)+60;
    
    [UIView animateWithDuration:0.2 animations:^{
        float width = self.frame.size.width;
        float height = self.frame.size.height;
        if(offset > 0)
        {
            CGRect rect = CGRectMake(0.0f, -offset,width,height);
            self.frame = rect;
        }
    }];
}
- (void)UITextFieldReturnEdit:(UITextField *)tF
{
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = CGRectMake(0.0f, 0.0f, self.frame.size.width, self.frame.size.height);
        self.frame = rect;
    }];
    [tF resignFirstResponder];
}




@end