//
//  OrderDetailTableViewCell.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/23.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderDetailTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation OrderDetailTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView  *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(248, 248, 248, 1);
        [self.contentView addSubview:bgView];
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(2))
        .topSpaceToView(self.contentView,Scale_X(0))
        .rightSpaceToView(self.contentView,Scale_X(2))
        .bottomSpaceToView(self.contentView,Scale_Y(6));
        
        NSArray *titleArray = @[@"金额",@"数量",@"颜色",@"货品编号",@"折扣率",@"货品名称",@"单价"];
       
        for (int i = 0; i<7; i++) {
            
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :14 :blackC];
            [bgView addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(bgView,Scale_X(15))
            .topSpaceToView(bgView,Scale_Y(6+20*i))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
            [bgView addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(2))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(200))
            .heightIs(15);
            
            if (i==0) {
                allAcount = rightLabel;
            }else if (i==1){
                 number = rightLabel;
            }else if (i==2){
                 color = rightLabel;
            }else if (i==3){
                goodsCode = rightLabel;
            }else if (i==4){
                 cutCode = rightLabel;
            }else if (i==5){
                 goodName = rightLabel;
            }else if (i==6){
                 price = rightLabel;
            }
        }
    }
    return self;
}

- (void)setDataModel:(DataModel *)dataModel
{
    allAcount.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.famt]] headFormat:@"："];
    number.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.fqty]] headFormat:@"："];
    color.text = [[[MethodTool shareTool] cleanData:dataModel.color] headFormat:@"："];
    goodsCode.text = [[[MethodTool shareTool] cleanData:dataModel.fitemNo] headFormat:@"："];
    cutCode.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.fdiscount]] headFormat:@"："];
    goodName.text = [[[MethodTool shareTool] cleanData:dataModel.fitemName] headFormat:@"："];
    price.text = [[[MethodTool shareTool] cleanData:[NSNumber numberWithDouble:dataModel.fprice]] headFormat:@"："];
    
}

@end
