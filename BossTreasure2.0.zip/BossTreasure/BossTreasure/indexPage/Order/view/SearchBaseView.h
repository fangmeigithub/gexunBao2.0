//
//  searchBaseView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol selfTappedDelegate <NSObject>

- (void)selfTappedBack :(NSInteger)selfTag;
//为了上层页面不遮挡键盘
- (void)UITextFieldBiganEdit :(UITextField *)tF;
- (void)UITextFieldReturnEdit :(UITextField *)tF;

@end

@interface SearchBaseView : UIView
<UITextFieldDelegate>
{
    UIImageView *rightImageView;
    UITextField *textF;
    BOOL isForTime;
    BOOL isHaveRightImage;
}
@property(copy,nonatomic)NSString  *tFText;
@property(assign,nonatomic)id <selfTappedDelegate> myDelegate;

/**
 *  自定义控件
 *
 *  @param enable    是否可以点击
 *  @param haveImage 是有有右边的图片
 *  @param forTime   是否是时间选择的图片
 *  @param rect   尺寸
 *
 *  @return 自定义控件
 */
- (instancetype)initWithSetting  :(BOOL)enable haveRightImage:(BOOL)haveImage forTime:(BOOL)forTime :(CGRect )rect;


@end
