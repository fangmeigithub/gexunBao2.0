//
//  MoveViewInChartView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/24.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^buttonClickBlock)(NSInteger buttonTag);

@interface MoveViewInChartView : UIView
{
    UIView *lineView;
}
@property(copy,nonatomic)buttonClickBlock buttonClick;

- (void)buttonClickBlock :(buttonClickBlock )buttonClick;

@end
