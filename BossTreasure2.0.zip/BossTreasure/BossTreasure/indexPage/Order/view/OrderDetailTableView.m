//
//  OrderDetailTableView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/23.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderDetailTableView.h"
#import "OrderDetailTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation OrderDetailTableView

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.dataSource = self;
        self.delegate = self;
        self.backgroundColor = RGB(248, 248, 248, 1);
    }
    return self;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.modelArray.count+1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section ==0 ) {
        return 170*NEWY;
    }
    else{
        return 155*NEWY;
    }
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section<=1) {
        return Scale_Y(25);
    }
    return 0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 1;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(236, 236, 236, 1);
    view1.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).heightIs(Scale_Y(25));
    
    UILabel *allGoodsNumberLabel = [[MethodTool shareTool] creatLabelWithAttribute:section==0?@"订单信息":@"商品信息"  :MEDIUM_FONT :1 :blackC];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(10)).centerYEqualToView(view1).rightSpaceToView(view1,Scale_X(100)).heightIs(Scale_Y(20));
    return view1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        UITableViewCell *cell = [[UITableViewCell alloc]init];
        [cell.contentView addSubview:bgView];
        return cell;
    }else{
        static NSString *cellIdentifier = @"firstCell";
        OrderDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (!cell) {
            cell = [[OrderDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        cell.tag = indexPath.row;
        cell.dataModel = [self.modelArray objectAtIndex:(indexPath.section-1)];
        return cell;
    }
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

- (void)setSuperV:(UIView *)superV
{
    [superV addSubview:self];
    self.sd_layout
    .leftSpaceToView(superV,0)
    .topSpaceToView(superV,NavHeight)
    .rightSpaceToView(superV,0)
    .heightIs(HEIGHT-64);
}

- (void)setDataModel:(OrderListDataModel *)dataModel
{
    UITableViewCell *cell = [self cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    bgView = [UIView new];
    bgView.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:bgView];
    
    bgView.sd_layout
    .leftSpaceToView(cell.contentView,Scale_X(2))
    .topSpaceToView(cell.contentView,Scale_X(0))
    .rightSpaceToView(cell.contentView,Scale_X(2))
    .bottomSpaceToView(cell.contentView,Scale_Y(6));
    
    statusArray = @[@"：未审核",@"：审核中",@"：已审核",@"：已作废"];
    sendArray = @[@"：未发货",@"：部分发货",@"：已发货",@"：准备发货"];
    NSArray *titleArray = @[@"订单编号",@"状态",@"客户名称",@"开单人",@"总金额",@"总数量",@"交货日期",@"下单日期"];
    
    NSArray *textArray = @[dataModel.fbillNo,
                           @"",
                           dataModel.fcustname,
                           dataModel.fkdEmpName,
                           [[NSNumber numberWithDouble:dataModel.famt]stringValue],
                           [[NSNumber numberWithDouble:dataModel.fsumQty]stringValue],
                           dataModel.freqJhDate,
                           dataModel.fbillCreateAt];
    
    UILabel *status ;
    for (int i = 0; i<titleArray.count; i++) {
        
        FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :14 :blackC];
        [bgView addSubview:titlelabel];
        titlelabel.sd_layout
        .leftSpaceToView(bgView,Scale_X(15))
        .topSpaceToView(bgView,Scale_Y(6+20*i))
        .widthIs(Scale_X(60))
        .heightIs(15);
        
        UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:[[textArray objectAtIndex:i] headFormat:@"：" ] :MEDIUM_FONT :1 :i==1?ORANGE_COLOR:blackC];
        [bgView addSubview:rightLabel];
        rightLabel.sd_layout
        .leftSpaceToView(titlelabel,Scale_X(2))
        .topEqualToView(titlelabel)
        .widthIs(Scale_X(200))
        .heightIs(15);
        if (i==1) {
            status = rightLabel;
        }
    }
    if ([dataModel.fstatu intValue]==2) {
        status.text = [sendArray objectAtIndex:[dataModel.fsendStatu intValue]];
    }else
    {
        status.text = [statusArray objectAtIndex:[dataModel.fstatu intValue]];
    }
     status.attributedText = [[MethodTool shareTool] creatAttributedString:status.text :blackC :0 :1];
}


@end

