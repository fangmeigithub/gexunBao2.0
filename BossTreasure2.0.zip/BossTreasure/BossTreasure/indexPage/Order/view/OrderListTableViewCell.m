//
//  OrderListTableViewCell.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/15.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderListTableViewCell.h"

@implementation OrderListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.bgView = [UIView new];
        self.bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(248, 248, 248, 1);
        [self.contentView addSubview:self.bgView];
        
        self.bgView.sd_layout
        .leftSpaceToView(self.contentView,Scale_X(2))
        .topSpaceToView(self.contentView,Scale_X(0))
        .rightSpaceToView(self.contentView,Scale_X(2))
        .bottomSpaceToView(self.contentView,Scale_Y(6));
        
        NSArray *titleArray = @[@"订单编号",@"开单人",@"客户名称"];
        statusArray = @[@"未审核",@"审核中",@"已审核",@"已作废"];
        sendArray = @[@"未发货",@"部分发货",@"已发货",@"准备发货"];
        
        for (int i = 0; i<3; i++) {
            FDLabelView *titlelabel  = [[MethodTool shareTool] creatAdjustLabelWithAttribute:[titleArray objectAtIndex:i] :16 :blackC];
            [self.bgView addSubview:titlelabel];
            titlelabel.sd_layout
            .leftSpaceToView(self.bgView,Scale_X(10))
            .topSpaceToView(self.bgView,Scale_Y(6+20*i))
            .widthIs(Scale_X(60))
            .heightIs(15);
            
            UILabel *rightLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
            [self.bgView addSubview:rightLabel];
            rightLabel.sd_layout
            .leftSpaceToView(titlelabel,Scale_X(2))
            .topEqualToView(titlelabel)
            .widthIs(Scale_X(200))
            .heightIs(15);
            
            if (i==0) {
                orderCode = rightLabel;
            }
            else if (i == 1){
                oderByPerson = rightLabel;
            }
            else if (i == 2){
                customer = rightLabel;
            }
        }
    
        statusLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :3 :ORANGE_COLOR];
        [self.bgView addSubview:statusLabel];
        statusLabel.sd_layout
        .rightSpaceToView(self.bgView,Scale_X(15))
        .topSpaceToView(self.bgView,Scale_Y(6))
        .widthIs(Scale_X(60))
        .heightIs(15);

       
        
        //下单日期
        UILabel *startTimeLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"下单日期" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:startTimeLabel];
        startTimeLabel.sd_layout
        .leftSpaceToView(self.bgView,Scale_X(10))
        .topSpaceToView(self.bgView,Scale_Y(8+20*3))
        .widthIs(Scale_X(55))
        .heightIs(15);
        
        
        startDate = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:startDate];
        startDate.sd_layout
        .leftSpaceToView(startTimeLabel,Scale_X(0))
        .topEqualToView(startTimeLabel)
        .widthIs(Scale_X(80))
        .heightIs(15);
        
        
    
        //交期
        UILabel *endTimeLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"要求交货日期" :MEDIUM_FONT :3 :blackC];
        [self.bgView addSubview:endTimeLabel];
         endTimeLabel.sd_layout
        .rightSpaceToView(self.bgView,Scale_X(80))
        .topEqualToView(startDate)
        .widthIs(Scale_X(80))
        .heightIs(15);
        
        
        endDate = [[MethodTool shareTool] creatLabelWithAttribute:@"" :MEDIUM_FONT :1 :blackC];
        [self.bgView addSubview:endDate];
        endDate.sd_layout
        .leftSpaceToView(endTimeLabel,Scale_X(0))
        .topEqualToView(endTimeLabel)
        .widthIs(Scale_X(80))
        .heightIs(15);
        
    }
    return self;
}

- (void)setDataModel:(OrderListDataModel *)dataModel
{
    orderCode.text = [[[MethodTool shareTool] cleanData:dataModel.fbillNo] headFormat:@"："];
    oderByPerson.text = [[[MethodTool shareTool] cleanData:dataModel.fkdEmpName] headFormat:@"："];
    customer.text = [[[MethodTool shareTool] cleanData:dataModel.fcustname] headFormat:@"："];
    if ([dataModel.fstatu intValue]==2) {
        statusLabel.text = [sendArray objectAtIndex:[dataModel.fsendStatu intValue]];
    }else
    {
        statusLabel.text = [statusArray objectAtIndex:[dataModel.fstatu intValue]];
    }
    startDate.text = [[[MethodTool shareTool] cleanData:dataModel.fbillCreateAt] headFormat:@"："];
    endDate.text = [[[MethodTool shareTool] cleanData:dataModel.freqJhDate] headFormat:@"："];
    if ((![endDate.text isEqualToString:@"：暂无数据"])&&([endDate.text length] !=0)) {
        endDate.textColor = REDCOLOR;
        endDate.attributedText = [[MethodTool shareTool] creatAttributedString:endDate.text :blackC :0 :1];
    }
    else{
        endDate.textColor = blackC;
    }
    
}


@end
