//
//  OrderChartView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/13.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderChartView.h"


@implementation OrderChartView


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        //初始化  Day/Month
       dayDateArray = [[[[MethodTool shareTool] getSevenDaysFormNow] reverseObjectEnumerator] allObjects];
       monthDateArray = [[[[MethodTool shareTool] getSevenMonthFormNow] reverseObjectEnumerator] allObjects];
        //默认按天
        _dayType = YES;
        lineViewIndex = 6;
       [self initSubV];
        
    }
    return self;
    
}

- (void)initSubV
{
    
    
    timeLabel = [[MethodTool shareTool] creatLabelWithAttribute:[dayDateArray lastObject] :MEDIUM_FONT :2 :ORANGE_COLOR];
    [self addSubview:timeLabel];
    timeLabel.sd_layout.centerXEqualToView(self).topSpaceToView(self,NavHeight+Scale_Y(56)).widthIs(Scale_X(120)).heightIs(Scale_X(15));
    
    
    NSArray *colorArray = @[RGB(28, 172, 221, 1),
                            RGB(238, 68, 37, 1),
                            RGB(115, 200, 38, 1)];
    
    
    chartView = [[UUChart alloc]initwithUUChartDataFrame:CGRectMake(Scale_X(5), NavHeight+Scale_Y(74), [UIScreen mainScreen].bounds.size.width-Scale_X(20), Scale_Y(195))
                                              withSource:self
                                               withStyle:UUChartLineStyle];
    chartView.backgroundColor = [UIColor clearColor];
    [chartView showInView:self];
    
    
    
    NSArray *titleArray = @[@"已接收的订单",@"已审核的订单",@"已发货的订单"];
    for (int i = 0; i<3; i++) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [colorArray objectAtIndex:i];
        bgView.layer.cornerRadius = 5;
        [self addSubview:bgView];
        bgView.sd_layout.leftSpaceToView(self,Scale_X(15)).topSpaceToView(chartView,Scale_Y(20+55*i)).rightSpaceToView(self,Scale_X(15)).heightIs(Scale_Y(45));
        
        UIButton *actionB = [[MethodTool shareTool] creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
        [actionB addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        actionB.tag = 200+i;
        [bgView addSubview:actionB];
         actionB.sd_layout.leftSpaceToView(bgView,Scale_X(0)).topSpaceToView(bgView,Scale_Y(0)).rightSpaceToView(bgView,Scale_X(0)).bottomSpaceToView(bgView,0);
        
        UILabel *titleLabel = [[MethodTool shareTool] creatLabelWithAttribute:[titleArray objectAtIndex:i] :MEDIUM_FONT :1 :[UIColor whiteColor]];
        [bgView addSubview:titleLabel];
        titleLabel.sd_layout.leftSpaceToView(bgView,Scale_X(10)).topSpaceToView(bgView,Scale_Y(5)).widthIs(Scale_X(120)).heightIs(15);
        
        UILabel *numberLabel = [[MethodTool shareTool] creatLabelWithAttribute:@"0" :BIG_FONT :1 :[UIColor whiteColor]];
        [bgView addSubview:numberLabel];
        numberLabel.sd_layout.leftSpaceToView(bgView,Scale_X(10)).bottomSpaceToView(bgView,Scale_Y(5)).widthIs(Scale_X(120)).heightIs(15);
        
        UIImageView *arrowV = [[MethodTool shareTool] creatImageWithAttribute:@"goto"];
        [bgView addSubview:arrowV];
        arrowV.sd_layout.centerYEqualToView(bgView).rightSpaceToView(bgView,Scale_Y(10)).widthIs(Scale_X(20)).heightIs(Scale_X(20));
        
        
        if (i == 0) {
            allLabel = numberLabel;
        }
        else if (i == 1){
            checkLabel = numberLabel;
        }
        else{
            sendGoodLabel = numberLabel;
        }
    }
    
    //移动的指针
    MoveViewInChartView *moveView = [[MoveViewInChartView alloc]init];
    [self addSubview:moveView];
    [moveView buttonClickBlock:^(NSInteger buttonTag) {
        //竖线的坐标
        lineViewIndex = buttonTag;
        [self selectDataWithLineViewIndex];
    }];
    moveView.sd_layout.leftSpaceToView(self,Scale_X(52)).topSpaceToView(self,NavHeight+Scale_Y(74)).rightSpaceToView(self,Scale_X(40)).heightIs(Scale_Y(210));
    
    
    // 加上左右滑动的手势
    UISwipeGestureRecognizer *swiepLeftGeture = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRecpgnizer:)];
    [swiepLeftGeture setDirection: UISwipeGestureRecognizerDirectionLeft];
    [self addGestureRecognizer:swiepLeftGeture];
    
    UISwipeGestureRecognizer *swiepRightGeture = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRecpgnizer:)];
    [swiepRightGeture setDirection: UISwipeGestureRecognizerDirectionRight];
    [self addGestureRecognizer:swiepRightGeture];
    
}

#pragma mark - @required
//横坐标标题数组
- (NSArray *)UUChart_xLableArray:(UUChart *)chart
{
    if (_dayType) {
        NSMutableArray *dateA =[[NSMutableArray alloc]initWithCapacity:0];
        for (NSString *timeStr in dayDateArray) {
            [dateA addObject:[timeStr substringFromIndex:5]];
        }
        return [NSArray arrayWithArray:dateA];
    }else
    {
        NSMutableArray *dateA =[[NSMutableArray alloc]initWithCapacity:0];
        for (NSString *timeStr in monthDateArray) {
            [dateA addObject:[timeStr componentsSeparatedByString:@"-"][1]];
        }
        return [NSArray arrayWithArray:dateA];
    }
}
//数值多重数组
- (NSArray *)UUChart_yValueArray:(UUChart *)chart
{
    if (self.dataDic.count>0) {
        return @[self.dataDic[@"accCount"],self.dataDic[@"apprCount"],self.dataDic[@"sendCount"]];
    }else
    {
        //初始化值，避免崩溃
        NSArray *ary = @[@"0",@"0",@"0",@"0",@"0",@"0",@"0"];
        NSArray *ary1 = @[@"0",@"0",@"0",@"0",@"0",@"0",@"0"];
        NSArray *ary2 = @[@"0",@"0",@"0",@"0",@"0",@"0",@"0"];
        return @[ary,ary1,ary2];
    }
}
#pragma mark - @optional
//颜色数组
- (NSArray *)UUChart_ColorArray:(UUChart *)chart
{
    return @[RGB(28, 172, 221, 1),
             RGB(238, 68, 37, 1),
             RGB(115, 200, 38, 1)];
}
//显示数值范围
- (CGRange)UUChartChooseRangeInLineChart:(UUChart *)chart
{
    if (self.dataDic.count>0) {
        return CGRangeMake([self getMaxDataForY], 0);
    }else{
       return CGRangeMake(100, 0);
    }
    
}

//判断显示横线条
- (BOOL)UUChart:(UUChart *)chart ShowHorizonLineAtIndex:(NSInteger)index
{
    return YES;
}

- (void)clickType :(chartBlock )block;
{
    self.myBlock = block;
}
- (void)swipe :(swipeBlock )block;
{
    self.mySwipeBlock = block;
}

- (void)buttonClick :(UIButton *)sende
{
    NSString *buttonTag = @"";
    if (sende.tag==200) {
        buttonTag = @"";
    }else if (sende.tag==201){
        buttonTag = @"2";
    }else{
        //buttonTag = @"3";//已发货的状态还没加上
    }
     self.myBlock([NSString stringWithFormat:@"%@:%@:%@",buttonTag,_dayType?@"Day":@"Month",timeLabel.text]);
}

//滑动请求 当天和当月  本处的滑动跟新通过VC的请求后得到刷新
- (void)swipeRecpgnizer :(UISwipeGestureRecognizer *)sender
{
    if (sender.direction == UISwipeGestureRecognizerDirectionLeft) {
        self.mySwipeBlock(1);
        }
    else{
         self.mySwipeBlock(0);
    }
}

- (void)setSuperV:(UIView *)superV
{
    [superV addSubview:self];
    self.sd_layout
    .leftSpaceToView(superV,0)
    .topSpaceToView(superV,0)
    .rightSpaceToView(superV,0)
    .bottomSpaceToView(superV,0);
    
}
//为了布局页面
- (void)setDayType:(BOOL )dayType
{
    _dayType = dayType;
    [self selectDataWithLineViewIndex];
    [self layoutSubV];
}
- (void)layoutSubV; //刷新页面
{
    [chartView strokeChart];
}


#pragma mark－－－－－－－－－－－－－－－－－－－tool method－－－－－－－－－－－－－－－－
//得到年－月
- (NSString *)subTimeStr:(NSString *)orginTimeStr
{
    NSArray *strArray =[orginTimeStr componentsSeparatedByString:@"-"];
    return [NSString stringWithFormat:@"%@-%@",strArray[0],strArray[1]];
}
//根据竖线的位置来筛选数据
- (void)selectDataWithLineViewIndex
{
     timeLabel.text = _dayType?dayDateArray[lineViewIndex]:[self subTimeStr:monthDateArray[lineViewIndex]];
    
    if (self.dataDic.count==0) {
        return;
    }
    DMLog(@"%@ %@ %@",self.dataDic[@"accCount"][lineViewIndex],self.dataDic[@"apprCount"][lineViewIndex],self.dataDic[@"sendCount"][lineViewIndex]);
    
    allLabel.text = [[MethodTool shareTool] cleanData:self.dataDic[@"accCount"][lineViewIndex]];
    checkLabel.text = [[MethodTool shareTool] cleanData:self.dataDic[@"apprCount"][lineViewIndex]];
    sendGoodLabel.text = [[MethodTool shareTool] cleanData:self.dataDic[@"sendCount"][lineViewIndex]];
    
}

//计算外Y坐标的取值范围
- (int )getMaxDataForY
{
    NSArray *allOrderDataArray =self.dataDic[@"accCount"];
    int max1 = [[allOrderDataArray valueForKeyPath:@"@max.intValue"] intValue];
    int needToAdd = max1%10;//需要多少变为整数
    int maxNew = 10-needToAdd+max1;
    if (maxNew==0) {
        return 100;
    }else{
        return maxNew;
    }
}



@end
