//
//  OrderDetailTableViewCell.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/23.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderDetailModel.h"

@interface OrderDetailTableViewCell : UITableViewCell
{
    UILabel  *allAcount;
    UILabel  *number;
    UILabel  *color;
    UILabel  *goodsCode;
    UILabel  *cutCode;
    UILabel  *goodName;
    UILabel  *price;
}

@property(strong,nonatomic)DataModel *dataModel;

@end
