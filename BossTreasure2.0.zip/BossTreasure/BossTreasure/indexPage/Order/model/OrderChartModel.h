//
//  OrderChartModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderChartModel : NSObject
//
- (NSDictionary *)selectDataWithDataDic :(NSDictionary *)dataDic :(BOOL)byDay;

@end


