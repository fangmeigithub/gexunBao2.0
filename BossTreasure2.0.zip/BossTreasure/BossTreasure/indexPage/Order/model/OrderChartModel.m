//
//  OrderChartModel.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderChartModel.h"

@implementation OrderChartModel


- (NSDictionary *)selectDataWithDataDic :(NSDictionary *)dataDic :(BOOL)byDay;
{
    //
    NSMutableDictionary *addDataDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    NSMutableArray *accCount = [NSMutableArray new];
    NSMutableArray *apprCount = [NSMutableArray new];
    NSMutableArray *sendCount = [NSMutableArray new];
    NSArray *keyArray  = nil;
    //此处的数据要严格与时间对应，顺序要正确
    if (byDay) {
        keyArray = @[@"Day1",@"Day2",@"Day3",@"Day4",@"Day5",@"Day6",@"Day7"];
    }else{
        keyArray = @[@"Month1",@"Month2",@"Month3",@"Month4",@"Month5",@"Month6",@"Month7"];
    }
    
    NSDictionary *dataD = dataDic[@"data"];
    for (int i = 0; i<keyArray.count; i++) {
        NSDictionary *dic = dataD[keyArray[i]];
        [accCount addObject:(dic[@"accCount"]?dic[@"accCount"]:@"0")];//如果没有就设初始值
        [apprCount addObject:(dic[@"apprCount"]?dic[@"apprCount"]:@"0")];
        [sendCount addObject:(dic[@"sendCount"]?dic[@"sendCount"]:@"0")];
    }
    [addDataDic setObject:accCount forKey:@"accCount"];
    [addDataDic setObject:apprCount forKey:@"apprCount"];
    [addDataDic setObject:sendCount forKey:@"sendCount"];
    
    return [NSDictionary dictionaryWithDictionary:addDataDic];
}

@end

