//
//  orderListModel.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/22.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface OrderListModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray *data;

@property (nonatomic, copy) NSString *msg;

- (void)initWithDic :(NSDictionary *)dataDic;

@end


@interface OrderListDataModel : NSObject

@property (nonatomic, copy) NSString *fstatu;

@property (nonatomic, copy) NSString *fcustname;

@property (nonatomic, assign) double fsumQty;

@property (nonatomic, copy) NSString *fkdEmpName;

@property (nonatomic, copy) NSString *fbillNo;

@property (nonatomic, copy) NSString *fsendStatu;

@property (nonatomic, copy) NSString *freqJhDate;

@property (nonatomic, copy) NSString *fbillCreateAt;

@property (nonatomic, assign) double famt;

- (void)initWithDataDic :(NSDictionary *)dataDic;

@end

